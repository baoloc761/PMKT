﻿(function () {
    angular.module('AccountingApp')
        .factory('AddDetailsAccountFactory', AddDetailsAccountFactory); //tao factory cho module chinh
    AddDetailsAccountFactory.$inject = ['$http']; //tim service http vao
    function AddDetailsAccountFactory($http) {
        var service = {
            GetlistAccount: GetlistAccount,
            LayDanhSanPhamDichVu: LayDanhSanPhamDichVu,
            LayDanhSachDoiTac: LayDanhSachDoiTac,
            LayDanhSachDanhMuc: LayDanhSachDanhMuc,
            LayDanhSachNoiBo: LayDanhSachNoiBo,
            GetlistAccountNameNumber: GetlistAccountNameNumber,
            ThemMoiTaiKhoanLV2: ThemMoiTaiKhoanLV2
        };
        return service
    }

    //GET ma bo phan
    function GetlistAccountNameNumber(item) {
        var data = item;
        var response = $.ajax({
            type: 'POST',
            url: '/AddDetailedAccount/NumberAccountGetLevel',
            dataType: 'json',
            contentType: 'application/json; charset=utf-8',
            data: JSON.stringify(data),

        });
        return response;
    }

    //Thêm
    function ThemMoiTaiKhoanLV2(item) {
        var data = item;
        var response = $.ajax({
            type: 'POST',
            url: '/AddDetailedAccount/AddAccountLevel',
            dataType: 'json',
            contentType: 'application/json; charset=utf-8',
            data: JSON.stringify(data),
        });
        return response;
    }

    function GetlistAccount() {
        var bodyRequest = {
            data: {
                LevelAccount: 2,
            }
        };
        var response =
            $.ajax({
            type: 'POST',
            url: '/AddDetailedAccount/AccountGetLevel',
            data: JSON.stringify(bodyRequest),
            dataType: 'json',
            contentType: 'application/json; charset=utf-8',
        });
        return response;
    }


   



    //GET SP/DV
    function LayDanhSanPhamDichVu(item) {
        var data = item;
        var response = $.ajax({
            type: 'POST',
            url: '/AddDetailedAccount/GetSPDV',
            dataType: 'json',
            contentType: 'application/json; charset=utf-8',
            data: JSON.stringify(data),

        });
        return response;
    }

    //GET doi tac
    function LayDanhSachDoiTac(item) {
        var data = item;
        var response = $.ajax({
            type: 'POST',
            url: '/AddDetailedAccount/GetDoiTac',
            dataType: 'json',
            contentType: 'application/json; charset=utf-8',
            data: JSON.stringify(data),

        });
        return response;
    }

    //GET danh mục
    function LayDanhSachDanhMuc(item) {
        var data = item;
        var response = $.ajax({
            type: 'POST',
            url: '/AddDetailedAccount/GetCategories',
            dataType: 'json',
            contentType: 'application/json; charset=utf-8',
            data: JSON.stringify(data),

        });
        return response;
    }

    //GET noi bộ
    function LayDanhSachNoiBo(item) {
        var data = item;
        var response = $.ajax({
            type: 'POST',
            url: '/AddDetailedAccount/GetNoiBo',
            dataType: 'json',
            contentType: 'application/json; charset=utf-8',
            data: JSON.stringify(data),

        });
        return response;
    }
})();