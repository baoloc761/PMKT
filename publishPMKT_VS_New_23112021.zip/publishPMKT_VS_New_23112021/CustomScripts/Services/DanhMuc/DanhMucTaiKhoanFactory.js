﻿(function () {
    angular.module('AccountingApp')
        .factory('DanhMucTaiKhoanFactory', DanhMucTaiKhoanFactory); //tao factory cho module chinh
    DanhMucTaiKhoanFactory.$inject = ['$http']; //tim service http vao
    function DanhMucTaiKhoanFactory($http) {
        var service = {
            LayDanhMucGiaoDich: LayDanhMucGiaoDich
        };
        return service

        //GET LIST Dan sách bộ phận
        function LayDanhMucGiaoDich() {
            var bodyRequest = {
                data: {
                    AccountParent: ''
                }
            };
            var response = $.ajax({
                type: 'POST',
                url: '/DanhMucTaiKhoan/GetAccParentt',
                dataType: 'json',
                contentType: 'application/json; charset=utf-8',
                data: JSON.stringify(bodyRequest),
            });
            return response;
        }

    }
})();