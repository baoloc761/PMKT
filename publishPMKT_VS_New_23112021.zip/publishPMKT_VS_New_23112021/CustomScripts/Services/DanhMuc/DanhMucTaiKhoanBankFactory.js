﻿(function () {
    angular.module('AccountingApp')
        .factory('DanhMucTaiKhoanBankFactory', DanhMucTaiKhoanBankFactory); //tao factory cho module chinh
    DanhMucTaiKhoanBankFactory.$inject = ['$http']; //tim service http vao
    function DanhMucTaiKhoanBankFactory($http) {
        var service = {
            LayDanhMucTaiKhoanBank: LayDanhMucTaiKhoanBank,
            ThemTaiKhoanBank: ThemTaiKhoanBank,
            CapNhatTaiKhoanChiTiet: CapNhatTaiKhoanChiTiet,
            XoaTaiKhoanChiTiet: XoaTaiKhoanChiTiet,
            LayDanhSachNganHang: LayDanhSachNganHang,
            LayDanhSachTienTeSelect: LayDanhSachTienTeSelect
        };
        return service

        //GET LIST Tiền
        function LayDanhSachTienTeSelect(item) {
            var data = item;
            var response = $.ajax({
                type: 'POST',
                url: '/DanhMucTaiKhoanBank/GetMoney',
                dataType: 'json',
                contentType: 'application/json; charset=utf-8',
                data: JSON.stringify(data),

            });
            return response;
        }


        //GET LIST ngân hàng
        function LayDanhSachNganHang(item) {
            var data = item;
            var response = $.ajax({
                type: 'POST',
                url: '/DanhMucTaiKhoanBank/GetListbank',
                dataType: 'json',
                contentType: 'application/json; charset=utf-8',
                data: JSON.stringify(data),

            });
            return response;
        }


        //GET LIST Danh mục tài khoản bank
        function LayDanhMucTaiKhoanBank() {
            var bodyRequest = {
                data: {
                    SearchValue: '',
                    Page: 1,
                    RowPerPage: 10,
                    SortType: ''
                }
            };
            var response = $.ajax({
                type: 'POST',
                url: '/DanhMucTaiKhoanBank/GetBankAccAll',
                dataType: 'json',
                contentType: 'application/json; charset=utf-8',
                data: JSON.stringify(bodyRequest),
            });
            return response;
        }

        //Thêm tài khoản chi tiết
        function ThemTaiKhoanBank(item) {
            var data = item;
            var response = $.ajax({
                type: 'POST',
                url: '/DanhMucTaiKhoanBank/AddBankAccount',
                dataType: 'json',
                contentType: 'application/json; charset=utf-8',
                data: JSON.stringify(data),
            });
            return response;
        }
        //UPDATE tài khoản chi tiết
        function CapNhatTaiKhoanChiTiet(item) {
            var data = item;
            var response = $.ajax({
                type: 'POST',
                url: 'DanhMucTaiKhoanBank/UpdateBankAccount',
                dataType: 'json',
                contentType: 'application/json; charset=utf-8',
                data: JSON.stringify(data),
            });
            return response;
        }

        //DELETE tài khoản chi tiết
        function XoaTaiKhoanChiTiet(item) {
            var data = item;
            var response = $.ajax({
                type: 'POST',
                url: 'DanhMucTaiKhoanBank/DeleteBankAccount',
                dataType: 'json',
                contentType: 'application/json; charset=utf-8',
                data: JSON.stringify(data),
            });
            return response;
        }
    }
})();