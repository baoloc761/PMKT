﻿(function () {
    angular.module('AccountingApp')
        .factory('BangDuAnFactory', BangDuAnFactory); //tao factory cho module chinh
    BangDuAnFactory.$inject = ['$http']; //tim service http vao
    function BangDuAnFactory($http) {
        var service = {
            LayDanhSachDuAn: LayDanhSachDuAn,
            ThemMoiDuan: ThemMoiDuan,
            XoaDuAn: XoaDuAn,
            CapNhatDuAn: CapNhatDuAn
        };
        return service
        //GET LIST Danh sách dự án
        function LayDanhSachDuAn(item) {
            var bodyRequest = item;
              
            var response = $.ajax({
                type: 'POST',
                url: '/BangDuAn/GetAllProject',
                dataType: 'json',
                contentType: 'application/json; charset=utf-8',
                data: JSON.stringify(bodyRequest),
            });
            return response;
        }

        //Thêm Danh sách dự án
        function ThemMoiDuan(item) {
            var data = item;
            var response = $.ajax({
                type: 'POST',
                url: '/BangDuAn/AddNewProject',
                dataType: 'json',
                contentType: 'application/json; charset=utf-8',
                data: JSON.stringify(data),
            });
            return response;
        }

        //DELETE Danh sách dự án
        function XoaDuAn(item) {
            var bodyRequest = {
                ProjectCode: item.ProjectCode,
                ProjectName: item.ProjectName,
                ProjectPlace: item.ProjectPlace,
                ProjectID: item.ProjectID,
                IsRemove: true
            };
            var response = $.ajax({
                type: 'POST',
                url: '/BangDuAn/DeleteProject',
                dataType: 'json',
                contentType: 'application/json; charset=utf-8',
                data: JSON.stringify(bodyRequest),
            });
            return response;
        }

        //UPDATE Danh sách dự án
        function CapNhatDuAn(item) {
            var bodyRequest = {
                ProjectCode: item.ProjectCode,
                ProjectName: item.ProjectName,
                ProjectPlace: item.ProjectPlace,
                ProjectID: item.ProjectID
            };
            var response = $.ajax({
                type: 'POST',
                url: 'BangDuAn/UpdateProject',
                dataType: 'json',
                contentType: 'application/json; charset=utf-8',
                data: JSON.stringify(bodyRequest),
            });
            return response;
        }
    }
})();