﻿(function () {
    angular.module('AccountingApp')
        .factory('DanhMucNhanVienFactory', DanhMucNhanVienFactory); //tao factory cho module chinh
    DanhMucNhanVienFactory.$inject = ['$http']; //tim service http vao
    function DanhMucNhanVienFactory($http) {
        var service = {
            LayDanhMucNhanVien: LayDanhMucNhanVien,
            ThemMoiNhanVien: ThemMoiNhanVien,
            XoaDichNhanvien: XoaDichNhanvien,
            CapNhatNhanVien: CapNhatNhanVien,
            LayDanhMaBoPhanSelect: LayDanhMaBoPhanSelect
        };
        return service

        //GET ma bo phan
        function LayDanhMaBoPhanSelect(item) {
            var data = item;
            var response = $.ajax({
                type: 'POST',
                url: '/DanhMucNhanVien/GetMaBoPhan',
                dataType: 'json',
                contentType: 'application/json; charset=utf-8',
                data: JSON.stringify(data),

            });
            return response;
        }


        //GET LIST Dịch vụ sản phẩm
        function LayDanhMucNhanVien(item) {
            var data = item;
            var response = $.ajax({
                type: 'POST',
                url: '/DanhMucNhanVien/GetListEmployees',
                dataType: 'json',
                contentType: 'application/json; charset=utf-8',
                data: JSON.stringify(data),
            });
            return response;
        }

        //thêm
        function ThemMoiNhanVien(item) {
            var data = item;
            var response = $.ajax({
                type: 'POST',
                url: '/DanhMucNhanVien/AddEmployee',
                dataType: 'json',
                contentType: 'application/json; charset=utf-8',
                data: JSON.stringify(data),
            });
            return response;
        }
        //DELETE 
        function XoaDichNhanvien(item) {
            var data = item;
            var response = $.ajax({
                type: 'POST',
                url: '/DanhMucNhanVien/DeleteEmployee',
                dataType: 'json',
                contentType: 'application/json; charset=utf-8',
                data: JSON.stringify(data),
            });
            return response;
        }
        //UPDATE 
        function CapNhatNhanVien(item) {
            var data = item;
            var response = $.ajax({
                type: 'POST',
                url: 'DanhMucNhanVien/UpdateEmployee',
                dataType: 'json',
                contentType: 'application/json; charset=utf-8',
                data: JSON.stringify(data),
            });
            return response;
        }
    }
})();