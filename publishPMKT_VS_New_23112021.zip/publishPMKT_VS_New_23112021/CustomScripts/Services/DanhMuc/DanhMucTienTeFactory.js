﻿(function () {
    angular.module('AccountingApp')
        .factory('DanhMucTienTeFactory', DanhMucTienTeFactory); //tao factory cho module chinh
    DanhMucTienTeFactory.$inject = ['$http']; //tim service http vao
    function DanhMucTienTeFactory($http) {
        var service = {
            Laydanhsachtiente: Laydanhsachtiente,
            ThemMoiTienTe: ThemMoiTienTe,
            XoaDichVuTienTe: XoaDichVuTienTe,
            CapNhatTienTe: CapNhatTienTe
        };
        return service
        //GET LIST Danh sách tiền tệ
        function Laydanhsachtiente(item) {
            var data = item;
            var response = $.ajax({
                type: 'POST',
                url: '/DanhMucTienTe/GetListTienTe',
                dataType: 'json',
                contentType: 'application/json; charset=utf-8',
                data: JSON.stringify(data),
            });
            return response;
        }

        //Thêm tiền tệ
        function ThemMoiTienTe(item) {
            var data = item;
            var response = $.ajax({
                type: 'POST',
                url: '/DanhMucTienTe/AddNewCurent',
                dataType: 'json',
                contentType: 'application/json; charset=utf-8',
                data: JSON.stringify(data),
            });
            return response;
        }

        //DELETE Danh sách tiền tệ
        function XoaDichVuTienTe(item) {
            var data = item;
            var response = $.ajax({
                type: 'POST',
                url: '/DanhMucTienTe/delete_Current',
                dataType: 'json',
                contentType: 'application/json; charset=utf-8',
                data: JSON.stringify(data),
            });
            return response;
        }
        //UPDATE Danh sách tiền tệ
        function CapNhatTienTe(item) {
            var data = item;
            var response = $.ajax({
                type: 'POST',
                url: 'DanhMucTienTe/Update_Current',
                dataType: 'json',
                contentType: 'application/json; charset=utf-8',
                data: JSON.stringify(data),
            });
            return response;
        }
    }

})();