﻿var AccountingApp = angular.module('AccountingApp');
AccountingApp.controller('SidebarController', ['$state', '$scope', '$stateParams', function ($state, $scope, $stateParams) {
    $scope.$on('$includeContentLoaded', function () {
        //lấy danh sách menu chức năng
        $scope.lastMenu = 0;
        $scope.layDSChucNang();
        $scope.fn_click();

    });
    //$scope.layDSChucNang = function () {
    //    $.post('/Home/LayMenuChucNang').done(function (res) {
    //        if (res && res.status === 1) {
    //            $scope.NavMainMenu = res.data;
    //            if (res.data.length > 0) {
    //                for (var i = 0; i < res.data.length; i++) {
    //                    var itemCap1 = res.data[i];
    //                    $scope.lastMenu = itemCap1.IDMenu;
    //                    if (itemCap1.Child.length > 0) {
    //                        for (var k = 0; k < itemCap1.Child.length; k++) {
    //                            var itemCap2 = itemCap1.Child[k];
    //                            $scope.lastMenu = itemCap2.IDMenu;
    //                            if (itemCap2.Child.length > 0) {
    //                                for (var j = 0; j < itemCap2.Child.length; j++) {
    //                                    var itemCap3 = itemCap2.Child[j];
    //                                    $scope.lastMenu = itemCap3.IDMenu;
    //                                }
    //                            }
    //                        }
    //                    }
    //                }
    //            }
    //            //console.log("menu: ", $scope.NavMainMenu);

    //        }
    //        else {
    //            toastr["warning"]("Vui lòng nhấn F5 để lấy menu chức năng", "Thông báo");
    //        }

    //    }).fail(function () {
    //        toastr["error"]("Vui lòng nhấn F5 để lA ấy menu chức năng", "Thông báo");
    //    }).always(function () {
    //        $scope.$digest();
    //    });
    //};


    //get list right menu
    $scope.layDSChucNang = function () {
        $.post('/Home/GetRightCategoriesMenu').done(function (res) {
            if (res && res.status === 1) {
                $scope.NavMainMenu = res.data;
                if (res.data.length > 0) {
                    for (var i = 0; i < res.data.length; i++) {
                        var itemCap1 = res.data[i];
                        $scope.lastMenu = itemCap1.Code;
                        if (itemCap1.MenuSubs.length > 0) {
                            for (var k = 0; k < itemCap1.MenuSubs.length; k++) {
                                var itemCap2 = itemCap1.MenuSubs[k];
                                $scope.lastMenu = itemCap2.Code;
                                if (itemCap2.MenuSubs.length > 0) {
                                    for (var j = 0; j < itemCap2.MenuSubs.length; j++) {
                                        var itemCap3 = itemCap2.MenuSubs[j];
                                        $scope.lastMenu = itemCap3.Code;
                                    }
                                }
                            }
                        }
                    }
                }
                //console.log("menu: ", $scope.NavMainMenu);

            }
            else {
                toastr["warning"]("Vui lòng nhấn F5 để lấy menu chức năng", "Thông báo");
            }

        }).fail(function () {
            toastr["error"]("Vui lòng nhấn F5 để lấy menu chức năng", "Thông báo");
        }).always(function () {
            $scope.$digest();
        });
    };

  
    $scope.initMenu = function (lastMenu) {
        // console.log("Test :" + index);
        if ($scope.lastMenu == lastMenu)//Load 1 lần
        {
            (function (jQuery) {

                // Variable
                var $ = jQuery;
                $.fn.ripple = function () {
                    $(this).click(function (e) {
                        var rippler = $(this),
                            ink = rippler.find(".ink");

                        if (rippler.find(".ink").length === 0) {
                            rippler.append("<span class='ink'></span>");
                        }


                        ink.removeClass("animate");
                        if (!ink.height() && !ink.width()) {
                            var d = Math.max(rippler.outerWidth(), rippler.outerHeight());
                            ink.css({
                                height: d,
                                width: d
                            });
                        }

                        var x = e.pageX - rippler.offset().left - ink.width() / 2;
                        var y = e.pageY - rippler.offset().top - ink.height() / 2;
                        ink.css({
                            top: y + 'px',
                            left: x + 'px'
                        }).addClass("animate");
                    });
                };

                $.fn.carouselAnimate = function () {
                    function doAnimations(elems) {
                        var animEndEv = 'webkitAnimationEnd animationend';

                        elems.each(function () {
                            var $this = $(this),
                                $animationType = $this.data('animation');
                            $this.addClass($animationType).one(animEndEv, function () {
                                $this.removeClass($animationType);
                            });
                        });
                    }

                    var $myCarousel = this;
                    var $firstAnimatingElems = $myCarousel.find('.item:first')
                        .find('[data-animation ^= "animated"]');

                    doAnimations($firstAnimatingElems);
                    $myCarousel.carousel('pause');
                    $myCarousel.on('slide.bs.carousel', function (e) {
                        var $animatingElems = $(e.relatedTarget)
                            .find("[data-animation ^= 'animated']");
                        doAnimations($animatingElems);
                    });
                };


                this.hide = function () {
                    $(".tree").hide();
                    $(".sub-tree").hide();
                };
                this.hoverMenu = function () {
                    $("#menuCap1 li").click(function (e) {
                        e.stopPropagation()
                        console.log($(this));
                        $(this).css("background-color", "yellow");
                    }, function () {
                        $(this).css("background-color", "pink");
                    });
                };
                //$(document).on("mouseenter", "#menuCap1 li a", function () {
                //    // console.log($(this));
                //    $(this).css("background-color", "rgba(0, 0, 0, .04)");
                //});
                //$(document).on("mouseleave", "#menuCap1 li a", function () {
                //    $(this).css("background-color", "#f6f8f8");
                //});
                this.treeMenu = function () {

                    $('.tree-toggle').click(function (e) {
                        e.preventDefault();
                        var $this = $(this).parent().children('ul.tree');
                        $(".tree").not($this).slideUp("fast");
                        $this.toggle("fast");

                        $(".tree").not($this).parent("li").find(".tree-toggle .right-arrow").removeClass("fa-angle-down").addClass("fa-angle-left");
                        $this.parent("li").find(".tree-toggle .right-arrow").toggleClass("fa-angle-left fa-angle-down");

                    });

                    $('.sub-tree-toggle').click(function (e) {
                        e.preventDefault();
                        var $this = $(this).parent().children('ul.sub-tree');
                        $(".sub-tree").not($this).slideUp("fast");
                        $this.toggle("fast");
                        //$(this).css("background-color", "rgba(0, 0, 0, .08)");
                        $(".sub-tree").not($this).parent("li").find(".sub-tree-toggle .right-arrow").removeClass("fa-angle-down").addClass("fa-angle-left");
                        $this.parent("li").find(".sub-tree-toggle .right-arrow").toggleClass("fa-angle-left fa-angle-down");
                        //$(".sub-tree").not($this).parent("li").css("background-color", "#f6f8f8");

                    });
                };
                $(document).on("click", "#menuCap1 li a", function (e) {
                    //e.preventDefault();
                    //$(this).unbind('mouseenter mouseleave')
                    //console.log($(this).parent().parent());
                    $('#sidebar-menu').find('li > a').each(function (ind, el) {
                        if ($(this).css("background-color") === "rgb(230,247,255)")
                            $(this).css("border-right", "6px solid #000000")
                            $(this).css("border-right", "transparent")
                            $(this).css("color", "#000000")
                            $(this).css("text-decoration", "transparent")
                            $(this).css("background-color", "transparent");
                    });
                    $(this).css("background-color", "rgb(230,247,255)");
                    $(this).css("border-right", "6px solid #0aa0ea");
                    $(this).css("color", "#2caeed");
                    $(this).css("text-decoration", "underline");

                    //$('.nav-list').find('li > a::after').each(function (ind, el) {
                    //    if ($(this).css("display") === "block")
                    //        $(this).css("content", "''")
                    //    $(this).css("position", "absolute!important")
                    //    $(this).css("right", "0")
                    //    $(this).css("top", "4px")
                    //    $(this).css("border", "8px solid transparent")
                    //    $(this).css("border-width", "14px 10px")
                    //    $(this).css("border-right-color", "#14AF9C");
                    //});
                    //$(this).css("display", "block");
                    //$(this).css("content", "''");
                    //$(this).css("position", "absolute!important");
                    //$(this).css("right", "0");
                    //$(this).css("top", "4px");
                    //$(this).css("border", "8px solid transparent");
                    //$(this).css("border-width", "14px 10px");
                    //$(this).css("border-right-color", "#14AF9C");
                });


                this.leftMenu = function () {
                    $('.opener-left-menu').on('click', function () {
                        $(".line-chart").width("100%");
                        $(".mejs-video").height("auto").width("100%");
                        if ($('#right-menu').is(":visible")) {
                            $('#right-menu').animate({ 'width': '0px' }, 'fast', function () {
                                $('#right-menu').hide();
                            });
                        }
                        if ($('#left-menu .sub-left-menu').is(':visible')) {
                            $('#content').animate({ 'padding-left': '0px' }, 'fast');
                            $('#left-menu .sub-left-menu').animate({ 'width': '0px' }, 'fast', function () {
                                $('.overlay').show();
                                $('.opener-left-menu').removeClass('is-open');
                                $('.opener-left-menu').addClass('is-closed');
                                $('#left-menu .sub-left-menu').hide();
                            });

                        }
                        else {
                            $('#left-menu .sub-left-menu').show();
                            $('#left-menu .sub-left-menu').animate({ 'width': "280px" }, 'fast');


                            //setTimeout(t => {
                            //    var elmnt = document.getElementById("left-menu");
                            //    var pad = window.innerWidth - elmnt.offsetWidth;},2000)

                            $('#content').animate({ 'padding-left': '280px', 'padding-right': '0px' }, 'fast');
                            $('.overlay').hide();
                            $('.opener-left-menu').removeClass('is-closed');
                            $('.opener-left-menu').addClass('is-open');
                        }
                    });
                };


                this.userList = function () {

                    $(".user-list ul").niceScroll({
                        touchbehavior: true,
                        cursorcolor: "#FF00FF",
                        cursoropacitymax: 0.6,
                        cursorwidth: 24,
                        usetransition: true,
                        hwacceleration: true,
                        autohidemode: "hidden"
                    });

                };




                this.rightMenu = function () {
                    $('.opener-right-menu').on('click', function () {
                        userList();
                        $(".user").niceScroll();
                        $(".user ul li").on('click', function () {
                            $(".user-list ul").getNiceScroll().remove();
                            $(".user").hide();
                            $(".chatbox").show(1000);
                            userList();
                        });

                        $(".close-chat").on("click", function () {
                            $(".user").show();
                            $(".chatbox").hide(1000);
                        });

                        $(".line-chart").width("100%");

                        if ($('#left-menu .sub-left-menu').is(':visible')) {
                            $('#left-menu .sub-left-menu').animate({ 'width': '0px' }, 'fast', function () {
                                $('#left-menu .sub-left-menu').hide();
                                $('.overlay').show();
                                $('.opener-left-menu').removeClass('is-open');
                                $('.opener-left-menu').addClass('is-closed');
                            });

                            $('#content').animate({ 'padding-left': '0px' }, 'fast');
                        }

                        if ($('#right-menu').is(':visible')) {
                            $('#right-menu').animate({ 'width': '0px' }, 'fast', function () {
                                $('#right-menu').hide();
                            });
                            $('#content').animate({ 'padding-right': '0px' }, 'fast');
                        }
                        else {
                            $('#right-menu').show();
                            $('#right-menu').animate({ 'width': '280px' }, 'fast');
                            $('#content').animate({ 'padding-right': '280px' }, 'fast');
                        }
                    });
                };

                


                $(".box-v6-content-bg").each(function () {
                    $(this).attr("style", "width:" + $(this).attr("data-progress") + ";");
                });

                $('.carousel-thumb').on('slid.bs.carousel', function () {
                    if ($(this).find($(".item")).is(".active")) {
                        var Current = $(this).find($(".item.active")).attr("data-slide");
                        $(".carousel-thumb-img li img").removeClass("animated rubberBand");
                        $(".carousel-thumb-img li").removeClass("active");

                        $($(".carousel-thumb-img").children()[Current]).addClass("active");
                        $($(".carousel-thumb-img li").children()[Current]).addClass("animated rubberBand");
                    }
                });

              

                $(".carousel-thumb-img li").on("click", function () {
                    $(".carousel-thumb-img li img").removeClass("animated rubberBand");
                    $(".carousel-thumb-img li").removeClass("active");
                    $(this).addClass("active");
                });

                $("#mimin-mobile-menu-opener").on("click", function (e) {
                    $("#mimin-mobile").toggleClass("reverse");
                    var rippler = $("#mimin-mobile");
                    if (!rippler.hasClass("reverse")) {
                        if (rippler.find(".ink").length == 0) {
                            rippler.append("<div class='ink'></div>");
                        }
                        var ink = rippler.find(".ink");
                        ink.removeClass("animate");
                        if (!ink.height() && !ink.width()) {
                            var d = Math.max(rippler.outerWidth(), rippler.outerHeight());
                            ink.css({ height: d, width: d });

                        }
                        var x = e.pageX - rippler.offset().left - ink.width() / 2;
                        var y = e.pageY - rippler.offset().top - ink.height() / 2;
                        ink.css({
                            top: y + 'px',
                            left: x + 'px',
                        }).addClass("animate");

                        rippler.css({ 'z-index': 9999 });
                        rippler.animate({
                            backgroundColor: "#FF6656",
                            width: '100%'
                        }, 750);

                        $("#mimin-mobile .ink").on("animationend webkitAnimationEnd oAnimationEnd MSAnimationEnd",
                            function (e) {
                                $(".sub-mimin-mobile-menu-list").show();
                                $("#mimin-mobile-menu-opener span").removeClass("fa-bars").addClass("fa-close").css({ "font-size": "2em" });
                            });
                    } else {

                        if (rippler.find(".ink").length == 0) {
                            rippler.append("<div class='ink'></div>");
                        }
                        var ink = rippler.find(".ink");
                        ink.removeClass("animate");
                        if (!ink.height() && !ink.width()) {
                            var d = Math.max(rippler.outerWidth(), rippler.outerHeight());
                            ink.css({ height: d, width: d });

                        }
                        var x = e.pageX - rippler.offset().left - ink.width() / 2;
                        var y = e.pageY - rippler.offset().top - ink.height() / 2;
                        ink.css({
                            top: y + 'px',
                            left: x + 'px',
                        }).addClass("animate");
                        rippler.animate({
                            backgroundColor: "transparent",
                            'z-index': '-1'
                        }, 750);

                        $("#mimin-mobile .ink").on("animationend webkitAnimationEnd oAnimationEnd MSAnimationEnd",
                            function (e) {
                                $("#mimin-mobile-menu-opener span").removeClass("fa-close").addClass("fa-bars").css({ "font-size": "1em" });
                                $(".sub-mimin-mobile-menu-list").hide();
                            });
                    }
                });



                $(".form-text").on("click", function () {
                    $(this).before("<div class='ripple-form'></div>");
                    $(".ripple-form").on("animationend webkitAnimationEnd oAnimationEnd MSAnimationEnd",
                        function (e) {
                            // do something here
                            $(this).remove();
                        });
                });

                $('.mail-wrapper').find('.mail-left').css('height', $('.mail-wrapper').innerHeight());
                $("#left-menu ul li a").ripple();
                $(".ripple div").ripple();
                $("#carousel-example3").carouselAnimate();
                $("#left-menu .sub-left-menu").niceScroll();
                $(".sub-mimin-mobile-menu-list").niceScroll({
                    touchbehavior: true,
                    cursorcolor: "#FF00FF",
                    cursoropacitymax: 0.6,
                    cursorwidth: 24,
                    usetransition: true,
                    hwacceleration: true,
                    autohidemode: "hidden"
                });

                $(".fileupload-v1-btn").on("click", function () {
                    var wrapper = $(this).parent("span").parent("div");
                    var path = wrapper.find($(".fileupload-v1-path"));
                    $(".fileupload-v1-file").click();
                    $(".fileupload-v1-file").on("change", function () {
                        path.attr("placeholder", $(this).val());
                        console.log(wrapper);
                        console.log(path);
                    });
                });

                var datetime = null,
                    date = null;

                var update = function () {
                    date = moment(new Date())
                    datetime.html(date.format('HH:mm'));
                    datetime2.html(date.format('dddd, MMMM Do YYYY'));
                };

                $(document).ready(function () {
                    datetime = $('.time h1');
                    datetime2 = $('.time p');
                    update();
                    setInterval(update, 1000);
                });


                $("body").tooltip({ selector: '[data-toggle=tooltip]' });
                leftMenu();
                rightMenu();
                treeMenu();
                hide();
                //hoverMenu();
            })(jQuery);

            // var url = location.hash.toLowerCase();
            setTimeout(t => {
                var menu = $('#sidebar-menu');
                //debugger
                menu.find('li > a').each(function () {
                    var state = $(this).attr('ui-sref');
                    if ($state && state) {
                        if ($state.is(state)) {
                            //el = $(this);
                            var $this = $(this).parent().parent();
                            if ($this.attr("id") != "menuCap1") {
                                $this.toggle("fast");
                                $this.parent("li").find(".sub-tree-toggle .right-arrow").toggleClass("fa-angle-right fa-angle-down");
                                $this = $this.parent().parent();
                            }
                            $this.toggle("fast");
                            $(this).css("background-color", "rgba(0, 0, 0, .08)");
                            $this.parent("li").find(".tree-toggle .right-arrow").toggleClass("fa-angle-right fa-angle-down");
                            // $this = $this.parent().parent();

                            //$this = $(this).parent().children('ul.sub-tree');
                            //$this.toggle("fast");
                            //$this.parent("li").find(".sub-tree-toggle .right-arrow").toggleClass("fa-angle-right fa-angle-down");
                            return;
                        }
                        //else {

                        //}
                    }
                })

            }, 500);
            //this.treeMenu1 = function () {

            //    $('.tree-toggle').click(function (e) {
            //        e.preventDefault();

            //    });

            //    $('.sub-tree-toggle').click(function (e) {
            //        e.preventDefault();
            //        var $this = $(this).parent().children('ul.sub-tree');
            //        $(".sub-tree").not($this).slideUp("fast");
            //        $this.toggle("fast");

            //        $(".sub-tree").not($this).parent("li").find(".sub-tree-toggle .right-arrow").removeClass("fa-angle-down").addClass("fa-angle-right");
            //        $this.parent("li").find(".sub-tree-toggle .right-arrow").toggleClass("fa-angle-right fa-angle-down");
            //    });
            //};
        }
        // $scope.a;
    };
    setTimeout(t => {
        //$(document).ready(function () {

        //});
    }, 1500)

}]);