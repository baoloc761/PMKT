﻿angular.module('AccountingApp').controller("CoCauController", function ($scope, CoCauFactory, SweetAlert) {
    $scope.$on('$viewContentLoaded', function () {
        $scope.LayDSCoCau();
        $scope.disableBtn = false;
        $scope.rowFocus = { IdCoCau: 0 };
    });
    //$scope.outTable = function () {
    //    $scope.rowFocus = { IdCoCau: 0 };
    //}
    $scope.selectRow = function (item) {
        $scope.rowFocus = item;
    }
    //lấy danh sách dịch vụ
    $scope.LayDSCoCau = function (type = 0) {
        $scope.DSCoCau = [];
        $scope.rowFocus = { IdCoCau: 0 };
        CoCauFactory
            .layDSCoCau()
            .done(function (res) {
                if (res && res.ErrorCode === 0) {
                    if (res.Data.length > 0) {
                        $scope.DSCoCau = res.Data;
                        if (type === 1) //Làm mới danh sách
                        {
                            toastr.success("Danh sách đã được làm mới!");
                        }
                        setTimeout(t => {
                            $('#datatables-example').DataTable();
                            $('#datatables-example_filter label input, #datatables-example_paginate ul').on('click', function () {
                                $scope.rowFocus = { IdCoCau: 0 };
                                $scope.$digest();
                            });
                        }, 100)
                    }
                    else {
                        toastr.info('Không có dữ liệu');
                    }
                }
                else {
                    toastr.warning(res.ErrorMsg);
                }
            }).fail(function () {
                toastr.error(res.ErrorMsg);
            }).always(function () {
                $scope.$digest();
            });
    };
    //khởi tạo thêm dịch vụ
    $scope.initThem = function (item) {
        $scope.ItemDetail = {
            IdCoCau: 0,
            TiLePLG: '',
            TenCoCau: '',
            Protein: '',
            Lipit: '',
            Gluxit: ''
        };
        $('#DetailModal').modal('show');
        //Validate form
        validateForm("#DetailForm")
    };
    $scope.ThemCoCau = function () {
        var check = $("#DetailForm").valid();
        if (check) {
            $scope.disableBtn = true;
            CoCauFactory
                .themCoCau($scope.ItemDetail)
                .done(function (res) {
                    if (res && res.ErrorCode === 0) {
                        toastr.success(res.Message)
                        $('#DetailModal').modal('hide');
                        $scope.LayDSCoCau();
                    }
                    else {
                        toastr.warning(res.ErrorMsg);
                    }
                }).fail(function () {
                    toastr.error(res.ErrorMsg);
                }).always(function () {
                    setTimeout(t => {
                        $scope.disableBtn = false;
                        $scope.$digest();
                    }, 500)

                });
        }
    }
    //khởi tạo sửa dịch vụ
    $scope.initCapNhap = function (item) {
        $scope.ItemDetail = {};
        $scope.TiLePLG = item.TiLePLG;
        CoCauFactory
            .layCoCauBangId(item)
            .done(function (res) {
                if (res && res.ErrorCode === 0) {

                    $scope.ItemDetail = res.Data;
                    $('#DetailModal').modal('show');
                    //Validate form
                    validateForm("#DetailForm")
                }
                else {
                    toastr.warning(res.ErrorMsg);
                }
            }).fail(function () {
                toastr.error(res.ErrorMsg);
            }).always(function () {
                $scope.$digest();
            });
    };
    $scope.CapNhatCoCau = function () {
        var check = $("#DetailForm").valid();
        if (check) {
            $scope.disableBtn = true;
            CoCauFactory
                .capNhatCoCau($scope.ItemDetail)
                .done(function (res) {
                    if (res && res.ErrorCode === 0) {
                        toastr.success(res.Message)
                        $('#DetailModal').modal('hide');
                        $scope.LayDSCoCau();
                    }
                    else {
                        toastr.warning(res.ErrorMsg);
                    }
                }).fail(function () {
                    toastr.error(res.ErrorMsg);
                }).always(function () {
                    setTimeout(t => {
                        $scope.disableBtn = false;
                    }, 500)
                    $scope.$digest();
                });
        }
    }
    //khởi tạo thêm dịch vụ
    $scope.initXoa = function (item) {
        SweetAlert.swal({
            title: "Xóa cơ cấu?",
            text: "Cơ cấu: " + item.TenCoCau + " sẽ được xóa!",
            type: "warning",
            showCancelButton: true,
            confirmButtonColor: "#DD6B55", confirmButtonText: "Đồng ý!",
            cancelButtonColor: "#D0D0D0", cancelButtonText: "Hủy bỏ!",
            closeOnConfirm: false,
            closeOnCancel: true
        },
            function (isConfirm) {
                if (isConfirm) {
                    CoCauFactory
                        .xoaCoCau(item)
                        .done(function (res) {
                            if (res && res.ErrorCode === 0) {
                                toastr.success(res.Message)
                                $scope.LayDSCoCau();
                            }
                            else {
                                toastr.warning(res.ErrorMsg);
                            }
                        }).fail(function () {
                            toastr.error(res.ErrorMsg);
                        }).always(function () {
                            SweetAlert.swal.close()
                            $scope.$digest();
                        });
                }
            });

    };
    $scope.initXoaModal = function (item) {
        $scope.ItemDetail = {};
        $scope.ItemDetail = JSON.parse(JSON.stringify(item));

        $('#idm_Xoa').modal('show');
    }
    $scope.XoaCoCau = function () {
        CoCauFactory
            .xoaCoCau($scope.ItemDetail)
            .done(function (res) {
                if (res && res.ErrorCode === 0) {
                    toastr.success(res.Message)
                    $('#idm_Xoa').modal('hide');
                    $scope.LayDSCoCau();
                }
                else {
                    toastr.warning(res.ErrorMsg);
                }
            }).fail(function () {
                toastr.error(res.ErrorMsg);
            }).always(function () {
                SweetAlert.swal.close()
                $scope.$digest();
            });
    }
    //#region Validate form truyền vào Id form và clear validate khi đóng form để tránh trường hợp lưu cache
    function validateForm(formElement) {
        $(formElement).validate({
            errorElement: "em",
            errorPlacement: function (error, element) {
                $(element.parent("div").addClass("form-animate-error"));
                error.appendTo(element.parent("div"));
            },
            success: function (label) {
                $(label.parent("div").removeClass("form-animate-error"));
            },
            rules: {
            },
            messages: {
            }
        });
    }
    function clearValidation(formElement) {
        var validator = $(formElement).validate();
        $('[name]', formElement).each(function () {
            validator.successList.push(this);//mark as error free
            validator.showErrors();//remove error messages if present
        });
        validator.resetForm();//remove error class on name elements and clear history
        validator.reset();//remove all error and success data
    }
    //Khi modal đóng thì clear hết validate
    $("#DetailModal").on("hidden.bs.modal", function () {
        clearValidation('#DetailForm');
    });
    //#endregion
    $scope.DoubleClick = function () {
        return;
    }
});