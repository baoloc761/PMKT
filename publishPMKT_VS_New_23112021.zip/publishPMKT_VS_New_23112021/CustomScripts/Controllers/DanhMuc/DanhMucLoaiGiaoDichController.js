﻿angular.module('AccountingApp').controller("DanhMucLoaiGiaoDichController", function ($scope, DanhMucLoaiGiaoDichFactory, SweetAlert) {
    $scope.$on('$viewContentLoaded', function () {
        $scope.GetTransactionType();
        $scope.getListMoney();
        $scope.getListSPDV();
        $scope.getListTKMD();
        $scope.rowFocus = { TransactionTypeID: 0, TransactionTypeCode: '', TransactionTypeName: '', CurrencyID: 0, CurrencyName: '', ProductServiceID: 0, ProductServiceCode: '', ProductServiceName: '', AccountNumber: '', AccountName: ''};
    });

    //Lấy tiền
    $scope.getListMoney = function (item) {
        $scope.Danhsachtienteselect = {};
        DanhMucLoaiGiaoDichFactory
            .LayDanhSachTienTeSelect(item)
            .done(function (res) {
                if (res && res.ErrorCode === 0) {
                    if (res.Data.Currencies.length > 0) {
                        $scope.Danhsachtienteselect = res.Data.Currencies;
                    }
                    else {
                        toastr.warning("Không có dữ liệu trong danh sách");
                    }
                }
                else {
                    toastr.warning(res.ErrorMsg);
                }
            }).fail(function () {
                toastr.error(res.ErrorMsg);
            }).always(function () {
                $scope.$digest();
            });
    }

    //Lấy danh mục tài khoản mặc định
    $scope.getListTKMD = function (item) {
        $scope.Danhsachtkmd = {};
        DanhMucLoaiGiaoDichFactory
            .LayDanhSanhLoaiGiaoDich(item)
            .done(function (res) {
                if (res && res.ErrorCode === 0) {
                    if (res.Data.length > 0) {
                        $scope.Danhsachtkmd = res.Data;

                    }
                    else {
                        toastr.warning("Không có dữ liệu trong danh sách");
                    }
                }
                else {
                    toastr.warning(res.ErrorMsg);
                }
            }).fail(function () {
                toastr.error(res.ErrorMsg);
            }).always(function () {
                $scope.$digest();
            });
    }



    //Lấy ma spdv
    $scope.getListSPDV = function (item) {
        $scope.Danhsachspdv = {};
        DanhMucLoaiGiaoDichFactory
            .LayDanhSanPhamDichVu(item)
            .done(function (res) {
                if (res && res.ErrorCode === 0) {
                    if (res.Data.ProductServices.length > 0) {
                        $scope.Danhsachspdv = res.Data.ProductServices;

                    }
                    else {
                        toastr.warning("Không có dữ liệu trong danh sách");
                    }
                }
                else {
                    toastr.warning(res.ErrorMsg);
                }
            }).fail(function () {
                toastr.error(res.ErrorMsg);
            }).always(function () {
                $scope.$digest();
            });
    }

    $scope.GetTransactionType = function () {
        $scope.DanhMucGiaoDich = {};
        DanhMucLoaiGiaoDichFactory
            .LayDanhMucGiaoDich()
            .done(function (res) {
                if (res && res.ErrorCode === 0) {
                    if (res.Data.TransactionTypes.length > 0) {
                        $scope.DanhMucGiaoDich = res.Data.TransactionTypes;
                        setTimeout(t => {
                            $('#datatables-example').DataTable();
                            $('#datatables-example_filter label input, #datatables-example_paginate ul').on('click', function () {
                                $scope.rowFocus = { TransactionTypeID: 0 };
                                $scope.$digest();
                            });
                        }, 100)
                    }
                    else {
                        toastr.info('Không có dữ liệu danh sách');
                    }
                }
                else {
                    toastr.warning(res.ErrorMsg);
                }
            }).fail(function () {
                toastr.error(res.ErrorMsg);
            }).always(function () {
                $scope.$digest();
            });
    }

    $scope.initThemLoaiGiaoDich = function (item) {
        $scope.ItemDetail = {
            TransactionTypeID: 0,
            TransactionTypeCode: '',
            TransactionTypeName: '',
            CurrencyID: '',
            CurrencyName: '',
            ProductServiceID: 0,
            ProductServiceCode: '',
            ProductServiceName: '',
            AccountNumber: '',
            AccountName: '',
        };
        $('#DetailModal').modal('show');

    };


    $scope.ThemGiaoDich = function () {
        $scope.disableBtn = false;
        DanhMucLoaiGiaoDichFactory
            .ThemLoaiGiaoDich($scope.ItemDetail)
            .done(function (res) {
                if (res && res.ErrorCode === 0) {
                    $('#DetailModal').modal('hide');
                    toastr.success("Thêm thành công!")
                    $scope.GetTransactionType();
                    location.reload();
                }
                else {
                    toastr.warning(res.ErrorMsg);
                }
            }).fail(function () {
                toastr.error("Lỗi hệ thống. Lấy dữ liệu thất bại", "Thông báo");
            }).always(function () {
                setTimeout(t => {
                    $scope.disableBtn = true;
                    $scope.$digest();
                }, 500)

            });
    }


    $scope.CapNhatGiaoDich = function () {
        var check = $("#DetailForm").valid();
        if (check) {
            $scope.disableBtn = false;
            DanhMucLoaiGiaoDichFactory
                .SuaLoaiGiaoDich($scope.ItemDetail)
                .done(function (res) {
                    if (res && res.ErrorCode === 0) {
                        toastr.success(res.Message)
                        $('#DetailModal').modal('hide');
                        $scope.GetTransactionType();
                    }
                    else {
                        toastr.warning(res.ErrorMsg);
                    }
                }).fail(function () {
                    toastr.error("Lỗi hệ thống. Lấy dữ liệu thất bại", "Thông báo");
                }).always(function () {
                    setTimeout(t => {
                        $scope.disableBtn = true;
                    }, 500)
                    $scope.$digest();
                });
        }
    }



    //pop sửa
    //Update Sản phẩm dịch vụ
    $scope.initCapNhapGiaoDich = function (item) {
        var Tkmacdinh = item.Account_ID;
        var Loaitien = item.CurrencyCode;
        var Spdv = item.ProductServiceCode;
        var MaloaiGD = item.TransactionTypeCode;
        var TenloaiGD = item.TransactionTypeName
        $scope.ItemDetail = {
            Account_ID: Tkmacdinh,
            CurrencyCode: Loaitien,
            ProductServiceCode: Spdv,
            TransactionTypeCode: MaloaiGD,
            TransactionTypeName: TenloaiGD,
            TransactionTypeID: item.TransactionTypeID,
            CurrencyID: item.CurrencyID,
            ProductServiceID: item.ProductServiceID
        };
        DanhMucLoaiGiaoDichFactory
        $('#DetailModal').modal('show');
    };



    //Sửa
    $scope.CapNhatGiaoDich = function () {
        var check = $("#DetailForm").valid();
        if (check) {
            DanhMucLoaiGiaoDichFactory
                .SuaLoaiGiaoDich($scope.ItemDetail)
                .done(function (res) {
                    if (res && res.ErrorCode === 0) {
                        toastr.success("Sửa thành công !")
                        $('#DetailModal').modal('hide');
                        $scope.GetTransactionType();
                        location.reload();
                    }
                    else {
                        toastr.warning(res.ErrorMsg);
                    }
                }).fail(function () {
                    toastr.error(res.ErrorMsg);
                }).always(function () {
                    setTimeout(t => {
                        $scope.disableBtn = false;
                    }, 500)
                    $scope.$digest();
                });
        }
    }

    //initXoa
    //initXoaBophan
    //khởi tạo xóa
    $scope.initXoaGiaoDich = function (item) {
        SweetAlert.swal({
            title: "Xóa doanh thu ?",
            text: "Doanh thu: " + item.TransactionTypeName + " sẽ được xóa!",
            type: "warning",
            showCancelButton: true,
            confirmButtonColor: "#DD6B55", confirmButtonText: "Đồng ý!",
            cancelButtonColor: "#D0D0D0", cancelButtonText: "Hủy bỏ!",
            closeOnConfirm: false,
            closeOnCancel: true
        },
            function (isConfirm) {
                if (isConfirm) {
                    DanhMucLoaiGiaoDichFactory
                        .XoaLoaiGiaoDich(item)
                        .done(function (res) {
                            if (res && res.ErrorCode === 0) {
                                toastr.success("Xóa thành công !")
                                $scope.GetTransactionType();
                                location.reload();
                            }
                            else {
                                toastr.warning(res.ErrorMsg);
                            }
                        }).fail(function () {
                            toastr.error("Lỗi");
                        }).always(function () {
                            SweetAlert.swal.close()
                            $scope.$digest();
                        });
                }
            });

    };

    //Xóa
    $scope.XoaDanhMucDoanhThu = function (item) {
        DanhMucLoaiGiaoDichFactory
            .XoaLoaiGiaoDich(item.TransactionTypeID)
            .done(function (res) {
                if (res && res.ErrorCode === 0) {
                    toastr.success(res.Message)
                    $('#idm_Xoa').modal('hide');
                    $scope.GetTransactionType();
                }
                else {
                    toastr.warning(res.ErrorMsg);
                }
            }).fail(function () {
                toastr.error(res.ErrorMsg);
            }).always(function () {
                SweetAlert.swal.close()
                $scope.$digest();
            });
    }

   
});