﻿angular.module('AccountingApp').controller("DanhmucbophanController", function ($scope, DanhmucbophanFactory, SweetAlert) {
    $scope.$on('$viewContentLoaded', function () {
        $scope.getdanhBophan();
        $scope.rowFocus = { DepartmentID: 0, CustomerCode:'', CustomerName:'', DepartmentCode:'', DepartmentName:'' };

    });

 $scope.selectRow = function (item) {
        $scope.rowFocus = item;
    }



 $scope.initThem = function (item) {
        $scope.ItemDetail = {
            DepartmentID: 0,
            CustomerCode: '',
            CustomerName: '',
            DeparmentCode: '',
            DepartmentName: ''
        };
        $('#DetailModal').modal('show');
        //Validate form
     validateForm("#DetailForm")
    };

    $scope.selectRow = function (item) {
        $scope.rowFocus = item;
    }

    //initXoa
    //initXoaBophan
 //khởi tạo xóa
    $scope.initXoaBophan = function (item) {
        SweetAlert.swal({
            title: "Xóa bộ phận ?",
            text: "Bộ phận: " + item.DepartmentName + " sẽ được xóa!",
            type: "warning",
            showCancelButton: true,
            confirmButtonColor: "#DD6B55", confirmButtonText: "Đồng ý!",
            cancelButtonColor: "#D0D0D0", cancelButtonText: "Hủy bỏ!",
            closeOnConfirm: false,
            closeOnCancel: true
        },
            function (isConfirm) {
                if (isConfirm) {
                    DanhmucbophanFactory
                        .XoaPhongBan(item)
                        .done(function (res) {
                            if (res && res.ErrorCode === 0) {
                                    toastr.success("Xóa thành công !")
                                $scope.getdanhBophan();
                            }
                            else {
                                toastr.warning(res.ErrorMsg);
                            }
                        }).fail(function () {
                            toastr.error("Lỗi");
                        }).always(function () {
                            SweetAlert.swal.close()
                            $scope.$digest();
                        });
                }
            });

    };
    //Xóa
    $scope.Xoabophan = function (item) {
        DanhmucbophanFactory
            .XoaPhongBan(item.DepartmentID)
            .done(function (res) {
                if (res && res.ErrorCode === 0) {
                    toastr.success(res.Message)
                    $('#idm_Xoa').modal('hide');
                    $scope.getdanhBophan();
                    location.reload();
                }
                else {
                    toastr.warning(res.ErrorMsg);
                }
            }).fail(function () {
                toastr.error(res.ErrorMsg);
            }).always(function () {
                SweetAlert.swal.close()
                $scope.$digest();
            });
    }
    $scope.getdanhBophan = function () {
        $scope.Danhsachbophan = {};
        DanhmucbophanFactory
            .Laydanhsachbophan()
            .done(function (res) {
                if (res && res.ErrorCode === 0) {
                    
                    if (res.Data.Departments.length > 0) {
                      
                        $scope.Danhsachbophan = res.Data.Departments;

                        setTimeout(t => {


                            $('#datatables-example').DataTable();
                            $('#datatables-example_filter label input, #datatables-example_paginate ul').on('click', function () {
                                $scope.rowFocus = { DepartmentID: 0 };
                                $scope.$digest();
                            });
                            //$('#datatables-example_filter label input').click(function () {
                            //    $scope.rowFocus = { IdNhom: 0 };
                            //    $scope.$digest();
                            //});

                        }, 100)
                    }
                    else {
                        toastr.info('Không có dữ liệu danh sách');
                    }
                }
                else {
                    toastr.warning(res.ErrorMsg);
                }
            }).fail(function () {
                toastr.error(res.ErrorMsg);
            }).always(function () {
                $scope.$digest();
            });
    }
  
    $scope.ThemPhongBan = function (item) {
        $scope.Danhsachbophan = {};
        DanhmucbophanFactory
            .ThemMoiBoPhan(item)
            .done(function (res) {
                if (res && res.ErrorCode === 0) {
                     $('#DetailModal').modal('hide');
                    $scope.getdanhBophan();
                    location.reload();
                    toastr.success("Thêm thành công!")
                }
                else {
                    toastr.warning(res.ErrorMsg);
                }
            }).fail(function () {
                toastr.error(res.ErrorMsg);
            }).always(function () {
                $scope.$digest();
            });
    }
     $scope.initXoaModal = function (item) {
        $scope.ItemDetail = {};
        $scope.ItemDetail = JSON.parse(JSON.stringify(item));

        $('#idm_Xoa').modal('show');
    }


    $scope.initCapNhapPhongBan = function (item) {
        var MaBoPhan = item.DepartmentCode;
        var TenBoPhan = item.DepartmentName;
        $scope.ItemDetail = {
            DepartmentCode: MaBoPhan,
            DepartmentName: TenBoPhan,
            DepartmentID: item.DepartmentID
        };
        //$scope.ItemDetail = item;
        DanhmucbophanFactory
        $('#DetailModal').modal('show');
    };

    //cập nhật
    $scope.CapNhatDanhSach = function () {
        var check = $("#DetailForm").valid();
        if (check) {
            DanhmucbophanFactory
                .CapNhatPhongBan($scope.ItemDetail)
                .done(function (res) {
                    if (res && res.ErrorCode === 0) {
                        toastr.success("Sửa thành công !")
                        $('#DetailModal').modal('hide');
                        $scope.getdanhBophan();
                        location.reload();
                    }
                    else {
                        toastr.warning(res.ErrorMsg);
                    }
                }).fail(function () {
                    toastr.error(res.ErrorMsg);
                }).always(function () {
                    setTimeout(t => {
                        $scope.disableBtn = false;
                    }, 500)
                    $scope.$digest();
                });
        }
    }
    function clearValidation(formElement) {
        var validator = $(formElement).validate();
        $('[name]', formElement).each(function () {
            validator.successList.push(this);//mark as error free
            validator.showErrors();//remove error messages if present
        });
        validator.resetForm();//remove error class on name elements and clear history
        validator.reset();//remove all error and success data
    }
    //Khi modal đóng thì clear hết validate
    $("#DetailModal").on("hidden.bs.modal", function () {
        clearValidation('#DetailForm');
    });
    //#endregion
    $scope.DoubleClick = function () {
        return;
    }
});