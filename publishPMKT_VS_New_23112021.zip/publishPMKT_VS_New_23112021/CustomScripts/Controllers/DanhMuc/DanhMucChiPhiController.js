﻿angular.module('AccountingApp').controller("DanhMucChiPhiController", function ($scope, DanhMucChiPhiFactory, SweetAlert) {
    $scope.$on('$viewContentLoaded', function () {
        $scope.GetCostAll();
        $scope.getListMaThue();
        $scope.getListSPDV();
        $scope.rowFocus = { DepartmentID: 0, CustomerCode: '', CustomerName: '', DepartmentCode: '', DepartmentName: '' };
    });

    $scope.selectRow = function (item) {
        $scope.rowFocus = item;
    }
   
    //pop sửa
    //Update Sản phẩm dịch vụ
    $scope.initCapNhapChiPhi = function (item) {
        var Makhoanchi = item.CostCode;
        var Tenkhoanchi = item.CostName;
        var Spdv = item.ProductServiceName;
        var Muchigiatri = item.CostFix;
        var Muchiphantram = item.CostPercent;
        var Mathue = item.TaxCode;
        var Tenthue = item.TaxName;
        var Mucthue = item.TaxValue;
        var Ngayapdung = new Date();
        $scope.ItemDetail = {
            CostCode: Makhoanchi,
            CostName: Tenkhoanchi,
            ProductServiceName: Spdv,
            CostFix: Muchigiatri,
            CostPercent: Muchiphantram,
            TaxCode: Mathue,
            TaxName: Tenthue,
            TaxValue: Mucthue,
            AppliedDate: Ngayapdung,
            CostID: item.CostID,
            ProductServiceID: item.ProductServiceID,
            TaxID: item.TaxID
        };
        DanhMucChiPhiFactory
        //$('#DetailModal').modal('show');
    };

    $scope.initThemChiPhi = function (item) {
        $scope.ItemDetail = {
            CostID: 0,
            CostCode: '',
            CostName: '',
            ProductServiceID: 0,
            ProductServiceCode: '',
            ProductServiceName: '',
            CostFix: '',
            CostPercent: '',
            TaxID: 0,
            TaxCode: '',
            TaxName: '',
            TaxType: 0,
            TaxValue: '',
            AppliedDate: ''
        };
        $('#DetailModal').modal('show');
        //Validate form
        //validateForm("#DetailForm")
    };

    $scope.selectRow = function (item) {
        $scope.rowFocus = item;
    }




    $scope.GetCostAll = function () {
        $scope.DanhMucChiPhi = {};
        DanhMucChiPhiFactory
            .LayDanhMucChiPhi()
            .done(function (res) {
                if (res && res.ErrorCode === 0) {
                    if (res.Data.Costs.length > 0) {
                        $scope.DanhMucChiPhi = res.Data.Costs;
                        setTimeout(t => {
                            $('#datatables-example').DataTable();
                            $('#datatables-example_filter label input, #datatables-example_paginate ul').on('click', function () {
                                $scope.rowFocus = { CostID: 0 };
                                $scope.$digest();
                            });
                        }, 100)
                    }
                    else {
                        toastr.info('Không có dữ liệu danh sách');
                    }
                }
                else {
                    toastr.warning(res.ErrorMsg);
                }
            }).fail(function () {
                toastr.error(res.ErrorMsg);
            }).always(function () {
                $scope.$digest();
            });
    }
    //Lấy ma spdv
    $scope.getListSPDV = function (item) {
        $scope.Danhsachspdv = {};
        DanhMucChiPhiFactory
            .LayDanhSanPhamDichVu(item)
            .done(function (res) {
                if (res && res.ErrorCode === 0) {
                    if (res.Data.ProductServices.length > 0) {
                        $scope.Danhsachspdv = res.Data.ProductServices;

                    }
                    else {
                        toastr.warning("Không có dữ liệu trong danh sách");
                    }
                }
                else {
                    toastr.warning(res.ErrorMsg);
                }
            }).fail(function () {
                toastr.error(res.ErrorMsg);
            }).always(function () {
                $scope.$digest();
            });
    }


    //Lấy ma thue
    $scope.getListMaThue = function (item) {
        $scope.Danhsachmathue = {};
        DanhMucChiPhiFactory
            .LayDanhSachMaThue(item)
            .done(function (res) {
                if (res && res.ErrorCode === 0) {
                    if (res.Data.Taxs.length > 0) {
                        $scope.Danhsachmathue = res.Data.Taxs;

                    }
                    else {
                        toastr.warning("Không có dữ liệu trong danh sách");
                    }
                }
                else {
                    toastr.warning(res.ErrorMsg);
                }
            }).fail(function () {
                toastr.error(res.ErrorMsg);
            }).always(function () {
                $scope.$digest();
            });
    }
    //thêm
    $scope.ThemChiPhi = function (item) {
        $scope.DanhMucChiPhi = {};
        DanhMucChiPhiFactory
            .ThemChiPhi(item)
            .done(function (res) {
                if (res && res.ErrorCode === 0) {
                    $('#DetailModal').modal('hide');
                    $scope.GetCostAll();
                    location.reload();
                    toastr.success("Thêm thành công!")
                }
                else {
                    toastr.warning(res.ErrorMsg);
                }
            }).fail(function () {
                toastr.error(res.ErrorMsg);
            }).always(function () {
                $scope.$digest();
            });
    }

    //Sửa
    $scope.CapNhatChiPhi = function () {
        var check = $("#DetailForm").valid();
        if (check) {
            DanhMucChiPhiFactory
                .CapNhatChiPhi($scope.ItemDetail)
                .done(function (res) {
                    if (res && res.ErrorCode === 0) {
                        toastr.success("Sửa thành công !")
                        $('#DetailModal').modal('hide');
                        $scope.GetCostAll();
                        location.reload();
                    }
                    else {
                        toastr.warning(res.ErrorMsg);
                    }
                }).fail(function () {
                    toastr.error(res.ErrorMsg);
                }).always(function () {
                    setTimeout(t => {
                        $scope.disableBtn = false;
                    }, 500)
                    $scope.$digest();
                });
        }
    }

    //initXoa
    //initXoaBophan
    //khởi tạo xóa
    $scope.initXoaChiTiet = function (item) {
        SweetAlert.swal({
            title: "Xóa chi tiết ?",
            text: "Chi tiết: " + item.CostName + " sẽ được xóa!",
            type: "warning",
            showCancelButton: true,
            confirmButtonColor: "#DD6B55", confirmButtonText: "Đồng ý!",
            cancelButtonColor: "#D0D0D0", cancelButtonText: "Hủy bỏ!",
            closeOnConfirm: false,
            closeOnCancel: true
        },
            function (isConfirm) {
                if (isConfirm) {
                    DanhMucChiPhiFactory
                        .XoaChiPhi(item)
                        .done(function (res) {
                            if (res && res.ErrorCode === 0) {
                                toastr.success("Xóa thành công !")
                                $scope.GetCostAll();
                                location.reload();
                            }
                            else {
                                toastr.warning(res.ErrorMsg);
                            }
                        }).fail(function () {
                            toastr.error("Lỗi");
                        }).always(function () {
                            SweetAlert.swal.close()
                            $scope.$digest();
                        });
                }
            });

    };

    //Xóa
    $scope.XoaDanhMucChiTiet = function (item) {
        DanhMucChiPhiFactory
            .XoaChiPhi(item.CostID)
            .done(function (res) {
                if (res && res.ErrorCode === 0) {
                    toastr.success(res.Message)
                    $('#idm_Xoa').modal('hide');
                    $scope.GetCostAll();
                }
                else {
                    toastr.warning(res.ErrorMsg);
                }
            }).fail(function () {
                toastr.error(res.ErrorMsg);
            }).always(function () {
                SweetAlert.swal.close()
                $scope.$digest();
            });
    }
   
});