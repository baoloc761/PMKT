﻿angular.module('AccountingApp').controller("DanhMucNhanVienController", function ($scope, DanhMucNhanVienFactory, SweetAlert) {
    $scope.$on('$viewContentLoaded', function () {
        $scope.GetEmployees();
        $scope.getMaBoPhan();
        $scope.rowFocus = { DepartmentID: 0, DepartmentName: '', DepartmentCode: '', EmployeeID: 0, EmployeeName: '', EmployeeCode: '', BirthDay: '', Phone: '', Email: '', IDNumber: '', Address: '', TaxCode: '' };
    });
    $scope.selectRow = function (item) {
        $scope.rowFocus = item;
    }

    //change select Mã bộ phận
    $scope.DicAccount = {};
    $scope.MaBoPhan = function () {
        if ($scope.selectedItem) {
            if ($scope.DicAccount[$scope.selectedItem])
                $scope.department_name = $scope.DicAccount[$scope.selectedItem].DepartmentName;
            else $scope.department_name = 'Không có dữ liệu liên quan';
        }
        else {
            $scope.department_name = '';
        }
    }
    $scope.selectedItem = '';
    $scope.department_name = '';
   

    //Lấy danh mục nhân viên
    $scope.GetEmployees = function () {
        $scope.DanhMucNhanVien = {};
        $scope.DicAccount = {};
        DanhMucNhanVienFactory
            .LayDanhMucNhanVien()
            .done(function (res) {
                if (res && res.ErrorCode === 0) {
                    if (res.Data.Employees.length > 0) {
                      
                        //for (var i = 0; i < res.Data.Employees.length; i++) {
                        //    var itemCurr = res.Data.Employees[i];
                        //    $scope.DicAccount[itemCurr.DepartmentCode] = itemCurr;
                        //}
                        $scope.DanhMucNhanVien = res.Data.Employees;

                        setTimeout(t => {
                            $('#datatables-example').DataTable();
                            $('#datatables-example_filter label input, #datatables-example_paginate ul').on('click', function () {
                                $scope.rowFocus = { EmployeeID: 0 };
                                $scope.$digest();
                            });
                        }, 100)
                    }
                    else {
                        toastr.warning("Không có dữ liệu trong danh sách");
                    }
                }
                else {
                    toastr.warning(res.ErrorMsg);
                }
            }).fail(function () {
                toastr.error(res.ErrorMsg);
            }).always(function () {
                $scope.$digest();
            });
    }
    //Lấy mã bộ phận
    $scope.getMaBoPhan = function (item) {
        $scope.Danhsachmabophan = {};
        DanhMucNhanVienFactory
            .LayDanhMaBoPhanSelect(item)
            .done(function (res) {
                if (res && res.ErrorCode === 0) {
                    if (res.Data.Departments.length > 0) {
                        $scope.Danhsachmabophan = res.Data.Departments;

                    }
                    else {
                        toastr.warning("Không có dữ liệu trong danh sách");
                    }
                }
                else {
                    toastr.warning(res.ErrorMsg);
                }
            }).fail(function () {
                toastr.error(res.ErrorMsg);
            }).always(function () {
                $scope.$digest();
            });
    }
    //Thêm popup nhân viên
    $scope.initThemNhanVien = function (item) {
        $scope.ItemDetail = {
            DepartmentID: 0,
            EmployeeID: 0,
            EmployeeCode: '',
            EmployeeName: '',
            DepartmentName: '',
            DepartmentCode: '',
            BirthDay: '',
            Phone: '',
            Email: '',
            IDNumber: '',
            Address: '',
            TaxCode: ''
        };
        $('#DetailModal').modal('show');
        //Validate form
        //validateForm("#DetailForm")
    };
    //Thêm nhân viên
    $scope.ThemMoiNhanVien= function (item) {
        $scope.Danhsachnhanvien = {};
        DanhMucNhanVienFactory
            .ThemMoiNhanVien(item)
            .done(function (res) {
                if (res && res.ErrorCode === 0) {
                    toastr.success("Thêm thành công!")
                    $('#DetailModal').modal('hide');
                    $scope.GetEmployees();
                    location.reload();
                }
                else {
                    toastr.warning(res.ErrorMsg);
                }
            }).fail(function () {
                toastr.error(res.ErrorMsg);
            }).always(function () {
                $scope.$digest();
            });
    }

    //khởi tạo xóa
    $scope.initXoaNhanvien = function (item) {
        SweetAlert.swal({
            title: "Xóa nhân viên ?",
            text: "Nhân viên: " + item.EmployeeName + " sẽ được xóa!",
            type: "warning",
            showCancelButton: true,
            confirmButtonColor: "#DD6B55", confirmButtonText: "Đồng ý",
            cancelButtonColor: "#D0D0D0", cancelButtonText: "Hủy bỏ",
            closeOnConfirm: false,
            closeOnCancel: true
        },
            function (isConfirm) {
                if (isConfirm) {
                    DanhMucNhanVienFactory
                        .XoaDichNhanvien(item)
                        .done(function (res) {
                            if (res && res.ErrorCode === 0) {
                                toastr.success("Xóa thành công !")
                                $scope.GetEmployees();
                                location.reload();
                            }
                            else {
                                toastr.warning(res.ErrorMsg);
                            }
                        }).fail(function () {
                            toastr.error("Lỗi");
                        }).always(function () {
                            SweetAlert.swal.close()
                            $scope.$digest();
                        });
                }
            });

    };

    //Xóa
    $scope.XoaSanNhanVien = function (item) {
        DanhMucNhanVienFactory
            .XoaDichNhanvien(item.EmployeeID)
            .done(function (res) {
                if (res && res.ErrorCode === 0) {
                    toastr.success(res.Message)
                    $('#idm_Xoa').modal('hide')
                    $scope.GetEmployees();
                }
                else {
                    toastr.warning(res.ErrorMsg);
                }
            }).fail(function () {
                toastr.error(res.ErrorMsg);
            }).always(function () {
                SweetAlert.swal.close()
                $scope.$digest();
            });
    }

    //Update Sản phẩm dịch vụ
    $scope.initCapNhapNhanVien = function (item) {
        var Mabophan = item.DepartmentCode;
        var Manhanvien = item.EmployeeCode;
        var Tennhanvien = item.EmployeeName;
        var Ngaysinh = new Date();
        var Sodienthoai = item.Phone;
        var Email = item.Email;
        var IDNumber = item.IDNumber;
        var Diachi = item.Address;
        var MST = item.TaxCode;
        $scope.ItemDetail = {
            DepartmentCode: Mabophan,
            EmployeeCode: Manhanvien,
            EmployeeName: Tennhanvien,
            BirthDay: Ngaysinh,
            Phone: Sodienthoai,
            Email: Email,
            IDNumber: IDNumber,
            Address: Diachi,
            TaxCode: MST,
            DepartmentID: item.DepartmentID,
            EmployeeID: item.EmployeeID
        };
        DanhMucNhanVienFactory
        $('#DetailModal').modal('show');
    };
    //cập nhật Sản phẩm dịch vụ
    $scope.CapNhatNhanVien = function () {
        var check = $("#DetailForm").valid();
        if (check) {
            DanhMucNhanVienFactory
                .CapNhatNhanVien($scope.ItemDetail)
                .done(function (res) {
                    if (res && res.ErrorCode === 0) {
                        toastr.success("Sửa thành công !")
                        $('#DetailModal').modal('hide');
                        $scope.GetEmployees();
                        location.reload();
                    }
                    else {
                        toastr.warning(res.ErrorMsg);
                    }
                }).fail(function () {
                    toastr.error(res.ErrorMsg);
                }).always(function () {
                    setTimeout(t => {
                        $scope.disableBtn = false;
                    }, 500)
                    $scope.$digest();
                });
        }
    }


    function clearValidation(formElement) {
        var validator = $(formElement).validate();
        $('[name]', formElement).each(function () {
            validator.successList.push(this);//mark as error free
            validator.showErrors();//remove error messages if present
        });
        validator.resetForm();//remove error class on name elements and clear history
        validator.reset();//remove all error and success data
    }
    //Khi modal đóng thì clear hết validate
    $("#DetailModal").on("hidden.bs.modal", function () {
        clearValidation('#DetailForm');
    });
    //#endregion
    $scope.DoubleClick = function () {
        return;
    }

});