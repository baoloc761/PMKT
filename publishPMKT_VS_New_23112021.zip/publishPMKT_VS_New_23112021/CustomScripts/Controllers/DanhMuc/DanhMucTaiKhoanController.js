﻿angular.module('AccountingApp').controller("DanhMucTaiKhoanController", function ($scope, DanhMucTaiKhoanFactory, SweetAlert) {
    $scope.$on('$viewContentLoaded', function () {
        $scope.getdanhsachtaikhoan();

    });

    //danh tài khoản
    $scope.getdanhsachtaikhoan = function () {
        $scope.Danhsachtaikhoan = [];
        DanhMucTaiKhoanFactory
            .LayDanhMucGiaoDich()
            .done(function (res) {
                if (res && res.ErrorCode === 0) {
                    if (res.Data.length > 0) {
                        $scope.Danhsachtaikhoan = res.Data;
                        setTimeout(t => {
                            $('#datatables-example').DataTable();
                            $('#datatables-example_filter label input, #datatables-example_paginate ul').on('click', function () {
                                $scope.rowFocus = { AccountLevel: 0 };
                                $scope.$digest();
                            });
                        }, 100)
                    }
                    else {
                        toastr.info('Không có dữ liệu danh sách');
                    }
                }
                else {
                    toastr.warning(res.ErrorMsg);
                }
            }).fail(function () {
                toastr.error(res.ErrorMsg);
            }).always(function () {
                $scope.$digest();
            });
    }
});