﻿angular.module('AccountingApp').controller("NguoiDungController", function ($scope, NguoiDungFactory, NhomNguoiDungFactory , SweetAlert, $compile, $element) {
    $scope.$on('$viewContentLoaded', function () {
        $scope.LayDSNguoiDung();
        $scope.disableBtn = false;
        $scope.rowFocus = { Id:0};
        //setTimeout(t => {

        //}, 3000)
    });
    $scope.outTable = function () {
        $scope.rowFocus = { Id: 0 };
    }
    $scope.selectRow = function (item) {
        $scope.rowFocus = item;
    }
    //lấy danh sách  người dùng
    $scope.LayDSNguoiDung = function (type = 0) {
        debugger;
        $scope.DSNguoiDung = [];
        $scope.rowFocus = { Id: 0 };
        NguoiDungFactory
            .layDSNguoiDung()
            .done(function (res) {
                if (res && res.ErrorCode === 0) {
                    if (res.Data.length > 0) {
                        $scope.DSNguoiDung = res.Data;
                        if (type === 1) //Làm mới danh sách
                        {
                            toastr.success("Danh sách đã được làm mới!");
                        }
                        setTimeout(t => {

                            //$('#datatables-example').DataTable({
                            //    dom: "Bfrltip",
                            //    ajax: {
                            //        url: '.....'
                            //    },
                            //    pageLength: 0, Config page
                            //    lengthMenu: [0, 5, 10, 20, 50, 100, 200, 500],
                            //});
                            $('#datatables-example').DataTable();
                            $('#datatables-example_filter label input, #datatables-example_paginate ul').on('click', function () {
                                $scope.rowFocus = { Id: 0 };
                                $scope.$digest();
                            });
                            //$('#datatables-example_filter label input').click(function () {
                            //    $scope.rowFocus = { Id: 0 };
                            //    $scope.$digest();
                            //});
                           
                        }, 100)


                    }
                    else {
                        toastr.info('Không có dữ liệu');
                    }
                }
                else {
                    toastr.warning(res.ErrorMsg);
                }
            }).fail(function () {
                toastr.error(res.ErrorMsg);
            }).always(function () {
                $scope.$digest();
            });
    };
    $scope.layDSNhomNguoiDung = function () {
        NhomNguoiDungFactory
            .layDSNhomNguoiDung()
            .done(function (res) {
                if (res && res.ErrorCode === 0) {
                    if (res.Data.length > 0) {
                        $scope.DSNhomNguoiDung = res.Data;
                    }
                    else {
                        toastr.info('Không có dữ liệu nhóm người dùng');
                    }
                }
                else {
                    toastr.warning(res.ErrorMsg);
                }
            }).fail(function () {
                toastr.error(res.ErrorMsg);
            }).always(function () {
                $scope.$digest();
            });
    }
    //khởi tạo thêm  người dùng
    $scope.initThem = function (item) {
        $scope.ItemDetail = {
            Id: 0,
            TenNguoiDung: '',
            MatKhau: '',
            MatKhauNhapLai: '',
            IdNhomNguoiDung: '0',
            HoTenDem: '',
            Ten: '',
            DiaChi: '',
            Fax: '',
            SoDienThoai: '',
            Email: '',
            MaSoThue: '',
            TenNganHang: '',
            SoTKNganHang: '',
            ChucVu: '',
        };
        $scope.layDSNhomNguoiDung();
        $('#DetailModal').modal('show');
        //Validate form
        validateFormAdd("#DetailForm")
        $('.mask-phone').mask('000-000-0000');
    };
    
    $scope.ThemNguoiDung = function () {
        var check = $("#DetailForm").valid();
        if (check) {
            if ($scope.ItemDetail.IdNhomNguoiDung === '0') {
                toastr.warning("Vui lòng chọn nhóm người dùng");
                return;
            }
            $scope.disableBtn = true;
            NguoiDungFactory
                .themNguoiDung($scope.ItemDetail)
                .done(function (res) {
                    if (res && res.ErrorCode === 0) {
                        toastr.success(res.Message)
                        $('#DetailModal').modal('hide');
                        $scope.LayDSNguoiDung();
                        //Validate form
                        // validateForm("#DetailForm")
                    }
                    else {
                        toastr.warning(res.ErrorMsg);
                    }
                }).fail(function () {
                    toastr.error(res.ErrorMsg);
                }).always(function () {
                    setTimeout(t => {
                        $scope.disableBtn = false;
                        $scope.$digest();
                    }, 500)
                    
                });
        }
    }
    //khởi tạo sửa  người dùng
    $scope.initCapNhap = function (item) {
        $scope.layDSNhomNguoiDung();
        $scope.ItemDetail = {};
        $scope.TenNguoiDung = item.TenNguoiDung;
        $scope.HoVaTen = item.HoVaTen;
       
        NguoiDungFactory
            .layNguoiDungBangId(item)
            .done(function (res) {
                if (res && res.ErrorCode === 0) {

                    $scope.ItemDetail = res.Data;
                    $scope.ItemDetail.IdNhomNguoiDung = "" + $scope.ItemDetail.IdNhomNguoiDung;
                    $('#DetailModal').modal('show');
                    //Validate form
                    //$("#validate_TenNguoiDung").prop('disabled', true);
                    validateFormEdit("#DetailForm")
                    $('.mask-phone').mask('000-000-0000');
                }
                else {
                    toastr.warning(res.ErrorMsg);
                }
            }).fail(function () {
                toastr.error(res.ErrorMsg);
            }).always(function () {
                $scope.$digest();
            });
    };
    $scope.CapNhatNguoiDung = function () {
        var check = $("#DetailForm").valid();
        if (check) {
            //$.blockUI({
            //    target: "#DetailModal",
            //    message: "Đang lưu vui lòng đợi...",
            //});
            $scope.disableBtn = true;
            NguoiDungFactory
                .capNhatNguoiDung($scope.ItemDetail)
                .done(function (res) {
                    if (res && res.ErrorCode === 0) {

                        toastr.success(res.Message)
                        $('#DetailModal').modal('hide');
                        $scope.LayDSNguoiDung();
                        //Validate form
                        // validateForm("#DetailForm")
                    }
                    else {
                        toastr.warning(res.ErrorMsg);
                    }
                }).fail(function () {
                    toastr.error(res.ErrorMsg);
                }).always(function () {
                    // $.unblockUI("#DetailModal");
                    setTimeout(t => {
                        $scope.disableBtn = false;

                    }, 500)
                    $scope.$digest();
                });
        }
    }
    //khởi tạo thêm  người dùng
    $scope.initXoa = function (item) {
        SweetAlert.swal({
            title: "Xóa  người dùng?",
            text: "Người dùng: <b>" + item.TenNguoiDung + " - " + item.HoVaTen + " </b> sẽ được xóa!",
            type: "warning",
            showCancelButton: true,
            confirmButtonColor: "#DD6B55", confirmButtonText: "Đồng ý!",
            cancelButtonColor: "#D0D0D0", cancelButtonText: "Hủy bỏ!",
            closeOnConfirm: false,
            closeOnCancel: true,
            html: true
        },
            function (isConfirm) {
                if (isConfirm) {
                    NguoiDungFactory
                        .xoaNguoiDung(item)
                        .done(function (res) {
                            if (res && res.ErrorCode === 0) {
                                toastr.success(res.Message)
                                $scope.LayDSNguoiDung();
                            }
                            else {
                                toastr.warning(res.ErrorMsg);
                            }
                        }).fail(function () {
                            toastr.error(res.ErrorMsg);
                        }).always(function () {
                            SweetAlert.swal.close()
                            $scope.$digest();
                        });

                }// else {
                //    SweetAlert.swal("Hủy bỏ", "", "error");
                //}
            });

    };
    $scope.initXoaModal = function (item) {
        $scope.ItemDetail = {};
        $scope.ItemDetail = JSON.parse(JSON.stringify(item));

        $('#idm_Xoa').modal('show');
    }
    $scope.XoaNguoiDung = function () {
        NguoiDungFactory
            .xoaNguoiDung($scope.ItemDetail)
            .done(function (res) {
                if (res && res.ErrorCode === 0) {
                    //SweetAlert.swal("Đã xóa  người dùng!", "", "success", 5000);

                    toastr.success(res.Message)
                    $('#idm_Xoa').modal('hide');
                    $scope.LayDSNguoiDung();
                }
                else {
                    toastr.warning(res.ErrorMsg);
                }
            }).fail(function () {
                toastr.error(res.ErrorMsg);
            }).always(function () {
                SweetAlert.swal.close()
                $scope.$digest();
            });
    }
    $scope.initKhoa = function (item) {
        SweetAlert.swal({
            title: "Khóa người dùng?",
            text: "Người dùng: <b>" + item.TenNguoiDung + " - " + item.HoVaTen + " </b> sẽ bị khóa!",
            type: "warning",
            showCancelButton: true,
            confirmButtonColor: "#DD6B55", confirmButtonText: "Đồng ý!",
            cancelButtonColor: "#D0D0D0", cancelButtonText: "Hủy bỏ!",
            closeOnConfirm: false,
            closeOnCancel: true,
            html: true
        },
            function (isConfirm) {
                if (isConfirm) {
                    NguoiDungFactory
                        .khoaNguoiDung(item)
                        .done(function (res) {
                            if (res && res.ErrorCode === 0) {
                                toastr.success(res.Message)
                                $scope.LayDSNguoiDung();
                            }
                            else {
                                toastr.warning(res.ErrorMsg);
                            }
                        }).fail(function () {
                            toastr.error(res.ErrorMsg);
                        }).always(function () {
                            SweetAlert.swal.close()
                            $scope.$digest();
                        });

                }
            });
    };
    $scope.initMoKhoa = function (item) {
        SweetAlert.swal({
            title: "Mở khóa người dùng?",
            text: "Người dùng: <b>" + item.TenNguoiDung + " - " + item.HoVaTen + " </b> sẽ được mở khóa!",
            type: "warning",
            showCancelButton: true,
            confirmButtonColor: "#DD6B55", confirmButtonText: "Đồng ý!",
            cancelButtonColor: "#D0D0D0", cancelButtonText: "Hủy bỏ!",
            closeOnConfirm: false,
            closeOnCancel: true,
            html: true
        },
            function (isConfirm) {
                if (isConfirm) {
                    NguoiDungFactory
                        .moKhoaNguoiDung(item)
                        .done(function (res) {
                            if (res && res.ErrorCode === 0) {
                                toastr.success(res.Message)
                                $scope.LayDSNguoiDung();
                            }
                            else {
                                toastr.warning(res.ErrorMsg);
                            }
                        }).fail(function () {
                            toastr.error(res.ErrorMsg);
                        }).always(function () {
                            SweetAlert.swal.close()
                            $scope.$digest();
                        });

                }
            });
    };
    //#region Validate form truyền vào Id form và clear validate khi đóng form để tránh trường hợp lưu cache
    function validateFormAdd(formElement) {
        
        $(formElement).validate({
            errorElement: "em",
            errorPlacement: function (error, element) {
                $(element.parent("div").addClass("form-animate-error"));
                error.appendTo(element.parent("div"));
            },
            success: function (label) {
                $(label.parent("div").removeClass("form-animate-error"));
            },
            rules: {
                validate_TenNguoiDung: "required",
                validate_HoTenDem: "required",
                validate_Ten: "required",
                validate_IdNhomNguoiDung: "required",
                validate_password: {
                    required: true,
                    minlength: 5
                },
                validate_confirm_password: {
                    required: true,
                    minlength: 5,
                    equalTo: "#validate_password"
                },
                validate_email: {
                    //required: true,
                    email: true
                },
                //validate_agree: "required"
            },
            messages: {
                validate_TenNguoiDung: "Vui lòng nhập tên đăng nhập",
                validate_HoTenDem: "Vui lòng nhập họ và tên đệm người dùng",
                validate_Ten: "Vui lòng nhập tên người dùng",
                
                validate_password: {
                    required: "Vui lòng nhập mật khẩu",
                    minlength: "Mật khẩu của bạn phải dài hơn 5 ký tự"
                },
                validate_confirm_password: {
                    required: "Vui lòng nhập lại mật khẩu",
                    minlength: "Mật khẩu của bạn phải dài hơn 5 ký tự",
                    equalTo: "Mật khẩu không trùng khớp"
                },
                validate_email: "Vui lòng nhập email",
                validate_IdNhomNguoiDung: "Vui lòng chọn nhóm người dùng",
                //validate_agree: "Please accept our policy"
            }
        });
    }
    function validateFormEdit(formElement) {

        $(formElement).validate({
            errorElement: "em",
            errorPlacement: function (error, element) {
                $(element.parent("div").addClass("form-animate-error"));
                error.appendTo(element.parent("div"));
            },
            success: function (label) {
                $(label.parent("div").removeClass("form-animate-error"));
            },
            rules: {
                validate_TenNguoiDung: "required",
                validate_HoTenDem: "required",
                validate_Ten: "required",
                validate_IdNhomNguoiDung: "required",
                validate_email: {
                    email: true
                },
            },
            messages: {
                validate_TenNguoiDung: "Vui lòng nhập tên đăng nhập",
                validate_HoTenDem: "Vui lòng nhập họ và tên đệm người dùng",
                validate_Ten: "Vui lòng nhập tên người dùng",
                validate_email: "Vui lòng nhập email",
                validate_IdNhomNguoiDung: "Vui lòng chọn nhóm người dùng",
            }
        });
    }
    function clearValidation(formElement) {
        //Internal $.validator is exposed through $(form).validate()
        var validator = $(formElement).validate();
        //Iterate through named elements inside of the form, and mark them as error free
        $('[name]', formElement).each(function () {
            validator.successList.push(this);//mark as error free
            validator.showErrors();//remove error messages if present
        });
        validator.resetForm();//remove error class on name elements and clear history
        validator.reset();//remove all error and success data
    }
    //Khi modal đóng thì clear hết validate
    $("#DetailModal").on("hidden.bs.modal", function () {
        clearValidation('#DetailForm');

    });
    //#endregion
    $scope.DoubleClick = function () {
        return;
    }
});