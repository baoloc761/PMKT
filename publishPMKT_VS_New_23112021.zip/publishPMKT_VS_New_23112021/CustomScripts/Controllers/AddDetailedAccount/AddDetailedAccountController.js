﻿angular.module('AccountingApp').controller("AddDetailedAccountController", function ($scope, AddDetailsAccountFactory, SweetAlert) {
    $scope.$on('$viewContentLoaded', function () {
        $scope.getListSPDV();
        $scope.getListAccountNumberName();
        $scope.getListDoiTac();
        $scope.getListDanhMuc();
        $scope.getListNoiBo();
        $scope.getdanhSachTKCap2();
        $scope.ThemTaiKhoanCap2();
    });

    //Lấy ma spdv
    $scope.getListSPDV = function (item) {
        $scope.Danhsachspdv = {};
        AddDetailsAccountFactory
            .LayDanhSanPhamDichVu(item)
            .done(function (res) {
                if (res && res.ErrorCode === 0) {
                    if (res.Data.ProductServices.length > 0) {
                        $scope.Danhsachspdv = res.Data.ProductServices;

                    }
                    else {
                        toastr.warning("Không có dữ liệu trong danh sách");
                    }
                }
                else {
                    toastr.warning(res.ErrorMsg);
                }
            }).fail(function () {
                toastr.error(res.ErrorMsg);
            }).always(function () {
                $scope.$digest();
            });
    }
    
    $scope.ItemDetail = {
        Account_ID: 0,
        selectedItem: '',
        AccountLevel: 0,
        CagegoryId: 0,
        ServiceID: 0,
        SubCategoryId: 0,
        //ServiceID: 0,
        PartnerID: 0,
        PartnerOrEmployee: 0,
        PartnerOrEmpoyeeID: 0,
        AccountNumber: '',
        Account_Type: '',
        AccountName: '',
        Sotaikhoan: '',
        Taikhoantienmat: '',
        Account_Level: ''
    };
    $scope.ThemTaiKhoanCap2 = function () {
        debugger
        //$scope.danhSachTKCap2 = [];
        AddDetailsAccountFactory
            .ThemMoiTaiKhoanLV2($scope.ItemDetail)
            .done(function (res) {
                if (res && res.ErrorCode === 0) {
                   
                    toastr.success("Lưu thành công!")
                    $scope.getdanhSachTKCap2();
                }
                else {
                    toastr.warning(res.ErrorMsg);
                }
            }).fail(function () {
                toastr.error("Lỗi hệ thống. Lấy dữ liệu thất bại", "Thông báo");
            }).always(function () {
                setTimeout(t => {
                    $scope.disableBtn = true;
                    $scope.$digest();
                }, 500)

            });
    }

    //Lấy tên tk
    $scope.getListAccountNumberName = function (ItemDetail) {
        $scope.ItemDetail.AccountName = {};
        $scope.ItemDetail.AccountNumber = {};
        $scope.Captkmo = {};
        AddDetailsAccountFactory
            .GetlistAccountNameNumber(ItemDetail)
            .done(function (res) {
                if (res && res.ErrorCode === 0) {
                    if (res.Data.AccountName.length > 0 || res.Data.AccountNumber.length > 0 || res.Data.AccountLevel.length > 0) {
                        $scope.ItemDetail.AccountName = res.Data.AccountName;
                        $scope.ItemDetail.AccountNumber = res.Data.AccountNumber;
                        $scope.Captkmo = res.Data.AccountLevel
                    }
                    else {
                        toastr.warning("Không có dữ liệu trong danh sách");
                    }


                }
                else {
                    toastr.warning(res.ErrorMsg);
                }
            }).fail(function () {
                toastr.error(res.ErrorMsg);
            }).always(function () {
                $scope.$digest();
            });
    }

    //Lấy doi tac
    $scope.getListDoiTac = function (item) {
        $scope.Danhsachdoitac = {};
        AddDetailsAccountFactory
            .LayDanhSachDoiTac(item)
            .done(function (res) {
                if (res && res.ErrorCode === 0) {
                    if (res.Data.Partners.length > 0) {
                        $scope.Danhsachdoitac = res.Data.Partners;

                    }
                    else {
                        toastr.warning("Không có dữ liệu trong danh sách");
                    }
                }
                else {
                    toastr.warning(res.ErrorMsg);
                }
            }).fail(function () {
                toastr.error(res.ErrorMsg);
            }).always(function () {
                $scope.$digest();
            });
    }


   
    //Lấy doi tac
    $scope.getListDanhMuc = function (item) {
        $scope.Danhsachdanhmuc = {};
        AddDetailsAccountFactory
            .LayDanhSachDanhMuc(item)
            .done(function (res) {
                if (res && res.ErrorCode === 0) {
                    if (res.Data.length > 0) {
                        $scope.Danhsachdanhmuc = res.Data;

                    }
                    else {
                        toastr.warning("Không có dữ liệu trong danh sách");
                    }
                }
                else {
                    toastr.warning(res.ErrorMsg);
                }
            }).fail(function () {
                toastr.error(res.ErrorMsg);
            }).always(function () {
                $scope.$digest();
            });
    }

    //Lấy nội bộ
    $scope.getListNoiBo = function (item) {
        $scope.Danhsachnoibo = {};
        AddDetailsAccountFactory
            .LayDanhSachNoiBo(item)
            .done(function (res) {
                if (res && res.ErrorCode === 0) {
                    if (res.Data.Employees.length > 0) {
                        $scope.Danhsachnoibo = res.Data.Employees;

                    }
                    else {
                        toastr.warning("Không có dữ liệu trong danh sách");
                    }
                }
                else {
                    toastr.warning(res.ErrorMsg);
                }
            }).fail(function () {
                toastr.error(res.ErrorMsg);
            }).always(function () {
                $scope.$digest();
            });
    }

    // on - change tài khoản
    $scope.DicAccount = {};
    $scope.update = function (ItemDetail) {
        if ($scope.ItemDetail.Account_ID) {
            if ($scope.DicAccount[$scope.ItemDetail.Account_ID])
                $scope.ItemDetail.currency_monney = $scope.DicAccount[$scope.ItemDetail.Account_ID].Currency_Name;
            $scope.ItemDetail.acc_Type = $scope.DicAccount[$scope.ItemDetail.Account_ID].Check_Account_Type;
        }
        else {
            $scope.currency_monney = '';
            $scope.account_name = '';
        }
    }
    $scope.Account_ID = '';
    $scope.currency_monney = '';
    $scope.account_name = '';
    $scope.date_now = new Date();
    $scope.account_number = '';
    $scope.acc_Type = '';
    $scope.Taikhoantienmat = '';

    $scope.getdanhSachTKCap2 = function () {
        $scope.danhSachTKCap2 = [];
        $scope.DicAccount = {};
        AddDetailsAccountFactory
            .GetlistAccount()
            .done(function (res) {
                if (res && res.ErrorCode === 0) {
                    if (res.Data.length > 0) {
                        for (var i = 0; i < res.Data.length; i++) {
                            var itemCurr = res.Data[i];
                            $scope.DicAccount[itemCurr.Account_ID] = itemCurr;
                        }
                        $scope.danhSachTKCap2 = res.Data;
                    }
                    else {
                        toastr.info('Không có dữ liệu danh sách cấp 2');
                    }
                }
                else {
                    toastr.warning(res.ErrorMsg);
                }
            }).fail(function () {
                toastr.error(res.ErrorMsg);
            }).always(function () {
                $scope.$digest();
            });
    }
   
   
});