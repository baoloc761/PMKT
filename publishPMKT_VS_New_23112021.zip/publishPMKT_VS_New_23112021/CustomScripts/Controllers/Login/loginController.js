﻿angular.module('AccountingApp').controller("loginAngularController", function ($scope) {
    $scope.attendance = {
        value: true
    };

    $scope.LoginBtn = function () {
        debugger
        var stObject = {
            UserName: $scope.userName,
            PassWord: $scope.passWord
        };
        var response = $http({
            method: 'POST',
            url: 'Login/LoginForm',
            data: JSON.stringify(stObject),
            dataType: 'json',
            contentType: 'application/json; charset=utf-8'
        });
        if (response && response.ErrorCode === 0) {
            $location.path('/trang-chu');
        }
        else {
            toastr["warning"](_res.ErrorMsg, "Thông báo");
        }
    }
});