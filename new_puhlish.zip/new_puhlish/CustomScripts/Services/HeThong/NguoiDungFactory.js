﻿(function () {
    angular.module('AccountingApp')
        .factory('NguoiDungFactory', NguoiDungFactory); //tao factory cho module chinh
    NguoiDungFactory.$inject = ['$http']; //tim service http vao
    function NguoiDungFactory($http) {
        var service = {
            //mang cac ham tra ve
            layDSNguoiDung: layDSNguoiDung,
            layNguoiDungBangId: layNguoiDungBangId,
            themNguoiDung: themNguoiDung,
            capNhatNguoiDung: capNhatNguoiDung,
            xoaNguoiDung: xoaNguoiDung,
            khoaNguoiDung: khoaNguoiDung,
            moKhoaNguoiDung: moKhoaNguoiDung
        };
        return service
        //#region Danh mục người dùng
        //GET LIST NguoiDung
        function layDSNguoiDung () {
            var response = $.ajax({
                type: 'POST',
                url: 'NguoiDung/DanhSachNguoiDung',
                dataType: 'json',
                contentType: 'application/json; charset=utf-8'
            });
            return response;
        }

        //GET NguoiDung
        function layNguoiDungBangId (nnd) {
            var response = $.ajax({
                type: 'GET',
                url: 'NguoiDung/ChiTietNguoiDung',
                data: {
                    IdNguoiDung: nnd.Id
                },
                dataType: 'json',
                contentType: 'application/json; charset=utf-8'
            });
            return response;
        }

        //INSERT NguoiDung
        function themNguoiDung (NguoiDung) {
            var response = $.ajax({
                type: 'POST',
                url: 'NguoiDung/ThemMoiNguoiDung',
                data: JSON.stringify(NguoiDung),
                dataType: 'json',
                contentType: 'application/json; charset=utf-8'
            });
            return response;
        }

        //UPDATE NguoiDung
        function capNhatNguoiDung (NguoiDung) {
            var response = $.ajax({
                type: 'POST',
                url: 'NguoiDung/SuaNguoiDung',
                data: JSON.stringify(NguoiDung),
                dataType: 'json',
                contentType: 'application/json; charset=utf-8'
            });
            return response;
        }

        //DELETE NguoiDung
        function xoaNguoiDung (nnd) {
            var response = $.ajax({
                type: 'GET',
                url: 'NguoiDung/XoaNguoiDung',
                data: {
                    IdNguoiDung: nnd.Id
                },
                dataType: 'json',
                contentType: 'application/json; charset=utf-8'
            });
            return response;
        }
        function khoaNguoiDung(nnd) {
            var response = $.ajax({
                type: 'GET',
                url: 'NguoiDung/KhoaNguoiDung',
                data: {
                    IdNguoiDung: nnd.Id
                },
                dataType: 'json',
                contentType: 'application/json; charset=utf-8'
            });
            return response;
        }
        function moKhoaNguoiDung(nnd) {
            var response = $.ajax({
                type: 'GET',
                url: 'NguoiDung/MoKhoaNguoiDung',
                data: {
                    IdNguoiDung: nnd.Id
                },
                dataType: 'json',
                contentType: 'application/json; charset=utf-8'
            });
            return response;
        }
    //#endregion
    }
})();