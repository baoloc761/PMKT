﻿(function () {
    angular.module('AccountingApp')
        .factory('NhomNguoiDungFactory', NhomNguoiDungFactory); //tao factory cho module chinh
    NhomNguoiDungFactory.$inject = ['$http']; //tim service http vao
    function NhomNguoiDungFactory($http) {
        var service = {
            //mang cac ham tra ve
            layDSNhomNguoiDung: layDSNhomNguoiDung,
            layNhomNguoiDungBangId: layNhomNguoiDungBangId,
            themNhomNguoiDung: themNhomNguoiDung,
            capNhatNhomNguoiDung: capNhatNhomNguoiDung,
            xoaNhomNguoiDung: xoaNhomNguoiDung,
            danhSachQuyen: danhSachQuyen,
            phanQuyenNhomNguoiDung: phanQuyenNhomNguoiDung
        };
        return service
        //#region Danh mục Nhóm người dùng
        //GET LIST NhomNguoiDung
       function layDSNhomNguoiDung () {
            var response = $.ajax({
                type: 'POST',
                url: 'NhomNguoiDung/DanhSachNhomNguoiDung',
                dataType: 'json',
                contentType: 'application/json; charset=utf-8'
            });
            return response;
        }

        //GET NhomNguoiDung
       function layNhomNguoiDungBangId (nnd) {
            var response = $.ajax({
                type: 'GET',
                url: 'NhomNguoiDung/ChiTietNhomNguoiDung',
                data: {
                    IdNhomNguoiDung: nnd.IdNhom
                },
                dataType: 'json',
                contentType: 'application/json; charset=utf-8'
            });
            return response;
        }

        //INSERT NhomNguoiDung
       function themNhomNguoiDung (NhomNguoiDung) {
            var response = $.ajax({
                type: 'POST',
                url: 'NhomNguoiDung/ThemMoiNhomNguoiDung',
                data: JSON.stringify(NhomNguoiDung),
                dataType: 'json',
                contentType: 'application/json; charset=utf-8'
            });
            return response;
        }

        //UPDATE NhomNguoiDung
       function capNhatNhomNguoiDung (NhomNguoiDung) {
            var response = $.ajax({
                type: 'POST',
                url: 'NhomNguoiDung/SuaNhomNguoiDung',
                data: JSON.stringify(NhomNguoiDung),
                dataType: 'json',
                contentType: 'application/json; charset=utf-8'
            });
            return response;
        }

        //DELETE NhomNguoiDung
       function xoaNhomNguoiDung (nnd) {
            var response = $.ajax({
                type: 'GET',
                url: 'NhomNguoiDung/XoaNhomNguoiDung',
                data: {
                    IdNhomNguoiDung: nnd.IdNhom
                },
                dataType: 'json',
                contentType: 'application/json; charset=utf-8'
            });
            return response;
        }
        //Danh sách phân quyền NhomNguoiDung
       function danhSachQuyen (nnd) {
            var response = $.ajax({
                type: 'GET',
                url: 'NhomNguoiDung/LayDanhSachQuyen',
                data: {
                    idnhom: nnd.IdNhom
                },
                dataType: 'json',
                contentType: 'application/json; charset=utf-8'
            });
            return response;
        }
        //PhanQuyen NhomNguoiDung
       function phanQuyenNhomNguoiDung (DanhSachPhanQuyen) {
            var response = $.ajax({
                type: 'POST',
                url: 'NhomNguoiDung/PhanQuyenNhomNguoiDung',
                data: JSON.stringify(DanhSachPhanQuyen),
                dataType: 'json',
                contentType: 'application/json; charset=utf-8'
            });
            return response;
        }
    //#endregion
    }
})();