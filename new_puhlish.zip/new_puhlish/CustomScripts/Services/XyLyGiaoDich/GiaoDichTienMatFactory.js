﻿(function () {
    angular.module('AccountingApp')
        .factory('GiaoDichTienMatFactory', GiaoDichTienMatFactory); //tao factory cho module chinh
    GiaoDichTienMatFactory.$inject = ['$http']; //tim service http vao
    function GiaoDichTienMatFactory($http) {
        var service = {
            ListTransaction: ListTransaction,
            LayDanhMucGiaoDich: LayDanhMucGiaoDich,
            ThemMoiGiaoDichTienMat: ThemMoiGiaoDichTienMat,
            LayDanhSanPhamDichVu: LayDanhSanPhamDichVu,
            LayTien: LayTien,
            LayDanhMucDoiTac: LayDanhMucDoiTac,
            Account2To5: Account2To5,
            Updatetransaction: Updatetransaction,
            Debit2t85: Debit2t85,
            DeleteTranSaction: DeleteTranSaction
        };
        return service
        
        //GET LIST Dan sách bộ phận
        function LayDanhMucDoiTac() {
            var bodyRequest = {
                data: {
                    SearchValue: '',
                    Page: 1,
                    RowPerPage: 10,
                    SortType: ''
                }
            };
            var response = $.ajax({
                type: 'POST',
                url: '/GiaoDichTienMat/Getpartner',
                dataType: 'json',
                contentType: 'application/json; charset=utf-8',
                data: JSON.stringify(bodyRequest),
            });
            return response;
        }
        //Xóa loại giao dich
        function DeleteTranSaction(item) {
            var data = item
            var response = $.ajax({
                type: 'POST',
                url: '/GiaoDichTienMat/DeleteTransaction',
                dataType: 'json',
                contentType: 'application/json; charset=utf-8',
                data: JSON.stringify(data),
            });
            return response;
        }
        //GET LIST Transaction
        function ListTransaction() {
            debugger
            var dt = {
                FromDate: $("#fromdate").val(),
                ToDate: $("#todate").val(),
                TranID: $("#TranID").val()
            };
            var response = $.ajax({
                type: 'POST',
                url: '/GiaoDichTienMat/GetTransaction',
                dataType: 'json',
                contentType: 'application/json; charset=utf-8',
                data: JSON.stringify(dt),
            });
            return response;
        }
       
        //GET LIST Dan sách bộ phận
        function LayDanhMucGiaoDich() {
            var bodyRequest = {
                data: {
                    SearchValue: '',
                    Page: 1,
                    RowPerPage: 10,
                    SortType: ''
                }
            };
            var response = $.ajax({
                type: 'POST',
                url: '/GiaoDichTienMat/GetAllTransactionType',
                dataType: 'json',
                contentType: 'application/json; charset=utf-8',
                data: JSON.stringify(bodyRequest),
            });
            return response;
        }
       
        //thêm
        function ThemMoiGiaoDichTienMat(item) {
            var data = item;
            var response = $.ajax({
                type: 'POST',
                url: 'GiaoDichTienMat/AddNewTransaction',
                dataType: 'json',
                contentType: 'application/json; charset=utf-8',
                data: JSON.stringify(data),
            });
            return response;
        }

        //GET SP/DV
        function LayDanhSanPhamDichVu(item) {
            var data = item;
            var response = $.ajax({
                type: 'POST',
                url: '/GiaoDichTienMat/GetSPDV',
                dataType: 'json',
                contentType: 'application/json; charset=utf-8',
                data: JSON.stringify(data),

            });
            return response;
        }
        //Debit
        function Debit2t85(item) {
            var data = item;
            var response = $.ajax({
                type: 'POST',
                url: '/GiaoDichTienMat/AccountDebit2to5',
                dataType: 'json',
                contentType: 'application/json; charset=utf-8',
                data: JSON.stringify(data),

            });
            return response;
        }
        //Lấy tài khoản có và tài khoản nợ
        //GET SP/DV
        function Account2To5(item) {
            var data = item;
            var response = $.ajax({
                type: 'POST',
                url: '/GiaoDichTienMat/GetAccount2To5',
                dataType: 'json',
                contentType: 'application/json; charset=utf-8',
                data: JSON.stringify(data),

            });
            return response;
        }
        //GET SP/DV
        function LayTien(item) {
            var data = item;
            var response = $.ajax({
                type: 'POST',
                url: '/GiaoDichTienMat/GetMoney',
                dataType: 'json',
                contentType: 'application/json; charset=utf-8',
                data: JSON.stringify(data),

            });
            return response;
        }

        //cập nhật transacton
        function Updatetransaction(item) {
            var data = item;
            var response = $.ajax({
                type: 'POST',
                url: '/GiaoDichTienMat/UpdateTransaction',
                dataType: 'json',
                contentType: 'application/json; charset=utf-8',
                data: JSON.stringify(data),

            });
            return response;
        }
       
    }
})();