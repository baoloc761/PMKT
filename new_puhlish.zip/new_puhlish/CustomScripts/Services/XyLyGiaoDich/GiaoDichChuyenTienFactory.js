﻿(function () {
    angular.module('AccountingApp')
        .factory('GiaoDichChuyenTienFactory', GiaoDichChuyenTienFactory); //tao factory cho module chinh
    GiaoDichChuyenTienFactory.$inject = ['$http']; //tim service http vao
    function GiaoDichChuyenTienFactory($http) {
        var service = {
            ListTransaction: ListTransaction,
            LayDanhMucGiaoDich: LayDanhMucGiaoDich,
            ThemMoiGiaoDichTienMat: ThemMoiGiaoDichTienMat,
            LayDanhSanPhamDichVu: LayDanhSanPhamDichVu,
            LayTien: LayTien,
            LayDanhMucDoiTac: LayDanhMucDoiTac,
            Account2To5: Account2To5,
            Updatetransaction: Updatetransaction,
            Debit2t85: Debit2t85,
            GetlistAccount: GetlistAccount,
            DeleteTranSaction: DeleteTranSaction
        };
        return service
      
        //GET LIST Dan sách bộ phận
        function LayDanhMucDoiTac() {
            var bodyRequest = {
                data: {
                    SearchValue: '',
                    Page: 1,
                    RowPerPage: 10,
                    SortType: ''
                }
            };
            var response = $.ajax({
                type: 'POST',
                url: '/GiaoDichChuyenTien/Getpartner',
                dataType: 'json',
                contentType: 'application/json; charset=utf-8',
                data: JSON.stringify(bodyRequest),
            });
            return response;
        }
        //Xóa loại giao dich
        function DeleteTranSaction(item) {
            var data = item
            var response = $.ajax({
                type: 'POST',
                url: '/GiaoDichChuyenTien/DeleteTransaction',
                dataType: 'json',
                contentType: 'application/json; charset=utf-8',
                data: JSON.stringify(data),
            });
            return response;
        }
        //GET LIST Transaction
        function ListTransaction() {
            debugger
            var dt = {
                FromDate: $("#fromdate").val(),
                ToDate: $("#todate").val(),
                TranID: $("#TranID").val()
            };
            var response = $.ajax({
                type: 'POST',
                url: '/GiaoDichChuyenTien/GetTransaction',
                dataType: 'json',
                contentType: 'application/json; charset=utf-8',
                data: JSON.stringify(dt),
            });
            return response;
        }

        //GET LIST Dan sách bộ phận
        function LayDanhMucGiaoDich() {
            var bodyRequest = {
                data: {
                    SearchValue: '',
                    Page: 1,
                    RowPerPage: 10,
                    SortType: ''
                }
            };
            var response = $.ajax({
                type: 'POST',
                url: '/GiaoDichChuyenTien/GetAllTransactionType',
                dataType: 'json',
                contentType: 'application/json; charset=utf-8',
                data: JSON.stringify(bodyRequest),
            });
            return response;
        }

        //thêm
        function ThemMoiGiaoDichTienMat(item) {
            var data = item;
            var response = $.ajax({
                type: 'POST',
                url: 'GiaoDichChuyenTien/AddNewTransaction',
                dataType: 'json',
                contentType: 'application/json; charset=utf-8',
                data: JSON.stringify(data),
            });
            return response;
        }

        //GET SP/DV
        function LayDanhSanPhamDichVu(item) {
            var data = item;
            var response = $.ajax({
                type: 'POST',
                url: '/GiaoDichChuyenTien/GetSPDV',
                dataType: 'json',
                contentType: 'application/json; charset=utf-8',
                data: JSON.stringify(data),

            });
            return response;
        }
        //Debit
        function Debit2t85(item) {
            var data = item;
            var response = $.ajax({
                type: 'POST',
                url: '/GiaoDichChuyenTien/AccountDebit2to5',
                dataType: 'json',
                contentType: 'application/json; charset=utf-8',
                data: JSON.stringify(data),

            });
            return response;
        }
        //Lấy tài khoản có và tài khoản nợ
        //GET SP/DV
        function Account2To5(item) {
            var data = item;
            var response = $.ajax({
                type: 'POST',
                url: '/GiaoDichChuyenTien/GetAccount2To5',
                dataType: 'json',
                contentType: 'application/json; charset=utf-8',
                data: JSON.stringify(data),

            });
            return response;
        }
      
        //GET SP/DV
        function LayTien(item) {
            var data = item;
            var response = $.ajax({
                type: 'POST',
                url: '/GiaoDichChuyenTien/GetMoney',
                dataType: 'json',
                contentType: 'application/json; charset=utf-8',
                data: JSON.stringify(data),

            });
            return response;
        }
      
        //cập nhật transacton
        function Updatetransaction(item) {
            var data = item;
            var response = $.ajax({
                type: 'POST',
                url: '/GiaoDichChuyenTien/UpdateTransaction',
                dataType: 'json',
                contentType: 'application/json; charset=utf-8',
                data: JSON.stringify(data),

            });
            return response;
        }
        function GetlistAccount() {
            var bodyRequest = {
                data: {
                    LevelAccount: 2,
                }
            };
            var response =
                $.ajax({
                    type: 'POST',
                    url: '/GiaoDichChuyenTien/AccountGetLevel',
                    data: JSON.stringify(bodyRequest),
                    dataType: 'json',
                    contentType: 'application/json; charset=utf-8',
                });
            return response;
        }
      
    }
})();