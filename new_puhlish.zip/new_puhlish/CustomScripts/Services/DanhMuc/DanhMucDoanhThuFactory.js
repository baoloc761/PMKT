﻿(function () {
    angular.module('AccountingApp')
        .factory('DanhMucDoanhThuFactory', DanhMucDoanhThuFactory); //tao factory cho module chinh
    DanhMucDoanhThuFactory.$inject = ['$http']; //tim service http vao
    function DanhMucDoanhThuFactory($http) {
        var service = {
            LayDanhMucDoanhThu: LayDanhMucDoanhThu,
            ThemDoanhThu: ThemDoanhThu,
            LayDanhSachMaThue: LayDanhSachMaThue,
            LayDanhSanPhamDichVu: LayDanhSanPhamDichVu,
            CapNhatDoanhThu: CapNhatDoanhThu,
            XoaDoanhThu: XoaDoanhThu
        };
        return service
       
    }

    //GET SP/DV
    function LayDanhSanPhamDichVu(item) {
        var data = item;
        var response = $.ajax({
            type: 'POST',
            url: '/DanhMucDoanhThu/GetSPDV',
            dataType: 'json',
            contentType: 'application/json; charset=utf-8',
            data: JSON.stringify(data),

        });
        return response;
    }


    //GET Mã thuế
    function LayDanhSachMaThue(item) {
        var data = item;
        var response = $.ajax({
            type: 'POST',
            url: '/DanhMucDoanhThu/GetTaxList',
            dataType: 'json',
            contentType: 'application/json; charset=utf-8',
            data: JSON.stringify(data),

        });
        return response;
    }


    //GET LIST chi phi
    function LayDanhMucDoanhThu() {
        var bodyRequest = {
            data: {
                SearchValue: '',
                Page: 1,
                RowPerPage: 10,
                SortType: ''
            }
        };
        var response = $.ajax({
            type: 'POST',
            url: '/DanhMucDoanhThu/GetAllRevenue',
            dataType: 'json',
            contentType: 'application/json; charset=utf-8',
            data: JSON.stringify(bodyRequest),
        });
        return response;
    }
    //Thêm doanh thu
    function ThemDoanhThu(item) {
        var data = item;
        var response = $.ajax({
            type: 'POST',
            url: '/DanhMucDoanhThu/AddRevenue',
            dataType: 'json',
            contentType: 'application/json; charset=utf-8',
            data: JSON.stringify(data),
        });
        return response;
    }
    //UPDATE 
    function CapNhatDoanhThu(item) {
        var data = item;
        var response = $.ajax({
            type: 'POST',
            url: 'DanhMucDoanhThu/UpdateRevenue',
            dataType: 'json',
            contentType: 'application/json; charset=utf-8',
            data: JSON.stringify(data),
        });
        return response;
    }
    //DELETE
    function XoaDoanhThu(item) {
        var data = item;
        var response = $.ajax({
            type: 'POST',
            url: 'DanhMucDoanhThu/DeleteRevenue',
            dataType: 'json',
            contentType: 'application/json; charset=utf-8',
            data: JSON.stringify(data),
        });
        return response;
    }
})();