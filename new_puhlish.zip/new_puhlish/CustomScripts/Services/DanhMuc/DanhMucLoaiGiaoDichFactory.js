﻿(function () {
    angular.module('AccountingApp')
        .factory('DanhMucLoaiGiaoDichFactory', DanhMucLoaiGiaoDichFactory); //tao factory cho module chinh
    DanhMucLoaiGiaoDichFactory.$inject = ['$http']; //tim service http vao
    function DanhMucLoaiGiaoDichFactory($http) {
        var service = {
            LayDanhMucGiaoDich: LayDanhMucGiaoDich,
            ThemLoaiGiaoDich: ThemLoaiGiaoDich,
            LayDanhSachTienTeSelect: LayDanhSachTienTeSelect,
            LayDanhSanPhamDichVu: LayDanhSanPhamDichVu,
            LayDanhSanhLoaiGiaoDich: LayDanhSanhLoaiGiaoDich,
            SuaLoaiGiaoDich: SuaLoaiGiaoDich,
            XoaLoaiGiaoDich: XoaLoaiGiaoDich
        };
        return service
        
         //GET SP/DV
        function LayDanhSanhLoaiGiaoDich(item) {
            var data = item;
            var response = $.ajax({
                type: 'POST',
                url: '/DanhMucLoaiGiaoDich/GetTKMacDinh',
                dataType: 'json',
                contentType: 'application/json; charset=utf-8',
                data: JSON.stringify(data),

            });
            return response;
        }
        
        //GET SP/DV
        function LayDanhSanPhamDichVu(item) {
            var data = item;
            var response = $.ajax({
                type: 'POST',
                url: '/DanhMucLoaiGiaoDich/GetSPDV',
                dataType: 'json',
                contentType: 'application/json; charset=utf-8',
                data: JSON.stringify(data),

            });
            return response;
        }


        //GET LIST Tiền
        function LayDanhSachTienTeSelect(item) {
            var data = item;
            var response = $.ajax({
                type: 'POST',
                url: '/DanhMucLoaiGiaoDich/GetMoney',
                dataType: 'json',
                contentType: 'application/json; charset=utf-8',
                data: JSON.stringify(data),

            });
            return response;
        }


        //GET LIST Dan sách bộ phận
        function LayDanhMucGiaoDich() {
            var bodyRequest = {
                data: {
                    SearchValue: '',
                    Page: 1,
                    RowPerPage: 10,
                    SortType: ''
                }
            };
            var response = $.ajax({
                type: 'POST',
                url: '/DanhMucLoaiGiaoDich/GetAllTransactionType',
                dataType: 'json',
                contentType: 'application/json; charset=utf-8',
                data: JSON.stringify(bodyRequest),
            });
            return response;
        }
        //Thêm loại giao dich
        function ThemLoaiGiaoDich(item) {
            var data = item
            var response = $.ajax({
                type: 'POST',
                url: '/DanhMucLoaiGiaoDich/AddTransactionType',
                dataType: 'json',
                contentType: 'application/json; charset=utf-8',
                data: JSON.stringify(data),
            });
            return response;
        }

        //Sửa loại giao dich
        function SuaLoaiGiaoDich(item) {
            var data = item
            var response = $.ajax({
                type: 'POST',
                url: '/DanhMucLoaiGiaoDich/UpdateTransactionType',
                dataType: 'json',
                contentType: 'application/json; charset=utf-8',
                data: JSON.stringify(data),
            });
            return response;
        }

        //Xóa loại giao dich
        function XoaLoaiGiaoDich(item) {
            var data = item
            var response = $.ajax({
                type: 'POST',
                url: '/DanhMucLoaiGiaoDich/DeleteTransactionType',
                dataType: 'json',
                contentType: 'application/json; charset=utf-8',
                data: JSON.stringify(data),
            });
            return response;
        }
    }
})();