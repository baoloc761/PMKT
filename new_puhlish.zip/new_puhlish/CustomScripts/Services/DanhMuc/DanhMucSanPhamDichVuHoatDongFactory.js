﻿(function () {
    angular.module('AccountingApp')
        .factory('DanhMucSanPhamDichVuHoatDongFactory', DanhMucSanPhamDichVuHoatDongFactory); //tao factory cho module chinh
    DanhMucSanPhamDichVuHoatDongFactory.$inject = ['$http']; //tim service http vao
    function DanhMucSanPhamDichVuHoatDongFactory($http) {
        var service = {
            LayDanhSachDMDVSV: LayDanhSachDMDVSV,
            ThemDichVuSP: ThemDichVuSP,
            XoaDichVuSanPham: XoaDichVuSanPham,
            CapNhatSanPhamDichVu: CapNhatSanPhamDichVu
        };
        return service
        //GET LIST Dịch vụ sản phẩm
        function LayDanhSachDMDVSV() {
            var bodyRequest = {
                data: {
                    SearchValue: '',
                    Page: 1,
                    RowPerPage: 10,
                    SortType: ''
                }
            };
            var response = $.ajax({
                type: 'POST',
                url: '/DanhMucSanPhamDichVuDuAn/GetlistProductService',
                dataType: 'json',
                contentType: 'application/json; charset=utf-8',
                data: JSON.stringify(bodyRequest),
            });
            return response;
        }
        //Thêm Dịch vụ sản phẩm
        function ThemDichVuSP(item) {
            var data = item;
            var response = $.ajax({
                type: 'POST',
                url: '/DanhMucSanPhamDichVuDuAn/AddProjectService',
                dataType: 'json',
                contentType: 'application/json; charset=utf-8',
                data: JSON.stringify(data),
            });
            return response;
        }

        //DELETE Dịch vụ sản phẩm
        function XoaDichVuSanPham(item) {
            var data = item;
            var response = $.ajax({
                type: 'POST',
                url: '/DanhMucSanPhamDichVuDuAn/DeleteProjectService',
                dataType: 'json',
                contentType: 'application/json; charset=utf-8',
                data: JSON.stringify(data),
            });
            return response;
        }

        //UPDATE Dịch vụ sản phẩm
        function CapNhatSanPhamDichVu(item) {
            var data = item;
            var response = $.ajax({
                type: 'POST',
                url: 'DanhMucSanPhamDichVuDuAn/UpdateProjectSerVice',
                dataType: 'json',
                contentType: 'application/json; charset=utf-8',
                data: JSON.stringify(data),
            });
            return response;
        }
    }
})();