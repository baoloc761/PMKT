﻿(function () {
    angular.module('AccountingApp')
        .factory('DanhmucbophanFactory', DanhmucbophanFactory); //tao factory cho module chinh
    DanhmucbophanFactory.$inject = ['$http']; //tim service http vao
    function DanhmucbophanFactory($http) {
        var service = {
            Laydanhsachbophan: Laydanhsachbophan,
            ThemMoiBoPhan: ThemMoiBoPhan,
            CapNhatPhongBan: CapNhatPhongBan,
            XoaPhongBan: XoaPhongBan
        };
        return service
        //GET LIST Dan sách bộ phận
       function Laydanhsachbophan() {
             var bodyRequest = {
                data: {
                    SearchValue: '',
                    Page: 1,
                    RowPerPage: 10,
                    SortType: ''
                }
            };
            var response = $.ajax({
                type: 'POST',
                url: '/Danhmucbophan/Getdepartment',
                dataType: 'json',
                contentType: 'application/json; charset=utf-8',
                data: JSON.stringify(bodyRequest),
            });
            return response;
        }
        function ThemMoiBoPhan(item) {
             var data = item;
            var response = $.ajax({
                type: 'POST',
                url: '/Danhmucbophan/AddNewDepartment',
                dataType: 'json',
                contentType: 'application/json; charset=utf-8',
                data: JSON.stringify(data),
            });
            return response;
        }

        //UPDATE PHÒNG BAN
        function CapNhatPhongBan(item) {
            var bodyRequest = {
                DepartmentCode: item.DepartmentCode,
                DepartmentName: item.DepartmentName,
                DepartmentID: item.DepartmentID
            };
            var response = $.ajax({
                type: 'POST',
                url: 'Danhmucbophan/UpdateDepartment',
                dataType: 'json',
                contentType: 'application/json; charset=utf-8',
                data: JSON.stringify(bodyRequest),
            });
            return response;
        }


         //DELETE XÓA PHÒNG BAN
        function XoaPhongBan(item) {
            var bodyRequest = {
               
                    DepartmentCode: item.DepartmentCode,
                DepartmentName: item.DepartmentName,
                DepartmentID: item.DepartmentID,
                    IsRemove: true
               
            };
           var response = $.ajax({
                type: 'POST',
                url: 'Danhmucbophan/DeleteDepartment',
                dataType: 'json',
               contentType: 'application/json; charset=utf-8',
               data: JSON.stringify(bodyRequest),
            });
            return response;
        }

    }
})();