﻿(function () {
    angular.module('AccountingApp')
        .factory('DanhMucChiPhiFactory', DanhMucChiPhiFactory); //tao factory cho module chinh
    DanhMucChiPhiFactory.$inject = ['$http']; //tim service http vao
    function DanhMucChiPhiFactory($http) {
        var service = {
            LayDanhMucChiPhi: LayDanhMucChiPhi,
            ThemChiPhi: ThemChiPhi,
            CapNhatChiPhi: CapNhatChiPhi,
            XoaChiPhi: XoaChiPhi,
            LayDanhSachMaThue: LayDanhSachMaThue,
            LayDanhSanPhamDichVu: LayDanhSanPhamDichVu
        };
        return service

        //GET SP/DV
        function LayDanhSanPhamDichVu(item) {
            var data = item;
            var response = $.ajax({
                type: 'POST',
                url: '/DanhMucChiPhi/GetSPDV',
                dataType: 'json',
                contentType: 'application/json; charset=utf-8',
                data: JSON.stringify(data),

            });
            return response;
        }


        //GET Mã thuế
        function LayDanhSachMaThue(item) {
            var data = item;
            var response = $.ajax({
                type: 'POST',
                url: '/DanhMucChiPhi/GetTaxList',
                dataType: 'json',
                contentType: 'application/json; charset=utf-8',
                data: JSON.stringify(data),

            });
            return response;
        }



        //GET LIST chi phi
        function LayDanhMucChiPhi() {
            var bodyRequest = {
                data: {
                    SearchValue: '',
                    Page: 1,
                    RowPerPage: 10,
                    SortType: ''
                }
            };
            var response = $.ajax({
                type: 'POST',
                url: '/DanhMucChiPhi/GetCostAll',
                dataType: 'json',
                contentType: 'application/json; charset=utf-8',
                data: JSON.stringify(bodyRequest),
            });
            return response;
        }

        //Thêm chi phí
        function ThemChiPhi(item) {
            var data = item;
            var response = $.ajax({
                type: 'POST',
                url: '/DanhMucChiPhi/AddCost',
                dataType: 'json',
                contentType: 'application/json; charset=utf-8',
                data: JSON.stringify(data),
            });
            return response;
        }
        //UPDATE 
        function CapNhatChiPhi(item) {
            var data = item;
            var response = $.ajax({
                type: 'POST',
                url: 'DanhMucChiPhi/UpdateCost',
                dataType: 'json',
                contentType: 'application/json; charset=utf-8',
                data: JSON.stringify(data),
            });
            return response;
        }
        //DELETE
        function XoaChiPhi(item) {
            var data = item;
            var response = $.ajax({
                type: 'POST',
                url: 'DanhMucChiPhi/DeleteCost',
                dataType: 'json',
                contentType: 'application/json; charset=utf-8',
                data: JSON.stringify(data),
            });
            return response;
        }
    }
})();