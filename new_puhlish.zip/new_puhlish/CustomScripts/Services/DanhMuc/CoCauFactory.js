﻿(function () {
    angular.module('AccountingApp')
        .factory('CoCauFactory', CoCauFactory); //tao factory cho module chinh
    CoCauFactory.$inject = ['$http']; //tim service http vao
    function CoCauFactory($http) {
        var service = {
            //mang cac ham tra ve
            layDSCoCau: layDSCoCau,
            layCoCauBangId: layCoCauBangId,
            themCoCau: themCoCau,
            capNhatCoCau: capNhatCoCau,
            xoaCoCau: xoaCoCau,

        };
        return service
        //GET LIST COCAU
       function layDSCoCau  () {
            var response = $.ajax({
                type: 'POST',
                url: 'CoCau/DanhSachCoCau',
                dataType: 'json',
                contentType: 'application/json; charset=utf-8'
            });
            return response;
        }

        //GET COCAU
       function layCoCauBangId  (cocau) {
            var response = $.ajax({
                type: 'GET',
                url: 'CoCau/ChiTietCoCau',
                data: {
                    IdCoCau: cocau.IdCoCau
                },
                dataType: 'json',
                contentType: 'application/json; charset=utf-8'
            });
            return response;
        }

        //INSERT COCAU
      function  themCoCau  (cocau) {
            var response = $.ajax({
                type: 'POST',
                url: 'CoCau/ThemMoiCoCau',
                data: JSON.stringify(cocau),
                dataType: 'json',
                contentType: 'application/json; charset=utf-8'
            });
            return response;
        }

        //UPDATE COCAU
       function capNhatCoCau  (cocau) {
            var response = $.ajax({
                type: 'POST',
                url: 'CoCau/SuaCoCau',
                data: JSON.stringify(cocau),
                dataType: 'json',
                contentType: 'application/json; charset=utf-8'
            });
            return response;
        }

        //DELETE COCAU
       function xoaCoCau  (cocau) {
            var response = $.ajax({
                type: 'GET',
                url: 'CoCau/XoaCoCau',
                data: {
                    IdCoCau: cocau.IdCoCau
                },
                dataType: 'json',
                contentType: 'application/json; charset=utf-8'
            });
            return response;
        }

    }
})();