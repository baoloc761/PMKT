﻿(function () {
    angular.module('AccountingApp')
        .factory('DanhMucCacLoaiThueFactory', DanhMucCacLoaiThueFactory); //tao factory cho module chinh
    DanhMucCacLoaiThueFactory.$inject = ['$http']; //tim service http vao
    function DanhMucCacLoaiThueFactory($http) {
        var service = {
            Laydanhmucloaithe: Laydanhmucloaithe,
            ThemMoiThue: ThemMoiThue,
            CapNhatThue: CapNhatThue,
            Xoathue: Xoathue,
            LayDanhSachTienTeSelect: LayDanhSachTienTeSelect
        };
        return service

        //GET LIST Tiền
        function LayDanhSachTienTeSelect(item) {
            var data = item;
            var response = $.ajax({
                type: 'POST',
                url: '/DanhMucCacLoaiThue/GetMoney',
                dataType: 'json',
                contentType: 'application/json; charset=utf-8',
                data: JSON.stringify(data),

            });
            return response;
        }


        //GET LIST ngân hàng
        //function LayDanhSachNganHang(item) {
        //    var data = item;
        //    var response = $.ajax({
        //        type: 'POST',
        //        url: '/DanhMucCacLoaiThue/GetListbank',
        //        dataType: 'json',
        //        contentType: 'application/json; charset=utf-8',
        //        data: JSON.stringify(data),

        //    });
        //    return response;
        //}

        //GET LIST danh mục các loại thuế
        function Laydanhmucloaithe() {
            var bodyRequest = {
                data: {
                    SearchValue: '',
                    Page: 1,
                    RowPerPage: 10,
                    SortType: ''
                }
            };
            var response = $.ajax({
                type: 'POST',
                url: '/DanhMucCacLoaiThue/GetAlltax',
                dataType: 'json',
                contentType: 'application/json; charset=utf-8',
                data: JSON.stringify(bodyRequest),
            });
            return response;
        }
        //Thêm tiền tệ
        function ThemMoiThue(item) {
            var data = item;
            var response = $.ajax({
                type: 'POST',
                url: '/DanhMucCacLoaiThue/AddNewTax',
                dataType: 'json',
                contentType: 'application/json; charset=utf-8',
                data: JSON.stringify(data),
            });
            return response;
        }

        //UPDATE 
        function CapNhatThue(item) {
            var data = item;
            var response = $.ajax({
                type: 'POST',
                url: 'DanhMucCacLoaiThue/UpdateTax',
                dataType: 'json',
                contentType: 'application/json; charset=utf-8',
                data: JSON.stringify(data),
            });
            return response;
        }
        //DELETE
        function Xoathue(item) {
            var data = item;
            var response = $.ajax({
                type: 'POST',
                url: 'DanhMucCacLoaiThue/DeleteTax',
                dataType: 'json',
                contentType: 'application/json; charset=utf-8',
                data: JSON.stringify(data),
            });
            return response;
        }

    }
})();