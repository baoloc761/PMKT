﻿(function () {
    angular.module('AccountingApp')
        .factory('DanhMucDoiTacFactory', DanhMucDoiTacFactory); //tao factory cho module chinh
    DanhMucDoiTacFactory.$inject = ['$http']; //tim service http vao
    function DanhMucDoiTacFactory($http) {
        var service = {
            LayDanhMucDoiTac: LayDanhMucDoiTac,
            ThemMoiDoiTac: ThemMoiDoiTac,
            CapNhatDoiTac: CapNhatDoiTac,
            XoaDoiTac: XoaDoiTac,
            LayDanhSanPhamDichVu: LayDanhSanPhamDichVu,
            LayDanhSachNganHang: LayDanhSachNganHang
        };
        return service



        //GET LIST ngân hàng
        function LayDanhSachNganHang(item) {
            var data = item;
            var response = $.ajax({
                type: 'POST',
                url: '/DanhMucDoiTac/GetListbank',
                dataType: 'json',
                contentType: 'application/json; charset=utf-8',
                data: JSON.stringify(data),

            });
            return response;
        }
        //GET SP/DV
        function LayDanhSanPhamDichVu(item) {
            var data = item;
            var response = $.ajax({
                type: 'POST',
                url: '/DanhMucDoiTac/GetSPDV',
                dataType: 'json',
                contentType: 'application/json; charset=utf-8',
                data: JSON.stringify(data),

            });
            return response;
        }

        //GET LIST Dan sách bộ phận
        function LayDanhMucDoiTac() {
            var bodyRequest = {
                data: {
                    SearchValue: '',
                    Page: 1,
                    RowPerPage: 10,
                    SortType: ''
                }
            };
            var response = $.ajax({
                type: 'POST',
                url: '/DanhMucDoiTac/Getpartner',
                dataType: 'json',
                contentType: 'application/json; charset=utf-8',
                data: JSON.stringify(bodyRequest),
            });
            return response;
        }

        //Thêm đối tác
        function ThemMoiDoiTac(item) {
            var data = item;
            var response = $.ajax({
                type: 'POST',
                url: '/DanhMucDoiTac/Addpartner',
                dataType: 'json',
                contentType: 'application/json; charset=utf-8',
                data: JSON.stringify(data),
            });
            return response;
        }
        //UPDATE 
        function CapNhatDoiTac(item) {
            var data = item;
            var response = $.ajax({
                type: 'POST',
                url: 'DanhMucDoiTac/UpdatePartner',
                dataType: 'json',
                contentType: 'application/json; charset=utf-8',
                data: JSON.stringify(data),
            });
            return response;
        }

        //DELETE
        function XoaDoiTac(item) {
            var data = item;
            var response = $.ajax({
                type: 'POST',
                url: 'DanhMucDoiTac/DeletePartner',
                dataType: 'json',
                contentType: 'application/json; charset=utf-8',
                data: JSON.stringify(data),
            });
            return response;
        }
    }
})();