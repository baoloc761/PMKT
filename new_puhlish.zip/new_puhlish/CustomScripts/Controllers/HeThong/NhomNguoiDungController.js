﻿angular.module('AccountingApp').controller("NhomNguoiDungController", function ($scope, NhomNguoiDungFactory, SweetAlert, $compile, $element) {
    $scope.$on('$viewContentLoaded', function () {
        $scope.LayDSNhomNguoiDung();
        $scope.disableBtn = false;
        $scope.rowFocus = { IdNhom:0};
        //setTimeout(t => {

        //}, 3000)
    });
    $scope.outTable = function () {
        $scope.rowFocus = { IdNhom: 0 };
    }
    $scope.selectRow = function (item) {
        $scope.rowFocus = item;
    }
    //lấy danh sách Nhóm người dùng
    $scope.LayDSNhomNguoiDung = function (type = 0) {
        $scope.DSNhomNguoiDung = [];
        $scope.rowFocus = { IdNhom: 0 };
        NhomNguoiDungFactory
            .layDSNhomNguoiDung()
            .done(function (res) {
                if (res && res.ErrorCode === 0) {
                    if (res.Data.length > 0) {
                        $scope.DSNhomNguoiDung = res.Data;
                        if (type === 1) //Làm mới danh sách
                        {
                            toastr.success("Danh sách đã được làm mới!");
                        }
                        setTimeout(t => {

                            //$('#datatables-example').DataTable({
                            //    dom: "Bfrltip",
                            //    ajax: {
                            //        url: '.....'
                            //    },
                            //    pageLength: 0, Config page
                            //    lengthMenu: [0, 5, 10, 20, 50, 100, 200, 500],
                            //});
                            $('#datatables-example').DataTable();
                            $('#datatables-example_filter label input, #datatables-example_paginate ul').on('click', function () {
                                $scope.rowFocus = { IdNhom: 0 };
                                $scope.$digest();
                            });
                            //$('#datatables-example_filter label input').click(function () {
                            //    $scope.rowFocus = { IdNhom: 0 };
                            //    $scope.$digest();
                            //});
                           
                        }, 100)


                    }
                    else {
                        toastr.info('Không có dữ liệu');
                    }
                }
                else {
                    toastr.warning(res.ErrorMsg);
                }
            }).fail(function () {
                toastr.error(res.ErrorMsg);
            }).always(function () {
                $scope.$digest();
            });
    };
    //khởi tạo thêm Nhóm người dùng
    $scope.initThem = function (item) {
        $scope.ItemDetail = {
            IdNhom: 0,
            MaNhom: '',
            TenNhom: '',
            GiaTien: 0
        };
        $('#DetailModal').modal('show');
        //Validate form
        validateForm("#DetailForm")
    };
    $scope.ThemNhomNguoiDung = function () {
        var check = $("#DetailForm").valid();
        if (check) {
            $scope.disableBtn = true;
            NhomNguoiDungFactory
                .themNhomNguoiDung($scope.ItemDetail)
                .done(function (res) {
                    if (res && res.ErrorCode === 0) {
                        toastr.success(res.Message)
                        $('#DetailModal').modal('hide');
                        $scope.LayDSNhomNguoiDung();
                        //Validate form
                        // validateForm("#DetailForm")
                    }
                    else {
                        toastr.warning(res.ErrorMsg);
                    }
                }).fail(function () {
                    toastr.error(res.ErrorMsg);
                }).always(function () {
                    setTimeout(t => {
                        $scope.disableBtn = false;
                        $scope.$digest();
                    }, 500)
                    
                });
        }
    }
    //khởi tạo sửa Nhóm người dùng
    $scope.initCapNhap = function (item) {
        $scope.ItemDetail = {};
        $scope.Ma = item.MaNhom;
        $scope.Ten = item.TenNhom;
        NhomNguoiDungFactory
            .layNhomNguoiDungBangId(item)
            .done(function (res) {
                if (res && res.ErrorCode === 0) {

                    $scope.ItemDetail = res.Data;
                    $('#DetailModal').modal('show');
                    //Validate form
                    validateForm("#DetailForm")
                }
                else {
                    toastr.warning(res.ErrorMsg);
                }
            }).fail(function () {
                toastr.error(res.ErrorMsg);
            }).always(function () {
                $scope.$digest();
            });
    };
    $scope.CapNhatNhomNguoiDung = function () {
        var check = $("#DetailForm").valid();
        if (check) {
            //$.blockUI({
            //    target: "#DetailModal",
            //    message: "Đang lưu vui lòng đợi...",
            //});
            $scope.disableBtn = true;
            NhomNguoiDungFactory
                .capNhatNhomNguoiDung($scope.ItemDetail)
                .done(function (res) {
                    if (res && res.ErrorCode === 0) {

                        toastr.success(res.Message)
                        $('#DetailModal').modal('hide');
                        $scope.LayDSNhomNguoiDung();
                        //Validate form
                        // validateForm("#DetailForm")
                    }
                    else {
                        toastr.warning(res.ErrorMsg);
                    }
                }).fail(function () {
                    toastr.error(res.ErrorMsg);
                }).always(function () {
                    // $.unblockUI("#DetailModal");
                    setTimeout(t => {
                        $scope.disableBtn = false;

                    }, 500)
                    $scope.$digest();
                });
        }
    }
    //khởi tạo thêm Nhóm người dùng
    $scope.initXoa = function (item) {
        SweetAlert.swal({
            title: "Xóa nhóm người dùng?",
            text: "Nhóm người dùng: <b>" + item.MaNhom + " - " + item.TenNhom + " </b> sẽ được xóa!",
            type: "warning",
            showCancelButton: true,
            confirmButtonColor: "#DD6B55", confirmButtonText: "Đồng ý!",
            cancelButtonColor: "#D0D0D0", cancelButtonText: "Hủy bỏ!",
            closeOnConfirm: false,
            closeOnCancel: true,
            html: true
        },
            function (isConfirm) {
                if (isConfirm) {
                    NhomNguoiDungFactory
                        .xoaNhomNguoiDung(item)
                        .done(function (res) {
                            if (res && res.ErrorCode === 0) {
                                toastr.success(res.Message)
                                $scope.LayDSNhomNguoiDung();
                            }
                            else {
                                toastr.warning(res.ErrorMsg);
                            }
                        }).fail(function () {
                            toastr.error(res.ErrorMsg);
                        }).always(function () {
                            SweetAlert.swal.close()
                            $scope.$digest();
                        });

                }// else {
                //    SweetAlert.swal("Hủy bỏ", "", "error");
                //}
            });

    };
    $scope.initXoaModal = function (item) {
        $scope.ItemDetail = {};
        $scope.ItemDetail = JSON.parse(JSON.stringify(item));

        $('#idm_Xoa').modal('show');
    }
    $scope.XoaNhomNguoiDung = function () {
        NhomNguoiDungFactory
            .xoaNhomNguoiDung($scope.ItemDetail)
            .done(function (res) {
                if (res && res.ErrorCode === 0) {
                    //SweetAlert.swal("Đã xóa Nhóm người dùng!", "", "success", 5000);

                    toastr.success(res.Message)
                    $('#idm_Xoa').modal('hide');
                    $scope.LayDSNhomNguoiDung();
                }
                else {
                    toastr.warning(res.ErrorMsg);
                }
            }).fail(function () {
                toastr.error(res.ErrorMsg);
            }).always(function () {
                SweetAlert.swal.close()
                $scope.$digest();
            });
    }
    $scope.closeModelPhanQuyen = function () {
        //$element.remove();
        ////$scope.$destroy();
        //$scope.$destroy();
        //$('#contactTypeDiv').empty()
    }
    $scope.initPhanQuyen = function (item) {
        $scope.ItemDetail = {};
        $scope.ItemDetail = JSON.parse(JSON.stringify(item));
        NhomNguoiDungFactory
            .danhSachQuyen($scope.ItemDetail)
            .done(function (res) {
                if (res && res.ErrorCode === 0) {
                    $scope.nodes = res.data

                   // toastr.success(res.Message)
                    $('#idm_PhanQuyen').modal('show');
                    $('#contactTypeDiv').empty()
                    var divElement = angular.element(document.querySelector('#contactTypeDiv'));
                    var appendHtml = $compile('<tree-view checkbox click="myClick(node)" model="nodes" show-edit="false"></tree-view>')($scope);
                    divElement.append(appendHtml);
                }
                else {
                    toastr.warning(res.ErrorMsg);
                }
            }).fail(function () {
                toastr.error(res.ErrorMsg);
            }).always(function () {
                SweetAlert.swal.close()
                $scope.$digest();
            });
       //#region code sample
        //$scope.nodes = [
        //    {
        //        id: 2, name: '1ª Habilitação', checked: true,
        //        entity: [
        //            {
        //                entidade: {
        //                    img: 'http://placehold.it/500',
        //                    obrigatorio: true
        //                }
        //            }
        //        ],

        //        children: [
        //            { id: 23, name: 'Level2 - A', checked: true },
        //            { id: 24, name: 'Level2 - B', checked: true }
        //        ]
        //    },

        //    {
        //        id: 3, name: 'Veículo', checked: true,
        //        entity: [
        //            {
        //                entidade: {
        //                    img: 'http://placehold.it/500',
        //                    obrigatorio: true
        //                }
        //            }
        //        ],

        //        children: [
        //            { id: 33, name: 'Level2 - A', checked: true },
        //            { id: 34, name: 'Level2 - B', checked: true },
        //            {
        //                id: 35, name: 'Level2 - C', checked: false, children: [
        //                    { id: 336, name: 'Level3 - A', checked: false },
        //                    {
        //                        id: 337, name: 'Level3 - B', checked: true, children: [
        //                            { id: 338, name: 'Level4 - A', checked: false }
        //                        ]
        //                    }
        //                ]
        //            }
        //        ]
        //    },
        //    {
        //        id: 4, name: 'Habilitação', checked: true,
        //        entity: [
        //            {
        //                entidade: {
        //                    img: 'http://placehold.it/500',
        //                    obrigatorio: true
        //                }
        //            }
        //        ],

        //        children: [
        //            { id: 43, name: 'Level2 - A', checked: true },
        //            { id: 44, name: 'Level2 - B', checked: true },
        //            {
        //                id: 45, name: 'Level2 - C', checked: true, children: [
        //                    { id: 446, name: 'Level3 - A', checked: false },
        //                    {
        //                        id: 447, name: 'Level3 - B', checked: false, children: [
        //                            { id: 448, name: 'Level4 - A', checked: false }
        //                        ]
        //                    }
        //                ]
        //            }
        //        ]
        //    },
        //];
        //#endregion
        
       
    }
    function GetAllChildrenChecked(node, listPhanQuyen) {
        for (var i = 0; i < node.length; i++) {
            if (node[i].children && node[i].children.length > 0) {
                GetAllChildrenChecked(node[i].children, listPhanQuyen);
            }
            else {
                if (node[i].ischecked === true) {
                    var item = {
                        IdNhom :$scope.ItemDetail.IdNhom,
                        IdQuyen: node[i].id
                    }
                    listPhanQuyen.push(item)
                }
            }
        }
    }
    $scope.PhanQuyenNhomNguoiDung = function () {
        var listPhanQuyen = [];
        GetAllChildrenChecked($scope.nodes, listPhanQuyen )
        NhomNguoiDungFactory
            .phanQuyenNhomNguoiDung(listPhanQuyen)
            .done(function (res) {
                if (res && res.ErrorCode === 0) {
                    //SweetAlert.swal("Đã xóa Nhóm người dùng!", "", "success", 5000);

                    toastr.success(res.Message)
                    $('#idm_PhanQuyen').modal('hide');
                   // $scope.LayDSNhomNguoiDung();
                }
                else {
                    toastr.warning(res.ErrorMsg);
                }
            }).fail(function () {
                toastr.error(res.ErrorMsg);
            }).always(function () {
                SweetAlert.swal.close()
                $scope.$digest();
            });
    }
    $scope.myClick = function (node) {
        console.log($scope.nodes)
        alert('Clicked [' + node.name + '] state is [' + node.checked + ']');
    };
    $scope.changeGiaTien = function (value) {
        //if (value === undefined || value === null) {
        //    $scope.ItemDetail.GiaTien = 0;
        //}
        //console.log($scope.ItemDetail.GiaTien);
    }
    //#region Validate form truyền vào Id form và clear validate khi đóng form để tránh trường hợp lưu cache
    function validateForm(formElement) {
        $(formElement).validate({
            errorElement: "em",
            errorPlacement: function (error, element) {
                $(element.parent("div").addClass("form-animate-error"));
                error.appendTo(element.parent("div"));
            },
            success: function (label) {
                $(label.parent("div").removeClass("form-animate-error"));
            },
            rules: {
                validate_MaNhom: "required",
                validate_TenNhom: "required",
                validate_GiaTien: {
                    required: true,
                    // minlength: 2,
                    // minStrict: 0
                },
                //validate_password: {
                //    required: true,
                //    minlength: 5
                //},
                //validate_confirm_password: {
                //    required: true,
                //    minlength: 5,
                //    equalTo: "#validate_password"
                //},
                //validate_email: {
                //    required: true,
                //    email: true
                //},
                //validate_agree: "required"
            },
            messages: {
                validate_MaNhom: "Vui lòng nhập mã Nhóm người dùng",
                validate_TenNhom: "Vui lòng nhập tên Nhóm người dùng",
                validate_GiaTien: {
                    required: "Vui lòng nhập giá tiền",
                    // minlength: "Your username must consist of at least 2 characters"
                    //minStrict:"Giá tiền phải lớn hơn 0"
                },
                //validate_password: {
                //    required: "Please provide a password",
                //    minlength: "Your password must be at least 5 characters long"
                //},
                //validate_confirm_password: {
                //    required: "Please provide a password",
                //    minlength: "Your password must be at least 5 characters long",
                //    equalTo: "Please enter the same password as above"
                //},
                //validate_email: "Please enter a valid email address",
                //validate_agree: "Please accept our policy"
            }
        });
    }
    function clearValidation(formElement) {
        //Internal $.validator is exposed through $(form).validate()
        var validator = $(formElement).validate();
        //Iterate through named elements inside of the form, and mark them as error free
        $('[name]', formElement).each(function () {
            validator.successList.push(this);//mark as error free
            validator.showErrors();//remove error messages if present
        });
        validator.resetForm();//remove error class on name elements and clear history
        validator.reset();//remove all error and success data
    }
    //Khi modal đóng thì clear hết validate
    $("#DetailModal").on("hidden.bs.modal", function () {
        clearValidation('#DetailForm');

    });
    //#endregion
    $scope.DoubleClick = function () {
        return;
    }
});