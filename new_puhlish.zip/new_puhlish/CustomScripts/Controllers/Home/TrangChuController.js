﻿angular.module('AccountingApp').controller('TrangChuController', ['$rootScope', '$scope'
    , function ($rootScope, $scope) {
        $scope.$on('$viewContentLoaded', function () {
           
        });
       
    }]);


