﻿angular.module('AccountingApp').controller("DanhMucTaiKhoanBankController", function ($scope, DanhMucTaiKhoanBankFactory, SweetAlert) {
    $scope.$on('$viewContentLoaded', function () {
        $scope.getAccountBankAll();
        $scope.getListBank();
        $scope.getListMoney();
        $scope.rowFocus = { BankID: 0, BankCode: '', BankName: '', BankAccountID: 0, BankAccountNumber: '', BankAccountName: '', BankAccountBranch: '', OpeningDate: '', BankAccountBalance: '', CurrencyID: 0, CurrencyName: '', BankAccountType: 0  };
    });

    $scope.selectRow = function (item) {
        $scope.rowFocus = item;
    }
   
    $scope.initThemTaiKhoanBank = function (item) {
        $scope.ItemDetail = {
            BankID: 0,
            BankCode: '',
            BankName: '',
            BankAccountID: 0,
            BankAccountNumber: '',
            BankAccountName: '',
            BankAccountBranch: '',
            OpeningDate: '',
            BankAccountBalance: '',
            CurrencyID: 0,
            CurrencyName: '',
            BankAccountType: 0
        };
        $('#DetailModal').modal('show');
        //validateForm("#DetailForm")
    };


    //Lấy ngân hàng
    $scope.getListBank = function (item) {
        $scope.Danhsachnganhang = {};
        DanhMucTaiKhoanBankFactory
            .LayDanhSachNganHang(item)
            .done(function (res) {
                if (res && res.ErrorCode === 0) {
                    if (res.Data.length > 0) {
                        $scope.Danhsachnganhang = res.Data;

                    }
                    else {
                        toastr.warning("Không có dữ liệu trong danh sách");
                    }
                }
                else {
                    toastr.warning(res.ErrorMsg);
                }
            }).fail(function () {
                toastr.error(res.ErrorMsg);
            }).always(function () {
                $scope.$digest();
            });
    }



    //Lấy tiền
    $scope.getListMoney = function (item) {
        $scope.Danhsachtienteselect = {};
        DanhMucTaiKhoanBankFactory
            .LayDanhSachTienTeSelect(item)
            .done(function (res) {
                if (res && res.ErrorCode === 0) {
                    if (res.Data.Currencies.length > 0) {
                        $scope.Danhsachtienteselect = res.Data.Currencies;
                    }
                    else {
                        toastr.warning("Không có dữ liệu trong danh sách");
                    }
                }
                else {
                    toastr.warning(res.ErrorMsg);
                }
            }).fail(function () {
                toastr.error(res.ErrorMsg);
            }).always(function () {
                $scope.$digest();
            });
    }


    //Lấy danh sách
    $scope.getAccountBankAll = function () {
        $scope.DanhsachTaikhoanbank = {};
        DanhMucTaiKhoanBankFactory
            .LayDanhMucTaiKhoanBank()
            .done(function (res) {
                if (res && res.ErrorCode === 0) {
                    if (res.Data.BankAccounts.length > 0) {
                        $scope.DanhsachTaikhoanbank = res.Data.BankAccounts;
                        setTimeout(t => {
                            $('#datatables-example').DataTable();
                            $('#datatables-example_filter label input, #datatables-example_paginate ul').on('click', function () {
                                $scope.rowFocus = { IdNhom: 0 };
                                $scope.$digest();
                            });
                        }, 100)
                    }
                    else {
                        toastr.warning("Không có dữ liệu trong danh sách");
                    }
                }
                else {
                    toastr.warning(res.ErrorMsg);
                }
            }).fail(function () {
                toastr.error(res.ErrorMsg);
            }).always(function () {
                $scope.$digest();
            });
    }

    //Popup tài khoản chi tiết (Sửa)
    $scope.initCapNhapTaiKhoanChiTiet = function (item) {
        var Mabank = item.BankCode;
        var Tenbank = item.BankName;
        var STK = item.BankAccountNumber;
        var Tentaikhoan = item.BankAccountName;
        var Chinhanh = item.BankAccountBranch;
        var Ngaymo = new Date();
        var Sodu = item.BankAccountBalance;
        var Loaitien = item.CurrencyCode;
        var Loaitaikhoan = item.BankAccTypeCheck;
        $scope.ItemDetail = {
            BankCode: Mabank,
            BankName: Tenbank,
            BankAccountNumber: STK,
            BankAccountName: Tentaikhoan,
            BankAccountBranch: Chinhanh,
            OpeningDate: Ngaymo,
            BankAccountBalance: Sodu,
            CurrencyCode: Loaitien,
            BankAccTypeCheck: Loaitaikhoan,
            BankID: item.BankID,
            BankAccountID: item.BankAccountID,
            CurrencyID: item.CurrencyID
        };
        DanhMucTaiKhoanBankFactory
        $('#DetailModal').modal('show');
    };

    //Lưu tài khoản chi tiết
    $scope.ThemTaiKhoanDanhMuc = function (item) {
        $scope.DanhsachTaikhoanbank = {};
        DanhMucTaiKhoanBankFactory
            .ThemTaiKhoanBank(item)
            .done(function (res) {
                if (res && res.ErrorCode === 0) {
                    $('#DetailModal').modal('hide');
                    toastr.success("Thêm thành công!");
                    $scope.getAccountBankAll();
                    location.reload();
                }
                else {
                    toastr.warning(res.ErrorMsg);
                }
            }).fail(function () {
                toastr.error(res.ErrorMsg);
            }).always(function () {
                $scope.$digest();
            });
    }

    


    //cập nhật
    $scope.CapNhatTaiKhoanChiTiet = function () {
        var check = $("#DetailForm").valid();
        if (check) {
            DanhMucTaiKhoanBankFactory
                .CapNhatTaiKhoanChiTiet($scope.ItemDetail)
                .done(function (res) {
                    if (res && res.ErrorCode === 0) {
                        toastr.success("Sửa thành công !")
                        $('#DetailModal').modal('hide');
                        $scope.getAccountBankAll();
                        location.reload();
                    }
                    else {
                        toastr.warning(res.ErrorMsg);
                    }
                }).fail(function () {
                    toastr.error(res.ErrorMsg);
                }).always(function () {
                    setTimeout(t => {
                        $scope.disableBtn = false;
                    }, 500)
                    $scope.$digest();
                });
        }
    }

    //khởi tạo xóa
    $scope.initTaiKhoanChiTiet = function (item) {
        SweetAlert.swal({
            title: "Xóa tài khoản chi tiết ?",
            text: "Tài khoản: " + item.BankAccountName + " sẽ được xóa!",
            type: "warning",
            showCancelButton: true,
            confirmButtonColor: "#DD6B55", confirmButtonText: "Đồng ý!",
            cancelButtonColor: "#D0D0D0", cancelButtonText: "Hủy bỏ!",
            closeOnConfirm: false,
            closeOnCancel: true
        },
            function (isConfirm) {
                if (isConfirm) {
                    DanhMucTaiKhoanBankFactory
                        .XoaTaiKhoanChiTiet(item)
                        .done(function (res) {
                            if (res && res.ErrorCode === 0) {
                                toastr.success("Xóa thành công !")
                                $scope.getAccountBankAll();
                                location.reload();
                            }
                            else {
                                toastr.warning(res.ErrorMsg);
                            }
                        }).fail(function () {
                            toastr.error("Lỗi");
                        }).always(function () {
                            SweetAlert.swal.close()
                            $scope.$digest();
                        });
                }
            });

    };
    //Xóa
    $scope.XoaTaiKhoanChiTiet = function (item) {
        DanhMucTaiKhoanBankFactory
            .XoaTaiKhoanChiTiet(item.BankAccountID)
            .done(function (res) {
                if (res && res.ErrorCode === 0) {
                    toastr.success(res.Message)
                    $('#idm_Xoa').modal('hide');
                    $scope.getAccountBankAll();
                }
                else {
                    toastr.warning(res.ErrorMsg);
                }
            }).fail(function () {
                toastr.error(res.ErrorMsg);
            }).always(function () {
                SweetAlert.swal.close()
                $scope.$digest();
            });
    }

});