﻿angular.module('AccountingApp').controller("DanhMucSanPhamDichVuHoatDongController", function ($scope, DanhMucSanPhamDichVuHoatDongFactory, SweetAlert) {
    $scope.$on('$viewContentLoaded', function () {
        $scope.getProductSerVice();
        $scope.rowFocus = { ProductServiceID: 0, ProjectID: 0, ProjectCode: '', ProductServiceCode: '',  ProductServiceName: '', ProjectName: '', BeginDate:''  };
    });

    $scope.initThemSanPhamDichVu = function (item) {
        $scope.ItemDetail = {
            ProductServiceID: 0,
            ProjectID: 0,
            ProjectCode: '',
            ProductServiceCode: '',
            ProductServiceName: '',
            ProjectName: '',
            BeginDate: ''
        };
        $('#DetailModal').modal('show');
        validateForm("#DetailForm")
    };
    $scope.selectRow = function (item) {
        $scope.rowFocus = item;
    }

   


    //Thêm Sản phẩm dịch vụ
    $scope.ThemSanPhamDichVu = function (item) {
        $scope.Danhsachsanphamdichvu = {};
        DanhMucSanPhamDichVuHoatDongFactory
            .ThemDichVuSP(item)
            .done(function (res) {
                if (res && res.ErrorCode === 0) {
                    $('#DetailModal').modal('hide');
                    $scope.getProductSerVice();
                    location.reload();
                    toastr.success("Thêm thành công!")
                }
                else {
                    toastr.warning(res.ErrorMsg);
                }
            }).fail(function () {
                toastr.error(res.ErrorMsg);
            }).always(function () {
                $scope.$digest();
            });
    }


    //Lấy danh sách bộ phận
    $scope.getProductSerVice = function () {
        $scope.DanhsachDMDVSV = {};
        DanhMucSanPhamDichVuHoatDongFactory
            .LayDanhSachDMDVSV()
            .done(function (res) {
                if (res && res.ErrorCode === 0) {
                    if (res.Data.ProductServices.length > 0) {
                        $scope.DanhsachDMDVSV = res.Data.ProductServices;
                        setTimeout(t => {

                        
                            $('#datatables-example').DataTable();
                            $('#datatables-example_filter label input, #datatables-example_paginate ul').on('click', function () {
                                $scope.rowFocus = { IdNhom: 0 };
                                $scope.$digest();
                            });
                            //$('#datatables-example_filter label input').click(function () {
                            //    $scope.rowFocus = { IdNhom: 0 };
                            //    $scope.$digest();
                            //});

                        }, 100)
                    }
                    else {
                        toastr.warning("Không có dữ liệu trong danh sách");
                    }
                }
                else {
                    toastr.warning(res.ErrorMsg);
                }
            }).fail(function () {
                toastr.error(res.ErrorMsg);
            }).always(function () {
                $scope.$digest();
            });
    }
    //khởi tạo xóa
    $scope.initXoaDichVuSanPham = function (item) {
        SweetAlert.swal({
            title: "Xóa Dự Án ?",
            text: "Dịch vụ sản phẩm: " + item.ProductServiceName + " sẽ được xóa!",
            type: "warning",
            showCancelButton: true,
            confirmButtonColor: "#DD6B55", confirmButtonText: "Đồng ý!",
            cancelButtonColor: "#D0D0D0", cancelButtonText: "Hủy bỏ!",
            closeOnConfirm: false,
            closeOnCancel: true
        },
            function (isConfirm) {
                if (isConfirm) {
                    DanhMucSanPhamDichVuHoatDongFactory
                        .XoaDichVuSanPham(item)
                        .done(function (res) {
                            if (res && res.ErrorCode === 0) {
                                toastr.success("Xóa thành công !")
                                $scope.getProductSerVice();
                            }
                            else {
                                toastr.warning(res.ErrorMsg);
                            }
                        }).fail(function () {
                            toastr.error("Lỗi");
                        }).always(function () {
                            SweetAlert.swal.close()
                            $scope.$digest();
                        });
                }
            });

    };

    //Xóa
    $scope.XoaSanPhamDichVu = function (item) {
        DanhMucSanPhamDichVuHoatDongFactory
            .XoaDichVuSanPham(item.ProjectID)
            .done(function (res) {
                if (res && res.ErrorCode === 0) {
                    toastr.success(res.Message)
                    $('#idm_Xoa').modal('hide')
                    $scope.getProductSerVice();
                    location.reload();
                }
                else {
                    toastr.warning(res.ErrorMsg);
                }
            }).fail(function () {
                toastr.error(res.ErrorMsg);
            }).always(function () {
                SweetAlert.swal.close()
                $scope.$digest();
            });
    }
    //Update Sản phẩm dịch vụ
    $scope.initCapNhapSanPhamDichVu= function (item) {
        var ngayBatDau=new Date();
        var MaSPDV = item.ProductServiceCode;
        var TenSPDV = item.ProductServiceName;
                $scope.ItemDetail = {
        BeginDate:ngayBatDau,
        ProductServiceCode:MaSPDV,
        ProductServiceName:TenSPDV,
        ProjectID: item.ProjectID,
        ProductServiceID: item.ProductServiceID
    };
        DanhMucSanPhamDichVuHoatDongFactory
        $('#DetailModal').modal('show');
    };
    //cập nhật Sản phẩm dịch vụ
    $scope.CapNhatSanPhamDichVu = function () {
        var check = $("#DetailForm").valid();
        if (check) {
            DanhMucSanPhamDichVuHoatDongFactory
                .CapNhatSanPhamDichVu($scope.ItemDetail)
                .done(function (res) {
                    if (res && res.ErrorCode === 0) {
                        toastr.success("Sửa thành công !")
                        $('#DetailModal').modal('hide');
                        $scope.getProductSerVice();
                        location.reload();
                    }
                    else {
                        toastr.warning(res.ErrorMsg);
                    }
                }).fail(function () {
                    toastr.error(res.ErrorMsg);
                }).always(function () {
                    setTimeout(t => {
                        $scope.disableBtn = false;
                    }, 500)
                    $scope.$digest();
                });
        }
    }

    function clearValidation(formElement) {
        var validator = $(formElement).validate();
        $('[name]', formElement).each(function () {
            validator.successList.push(this);//mark as error free
            validator.showErrors();//remove error messages if present
        });
        validator.resetForm();//remove error class on name elements and clear history
        validator.reset();//remove all error and success data
    }
    //Khi modal đóng thì clear hết validate
    $("#DetailModal").on("hidden.bs.modal", function () {
        clearValidation('#DetailForm');
    });
    //#endregion
    $scope.DoubleClick = function () {
        return;
    }
});