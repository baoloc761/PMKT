﻿angular.module('AccountingApp').controller("DanhMucDoanhThuController", function ($scope, DanhMucDoanhThuFactory, SweetAlert) {
    $scope.$on('$viewContentLoaded', function () {
        $scope.GetRevenueAll();
        $scope.getListMaThue();
        $scope.getListSPDV();
        $scope.rowFocus = { RevenueID: 0, RevenueCode: '', RevenueName: '', ProductServiceID: 0, ProductServiceCode: '', ProductServiceName: '', RevenueFix: '', RevenuePercent: '', TaxID: 0, TaxCode: '', TaxName: '', TaxType: 0, TaxValue: 0, AppliedDate: '' };
    });

    $scope.GetRevenueAll = function () {
        $scope.DanhMucDoanhThu = {};
        DanhMucDoanhThuFactory
            .LayDanhMucDoanhThu()
            .done(function (res) {
                if (res && res.ErrorCode === 0) {

                    if (res.Data.Revenues.length > 0) {

                        $scope.DanhMucDoanhThu = res.Data.Revenues;

                        setTimeout(t => {


                            $('#datatables-example').DataTable();
                            $('#datatables-example_filter label input, #datatables-example_paginate ul').on('click', function () {
                                $scope.rowFocus = { DepartmentID: 0 };
                                $scope.$digest();
                            });

                        }, 100)
                    }
                    else {
                        toastr.info('Không có dữ liệu danh sách');
                    }
                }
                else {
                    toastr.warning(res.ErrorMsg);
                }
            }).fail(function () {
                toastr.error(res.ErrorMsg);
            }).always(function () {
                $scope.$digest();
            });
    }
    $scope.initThemChiPhi = function (item) {
        $scope.ItemDetail = {
            RevenueID: 0,
            RevenueCode: '',
            RevenueName: '',
            ProductServiceID: 0,
            ProductServiceCode: '',
            ProductServiceName: '',
            RevenueFix: '',
            RevenuePercent: '',
            TaxID: 0,
            TaxCode: '',
            TaxName: '',
            TaxType: 0,
            TaxValue: 0,
            AppliedDate: ''
        };
        $('#DetailModal').modal('show');
        //Validate form
        //validateForm("#DetailForm")
    };
   
    $scope.selectRow = function (item) {
        $scope.rowFocus = item;
    }
   
    //Sửa
    $scope.CapNhatDoanhThu = function () {
        var check = $("#DetailForm").valid();
        if (check) {
            DanhMucDoanhThuFactory
                .CapNhatDoanhThu($scope.ItemDetail)
                .done(function (res) {
                    if (res && res.ErrorCode === 0) {
                        toastr.success("Sửa thành công !")
                        $('#DetailModal').modal('hide');
                        $scope.GetRevenueAll();
                        location.reload();
                    }
                    else {
                        toastr.warning(res.ErrorMsg);
                    }
                }).fail(function () {
                    toastr.error(res.ErrorMsg);
                }).always(function () {
                    setTimeout(t => {
                        $scope.disableBtn = false;
                    }, 500)
                    $scope.$digest();
                });
        }
    }
    //thêm
    $scope.ThemDoanhThu = function (item) {
        $scope.DanhMucDoanhThu = {};
        DanhMucDoanhThuFactory
            .ThemDoanhThu(item)
            .done(function (res) {
                if (res && res.ErrorCode === 0) {
                    $('#DetailModal').modal('hide');
                    $scope.GetRevenueAll();
                    location.reload();
                    toastr.success("Thêm thành công!")
                }
                else {
                    toastr.warning(res.ErrorMsg);
                }
            }).fail(function () {
                toastr.error(res.ErrorMsg);
            }).always(function () {
                $scope.$digest();
            });
    }

    //Lấy ma spdv
    $scope.getListSPDV = function (item) {
        $scope.Danhsachspdv = {};
        DanhMucDoanhThuFactory
            .LayDanhSanPhamDichVu(item)
            .done(function (res) {
                if (res && res.ErrorCode === 0) {
                    if (res.Data.ProductServices.length > 0) {
                        $scope.Danhsachspdv = res.Data.ProductServices;

                    }
                    else {
                        toastr.warning("Không có dữ liệu trong danh sách");
                    }
                }
                else {
                    toastr.warning(res.ErrorMsg);
                }
            }).fail(function () {
                toastr.error(res.ErrorMsg);
            }).always(function () {
                $scope.$digest();
            });
    }


    //Lấy ma thue
    $scope.getListMaThue = function (item) {
        $scope.Danhsachmathue = {};
        DanhMucDoanhThuFactory
            .LayDanhSachMaThue(item)
            .done(function (res) {
                if (res && res.ErrorCode === 0) {
                    if (res.Data.Taxs.length > 0) {
                        $scope.Danhsachmathue = res.Data.Taxs;

                    }
                    else {
                        toastr.warning("Không có dữ liệu trong danh sách");
                    }
                }
                else {
                    toastr.warning(res.ErrorMsg);
                }
            }).fail(function () {
                toastr.error(res.ErrorMsg);
            }).always(function () {
                $scope.$digest();
            });
    }

    //pop sửa
    //Update
    $scope.initCapNhapDoanhThu = function (item) {
        var SPDV = item.ProductServiceName;
        var MaThue = item.TaxCode;
        var MaKhoanThu = item.RevenueCode;
        var TenKhoanThu = item.RevenueName;
        var MucThuGiaTri = item.RevenueFix;
        var MucThuPhanTram = item.RevenuePercent;
        var NgayApDung = new Date();
        $scope.ItemDetail = {
            ProductServiceName: SPDV,
            TaxCode: MaThue,
            RevenueCode: MaKhoanThu,
            RevenueName: TenKhoanThu,
            RevenueFix: MucThuGiaTri,
            RevenuePercent: MucThuPhanTram,
            AppliedDate: NgayApDung,
            RevenueID: item.RevenueID,
            ProductServiceID: item.ProductServiceID,
            TaxID: item.TaxID
        };
        DanhMucDoanhThuFactory
        $('#DetailModal').modal('show');
    };

    //initXoa
    //initXoaBophan
    //khởi tạo xóa
    $scope.initXoaDoanhThu = function (item) {
        SweetAlert.swal({
            title: "Xóa doanh thu ?",
            text: "Doanh thu: " + item.RevenueName + " sẽ được xóa!",
            type: "warning",
            showCancelButton: true,
            confirmButtonColor: "#DD6B55", confirmButtonText: "Đồng ý!",
            cancelButtonColor: "#D0D0D0", cancelButtonText: "Hủy bỏ!",
            closeOnConfirm: false,
            closeOnCancel: true
        },
            function (isConfirm) {
                if (isConfirm) {
                    DanhMucDoanhThuFactory
                        .XoaDoanhThu(item)
                        .done(function (res) {
                            if (res && res.ErrorCode === 0) {
                                toastr.success("Xóa thành công !")
                                $scope.GetRevenueAll();
                                location.reload();
                            }
                            else {
                                toastr.warning(res.ErrorMsg);
                            }
                        }).fail(function () {
                            toastr.error("Lỗi");
                        }).always(function () {
                            SweetAlert.swal.close()
                            $scope.$digest();
                        });
                }
            });

    };

    //Xóa
    $scope.XoaDanhMucDoanhThu = function (item) {
        DanhMucDoanhThuFactory
            .XoaDoanhThu(item.RevenueID)
            .done(function (res) {
                if (res && res.ErrorCode === 0) {
                    toastr.success(res.Message)
                    $('#idm_Xoa').modal('hide');
                    $scope.GetRevenueAll();
                }
                else {
                    toastr.warning(res.ErrorMsg);
                }
            }).fail(function () {
                toastr.error(res.ErrorMsg);
            }).always(function () {
                SweetAlert.swal.close()
                $scope.$digest();
            });
    }
});