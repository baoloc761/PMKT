﻿angular.module('AccountingApp').controller("BangTyGiaController", function ($scope, BangTyGiaFactory, SweetAlert) {
    $scope.$on('$viewContentLoaded', function () {
        $scope.getListMoney();
        $scope.getBangTyGia();
        $scope.rowFocus = { ExchangeRateID: 0, CurrencyID: 0, CurrencyCode: '', CurrencyName: '', AppliedDate: '', ExchangeRate: ''};
    });


    //Lấy tiền
    $scope.getListMoney = function (item) {
        $scope.Danhsachtienteselect = {};
        BangTyGiaFactory
            .LayDanhSachTienTeSelect(item)
            .done(function (res) {
                if (res && res.ErrorCode === 0) {
                    if (res.Data.Currencies.length > 0) {
                        $scope.Danhsachtienteselect = res.Data.Currencies;
                    }
                    else {
                        toastr.warning("Không có dữ liệu trong danh sách");
                    }
                }
                else {
                    toastr.warning(res.ErrorMsg);
                }
            }).fail(function () {
                toastr.error(res.ErrorMsg);
            }).always(function () {
                $scope.$digest();
            });
    }

    //Lấy danh sách bộ phận
    $scope.getBangTyGia = function () {
        $scope.bangtygia = {};
        BangTyGiaFactory
            .LayDanhMucBangTyGia()
            .done(function (res) {
                if (res && res.ErrorCode === 0) {
                    if (res.Data.ExchangeRates.length > 0) {
                        $scope.bangtygia = res.Data.ExchangeRates;
                        setTimeout(t => {
                            $('#datatables-example').DataTable();
                            $('#datatables-example_filter label input, #datatables-example_paginate ul').on('click', function () {
                                $scope.rowFocus = { IdNhom: 0 };
                                $scope.$digest();
                            });
                        }, 100)
                    }
                    else {
                        toastr.warning("Không có dữ liệu trong danh sách");
                    }
                }
                else {
                    toastr.warning(res.ErrorMsg);
                }
            }).fail(function () {
                toastr.error(res.ErrorMsg);
            }).always(function () {
                $scope.$digest();
            });
    }
    $scope.initThemTyGia = function (item) {
        $scope.ItemDetail = {
            ExchangeRateID: 0,
            CurrencyID: 0,
            ExchangeRate: '',
            AppliedDate: '',
        };
        $('#DetailModal').modal('show');
    };

    $scope.selectRow = function (item) {
        $scope.rowFocus = item;
    }
    //pop sửa
    //Update
    $scope.initCapNhapTyGia = function (item) {
        var Loaitien = item.CurrencyCode;
        var Tygia = item.ExchangeRate;
        var Ngayapdung = new Date();
        $scope.ItemDetail = {
            CurrencyCode: Loaitien,
            ExchangeRate: Tygia,
            AppliedDate: Ngayapdung,
            ExchangeRateID: item.ExchangeRateID,
            CurrencyID: item.CurrencyID
        };
        BangTyGiaFactory
        $('#DetailModal').modal('show');
    };
    //thêm
    $scope.ThemTyGia = function () {
        $scope.disableBtn = false;
        BangTyGiaFactory
            .ThemTyGia($scope.ItemDetail)
            .done(function (res) {
                if (res && res.ErrorCode === 0) {
                    $('#DetailModal').modal('hide');
                    toastr.success("Thêm thành công!")
                    $scope.getBangTyGia();
                }
                else {
                    toastr.warning(res.ErrorMsg);
                }
            }).fail(function () {
                toastr.error("Lỗi hệ thống. Lấy dữ liệu thất bại", "Thông báo");
            }).always(function () {
                setTimeout(t => {
                    $scope.disableBtn = true;
                    $scope.$digest();
                }, 500)

            });
    }

    //Sửa
    $scope.CapNhatBangTyGia = function () {
        var check = $("#DetailForm").valid();
        if (check) {
            BangTyGiaFactory
                .SuaTyGia($scope.ItemDetail)
                .done(function (res) {
                    if (res && res.ErrorCode === 0) {
                        toastr.success("Sửa thành công !")
                        $('#DetailModal').modal('hide');
                        $scope.getBangTyGia();
                        location.reload();
                    }
                    else {
                        toastr.warning(res.ErrorMsg);
                    }
                }).fail(function () {
                    toastr.error(res.ErrorMsg);
                }).always(function () {
                    setTimeout(t => {
                        $scope.disableBtn = false;
                    }, 500)
                    $scope.$digest();
                });
        }
    }

    //initXoa
    //initXoaBophan
    //khởi tạo xóa
    $scope.initXoaBangTyGia = function (item) {
        SweetAlert.swal({
            title: "Xóa tỷ giá ?",
            text: "tỷ giá: " + item.CurrencyCode + " sẽ được xóa!",
            type: "warning",
            showCancelButton: true,
            confirmButtonColor: "#DD6B55", confirmButtonText: "Đồng ý!",
            cancelButtonColor: "#D0D0D0", cancelButtonText: "Hủy bỏ!",
            closeOnConfirm: false,
            closeOnCancel: true
        },
            function (isConfirm) {
                if (isConfirm) {
                    BangTyGiaFactory
                        .XoaTyGia(item)
                        .done(function (res) {
                            if (res && res.ErrorCode === 0) {
                                toastr.success("Xóa thành công !")
                                $scope.getBangTyGia();
                                location.reload();
                            }
                            else {
                                toastr.warning(res.ErrorMsg);
                            }
                        }).fail(function () {
                            toastr.error("Lỗi");
                        }).always(function () {
                            SweetAlert.swal.close()
                            $scope.$digest();
                        });
                }
            });

    };

    //Xóa
    $scope.XoaDanhMucBangTyGia = function (item) {
        BangTyGiaFactory
            .XoaTyGia(item.ExchangeRateID)
            .done(function (res) {
                if (res && res.ErrorCode === 0) {
                    toastr.success(res.Message)
                    $('#idm_Xoa').modal('hide');
                    $scope.getBangTyGia();
                }
                else {
                    toastr.warning(res.ErrorMsg);
                }
            }).fail(function () {
                toastr.error(res.ErrorMsg);
            }).always(function () {
                SweetAlert.swal.close()
                $scope.$digest();
            });
    }
});