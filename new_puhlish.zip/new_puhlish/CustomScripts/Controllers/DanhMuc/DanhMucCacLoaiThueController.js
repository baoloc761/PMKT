﻿angular.module('AccountingApp').controller("DanhMucCacLoaiThueController", function ($scope, DanhMucCacLoaiThueFactory, SweetAlert) {
    $scope.$on('$viewContentLoaded', function () {
        $scope.GetTaxsAll();
        $scope.getListMoney();
        $scope.rowFocus = { TaxID: 0, TaxCode: '', TaxName: '', TaxPercent: '', TaxFix: '', CurrencyID: 0, CurrencyName: '', AppliedType: '' };
    });
    $scope.selectRow = function (item) {
        $scope.rowFocus = item;
    }
   
 


    $scope.GetTaxsAll = function () {
        $scope.DanhMucLoaiThue = {};
        DanhMucCacLoaiThueFactory
            .Laydanhmucloaithe()
            .done(function (res) {
                if (res && res.ErrorCode === 0) {

                    if (res.Data.Taxs.length > 0) {

                        $scope.DanhMucLoaiThue = res.Data.Taxs;

                        setTimeout(t => {


                            $('#datatables-example').DataTable();
                            $('#datatables-example_filter label input, #datatables-example_paginate ul').on('click', function () {
                                $scope.rowFocus = { DepartmentID: 0 };
                                $scope.$digest();
                            });
                            //$('#datatables-example_filter label input').click(function () {
                            //    $scope.rowFocus = { IdNhom: 0 };
                            //    $scope.$digest();
                            //});

                        }, 100)
                    }
                    else {
                        toastr.info('Không có dữ liệu danh sách');
                    }
                }
                else {
                    toastr.warning(res.ErrorMsg);
                }
            }).fail(function () {
                toastr.error(res.ErrorMsg);
            }).always(function () {
                $scope.$digest();
            });
    }

   
    $scope.initThemThue = function (item) {
        $scope.ItemDetail = {
            TaxID: 0,
            TaxCode: '',
            TaxName: '',
            TaxPercent: '',
            TaxFix: '',
            CurrencyID: 0,
            CurrencyName: '',
            AppliedType: ''
        };
        $('#DetailModal').modal('show');
        //Validate form
        validateForm("#DetailForm")
    };
    //Lấy tiền
    $scope.getListMoney = function (item) {
        $scope.Danhsachtienteselect = {};
        DanhMucCacLoaiThueFactory
            .LayDanhSachTienTeSelect(item)
            .done(function (res) {
                if (res && res.ErrorCode === 0) {
                    if (res.Data.Currencies.length > 0) {
                        $scope.Danhsachtienteselect = res.Data.Currencies;
                    }
                    else {
                        toastr.warning("Không có dữ liệu trong danh sách");
                    }
                }
                else {
                    toastr.warning(res.ErrorMsg);
                }
            }).fail(function () {
                toastr.error(res.ErrorMsg);
            }).always(function () {
                $scope.$digest();
            });
    }
    $scope.ThemLoaiThue = function (item) {
        $scope.DanhMucLoaiThue = {};
        DanhMucCacLoaiThueFactory
            .ThemMoiThue(item)
            .done(function (res) {
                if (res && res.ErrorCode === 0) {
                    $('#DetailModal').modal('hide');
                    toastr.success("Thêm thành công!")
                    $scope.GetTaxsAll();
                    location.reload();
                }
                else {
                    toastr.warning(res.ErrorMsg);
                }
            }).fail(function () {
                toastr.error(res.ErrorMsg);
            }).always(function () {
                $scope.$digest();
            });
    }

    $scope.initCapThue= function (item) {
        var Mathue = item.TaxCode;
        var Tenthue = item.TaxName;
        var Tysuat = item.TaxPercent;
        var Giatri = item.TaxFix;
        var Loaitien = item.CurrencyName;
        var Apdung = item.AppliedType;
        $scope.ItemDetail = {
            TaxCode: Mathue,
            TaxName: Tenthue,
            TaxPercent: Tysuat,
            TaxFix: Giatri,
            CurrencyName: Loaitien,
            AppliedType: Apdung,
            TaxID: item.TaxID,
            CurrencyID: item.CurrencyID
        };
        //$scope.ItemDetail = item;
        DanhMucCacLoaiThueFactory
        $('#DetailModal').modal('show');
    };

    //cập nhật
    $scope.CapNhatLoaithue = function () {
        var check = $("#DetailForm").valid();
        if (check) {
            DanhMucCacLoaiThueFactory
                .CapNhatThue($scope.ItemDetail)
                .done(function (res) {
                    if (res && res.ErrorCode === 0) {
                        toastr.success("Sửa thành công !")
                        $('#DetailModal').modal('hide');
                        $scope.GetTaxsAll();
                        location.reload();
                    }
                    else {
                        toastr.warning(res.ErrorMsg);
                    }
                }).fail(function () {
                    toastr.error(res.ErrorMsg);
                }).always(function () {
                    setTimeout(t => {
                        $scope.disableBtn = false;
                    }, 500)
                    $scope.$digest();
                });
        }
    }

    //initXoa
    //initXoaBophan
    //khởi tạo xóa
    $scope.initXoaThue = function (item) {
        SweetAlert.swal({
            title: "Xóa Thuế ?",
            text: "Thuế: " + item.TaxName + " sẽ được xóa!",
            type: "warning",
            showCancelButton: true,
            confirmButtonColor: "#DD6B55", confirmButtonText: "Đồng ý!",
            cancelButtonColor: "#D0D0D0", cancelButtonText: "Hủy bỏ!",
            closeOnConfirm: false,
            closeOnCancel: true
        },
            function (isConfirm) {
                if (isConfirm) {
                    DanhMucCacLoaiThueFactory
                        .Xoathue(item)
                        .done(function (res) {
                            if (res && res.ErrorCode === 0) {
                                toastr.success("Xóa thành công !")
                                $scope.GetTaxsAll();
                                location.reload();
                            }
                            else {
                                toastr.warning(res.ErrorMsg);
                            }
                        }).fail(function () {
                            toastr.error("Lỗi");
                        }).always(function () {
                            SweetAlert.swal.close()
                            $scope.$digest();
                        });
                }
            });

    };

    //Xóa
    $scope.XoaLoaiThue = function (item) {
        DanhMucCacLoaiThueFactory
            .Xoathue(item.TaxID)
            .done(function (res) {
                if (res && res.ErrorCode === 0) {
                    toastr.success(res.Message)
                    $('#idm_Xoa').modal('hide');
                    $scope.GetTaxsAll();
                }
                else {
                    toastr.warning(res.ErrorMsg);
                }
            }).fail(function () {
                toastr.error(res.ErrorMsg);
            }).always(function () {
                SweetAlert.swal.close()
                $scope.$digest();
            });
    }


    function clearValidation(formElement) {
        var validator = $(formElement).validate();
        $('[name]', formElement).each(function () {
            validator.successList.push(this);//mark as error free
            validator.showErrors();//remove error messages if present
        });
        validator.resetForm();//remove error class on name elements and clear history
        validator.reset();//remove all error and success data
    }
    //Khi modal đóng thì clear hết validate
    $("#DetailModal").on("hidden.bs.modal", function () {
        clearValidation('#DetailForm');
    });
    //#endregion
    $scope.DoubleClick = function () {
        return;
    }
});