﻿angular.module('AccountingApp').controller("DanhMucDoiTacController", function ($scope, DanhMucDoiTacFactory, SweetAlert) {
    $scope.$on('$viewContentLoaded', function () {
        $scope.GetPartnerAll();
        $scope.getListSPDV();
        $scope.getListBank();
        $scope.rowFocus = { PartnerID: 0, PartnerCode: '', PartnerName: '', PartnerType: '', PartnerFields: '', TaxCode: '', Address: '', BeginDate: '', Phone: '', AccountBankNumber: '', BankName: '', BankID: 0, ProductServiceID: 0, ProductServiceName: '' };
    });
   
    $scope.GetPartnerAll = function () {
        $scope.DanhMucDoiTac = {};
        DanhMucDoiTacFactory
            .LayDanhMucDoiTac()
            .done(function (res) {
                if (res && res.ErrorCode === 0) {
                    if (res.Data.Partners.length > 0) {
                        $scope.DanhMucDoiTac = res.Data.Partners;
                        setTimeout(t => {
                            $('#datatables-example').DataTable();
                            $('#datatables-example_filter label input, #datatables-example_paginate ul').on('click', function () {
                                $scope.rowFocus = { PartnerID: 0 };
                                $scope.$digest();
                            });
                        }, 100)
                    }
                    else {
                        toastr.info('Không có dữ liệu danh sách');
                    }
                }
                else {
                    toastr.warning(res.ErrorMsg);
                }
            }).fail(function () {
                toastr.error(res.ErrorMsg);
            }).always(function () {
                $scope.$digest();
            });
    }
    //Lấy ngân hàng
    $scope.getListBank = function (item) {
        $scope.Danhsachnganhang = {};
        DanhMucDoiTacFactory
            .LayDanhSachNganHang(item)
            .done(function (res) {
                if (res && res.ErrorCode === 0) {
                    if (res.Data.length > 0) {
                        $scope.Danhsachnganhang = res.Data;

                    }
                    else {
                        toastr.warning("Không có dữ liệu trong danh sách");
                    }
                }
                else {
                    toastr.warning(res.ErrorMsg);
                }
            }).fail(function () {
                toastr.error(res.ErrorMsg);
            }).always(function () {
                $scope.$digest();
            });
    }
    //pop sửa
    //Update Sản phẩm dịch vụ
    $scope.initCapNhapDoiTac = function (item) {
        var Sanphamdichvu = item.ProductServiceName;
        var Tenbank = item.BankName;
        var Stkbank = item.AccountBankNumber;
        var Loaikh = item.PartnerType;
        var Linhvuc = item.PartnerFields;
        var Madoitac = item.PartnerCode;
        var Tendoitac = item.PartnerName;
        var MST = item.TaxCode;
        var Diachi = item.Address;
        var Sdt = item.Phone;
        var Ngaybatdau = new Date();
        $scope.ItemDetail = {
            ProductServiceName: Sanphamdichvu,
            BankName: Tenbank,
            AccountBankNumber: Stkbank,
            PartnerType: Loaikh,
            PartnerFields: Linhvuc,
            PartnerCode: Madoitac,
            PartnerName: Tendoitac,
            TaxCode: MST,
            Address: Diachi,
            Phone: Sdt,
            BeginDate: Ngaybatdau,
            PartnerID: item.PartnerID,
            BankID: item.BankID,
            ProductServiceID: item.ProductServiceID
        };
        DanhMucDoiTacFactory
        $('#DetailModal').modal('show');
    };


    $scope.initThemdoiTac = function (item) {
        $scope.ItemDetail = {
            PartnerID: 0,
            PartnerCode: '',
            PartnerName: '',
            PartnerType: '',
            PartnerFields: '',
            TaxCode: '',
            Address: '',
            BeginDate: '',
            Phone: '',
            AccountBankNumber: '',
            BankName: '',
            BankID: 0,
            ProductServiceID: 0,
            ProductServiceName: ''
        };
        $('#DetailModal').modal('show');
        //Validate form
        //validateForm("#DetailForm")
    };
    $scope.selectRow = function (item) {
        $scope.rowFocus = item;
    }
    //thêm
    $scope.ThemDoiTac = function (item) {
        $scope.themDoiTac = {};
        DanhMucDoiTacFactory
            .ThemMoiDoiTac(item)
            .done(function (res) {
                if (res && res.ErrorCode === 0) {
                    $('#DetailModal').modal('hide');
                    $scope.GetPartnerAll();
                    location.reload();
                    toastr.success("Thêm thành công!")
                }
                else {
                    toastr.warning(res.ErrorMsg);
                }
            }).fail(function () {
                toastr.error(res.ErrorMsg);
            }).always(function () {
                $scope.$digest();
            });
    }
    //Lấy ma spdv
    $scope.getListSPDV = function (item) {
        $scope.Danhsachspdv = {};
        DanhMucDoiTacFactory
            .LayDanhSanPhamDichVu(item)
            .done(function (res) {
                if (res && res.ErrorCode === 0) {
                    if (res.Data.ProductServices.length > 0) {
                        $scope.Danhsachspdv = res.Data.ProductServices;

                    }
                    else {
                        toastr.warning("Không có dữ liệu trong danh sách");
                    }
                }
                else {
                    toastr.warning(res.ErrorMsg);
                }
            }).fail(function () {
                toastr.error(res.ErrorMsg);
            }).always(function () {
                $scope.$digest();
            });
    }
    //initXoa
    //initXoaBophan
    //khởi tạo xóa
    $scope.initXoaDoiTac = function (item) {
        SweetAlert.swal({
            title: "Xóa đối tác ?",
            text: "Đối tác: " + item.PartnerName + " sẽ được xóa!",
            type: "warning",
            showCancelButton: true,
            confirmButtonColor: "#DD6B55", confirmButtonText: "Đồng ý!",
            cancelButtonColor: "#D0D0D0", cancelButtonText: "Hủy bỏ!",
            closeOnConfirm: false,
            closeOnCancel: true
        },
            function (isConfirm) {
                if (isConfirm) {
                    DanhMucDoiTacFactory
                        .XoaDoiTac(item)
                        .done(function (res) {
                            if (res && res.ErrorCode === 0) {
                                toastr.success("Xóa thành công !")
                                $scope.GetPartnerAll();
                                location.reload();
                            }
                            else {
                                toastr.warning(res.ErrorMsg);
                            }
                        }).fail(function () {
                            toastr.error("Lỗi");
                        }).always(function () {
                            SweetAlert.swal.close()
                            $scope.$digest();
                        });
                }
            });

    };

    //Xóa
    $scope.XoaDanhMucDoiTac = function (item) {
        DanhMucDoiTacFactory
            .XoaDoiTac(item.PartnerID)
            .done(function (res) {
                if (res && res.ErrorCode === 0) {
                    toastr.success(res.Message)
                    $('#idm_Xoa').modal('hide');
                    $scope.GetPartnerAll();
                }
                else {
                    toastr.warning(res.ErrorMsg);
                }
            }).fail(function () {
                toastr.error(res.ErrorMsg);
            }).always(function () {
                SweetAlert.swal.close()
                $scope.$digest();
            });
    }

    //Sửa
    $scope.CapNhatDoiTac = function () {
        var check = $("#DetailForm").valid();
        if (check) {
            DanhMucDoiTacFactory
                .CapNhatDoiTac($scope.ItemDetail)
                .done(function (res) {
                    if (res && res.ErrorCode === 0) {
                        toastr.success("Sửa thành công !")
                        $('#DetailModal').modal('hide');
                        $scope.GetPartnerAll();
                        location.reload();
                    }
                    else {
                        toastr.warning(res.ErrorMsg);
                    }
                }).fail(function () {
                    toastr.error(res.ErrorMsg);
                }).always(function () {
                    setTimeout(t => {
                        $scope.disableBtn = false;
                    }, 500)
                    $scope.$digest();
                });
        }
    }
    
    

});