﻿angular.module('AccountingApp').controller("BangDuAnController", function ($scope, BangDuAnFactory, SweetAlert) {
    $scope.$on('$viewContentLoaded', function () {
        $scope.getBangDuAn();
        $scope.rowFocus = { ProjectID: 0, ProjectCode: '', ProjectName: '', ProjectPlace: '' };
    });

    $scope.initThem = function (item) {
        $scope.ItemDetail = {
            ProjectID: 0,
            ProjectCode: '',
            ProjectName: '',
            ProjectPlace: ''
        };
        $('#DetailModal').modal('show');
        //Validate form
        validateForm("#DetailForm")
    };
    $scope.selectRow = function (item) {
        $scope.rowFocus = item;
    }
    //Lấy danh sách bộ phận
    $scope.getBangDuAn = function () {
        $scope.Danhsachduan = {};
        BangDuAnFactory
            .LayDanhSachDuAn()
            .done(function (res) {
                if (res && res.ErrorCode === 0) {
                    if (res.Data.Projects.length > 0) {
                        $scope.Danhsachduan = res.Data.Projects;
                        setTimeout(t => {
                            $('#datatables-example').DataTable();
                            $('#datatables-example_filter label input, #datatables-example_paginate ul').on('click', function () {
                                $scope.rowFocus = { IdNhom: 0 };
                                $scope.$digest();
                            });
                        }, 100)
                    }
                    else {
                        toastr.warning("Không có dữ liệu trong danh sách");
                    }
                }
                else {
                    toastr.warning(res.ErrorMsg);
                }
            }).fail(function () {
                toastr.error(res.ErrorMsg);
            }).always(function () {
                $scope.$digest();
            });
    }
    //Thêm dự án
    $scope.ThemDuAn = function (item) {
        $scope.Danhsachbophan = {};
        BangDuAnFactory
            .ThemMoiDuan(item)
            .done(function (res) {
                if (res && res.ErrorCode === 0) {
                    $('#DetailModal').modal('hide');
                    $scope.getBangDuAn();
                    location.reload();
                    toastr.success("Thêm thành công!")
                }
                else {
                    toastr.warning(res.ErrorMsg);
                }
            }).fail(function () {
                toastr.error(res.ErrorMsg);
            }).always(function () {
                $scope.$digest();
            });
    }
    //khởi tạo xóa
    $scope.initXoaDuan = function (item) {
        SweetAlert.swal({
            title: "Xóa Dự Án ?",
            text: "Dự án: " + item.ProjectName + " sẽ được xóa!",
            type: "warning",
            showCancelButton: true,
            confirmButtonColor: "#DD6B55", confirmButtonText: "Đồng ý!",
            cancelButtonColor: "#D0D0D0", cancelButtonText: "Hủy bỏ!",
            closeOnConfirm: false,
            closeOnCancel: true
        },
            function (isConfirm) {
                if (isConfirm) {
                    BangDuAnFactory
                        .XoaDuAn(item)
                        .done(function (res) {
                            if (res && res.ErrorCode === 0) {
                                toastr.success("Xóa thành công !")
                                $scope.getBangDuAn();
                                location.reload();
                            }
                            else {
                                toastr.warning(res.ErrorMsg);
                            }
                        }).fail(function () {
                            toastr.error("Lỗi");
                        }).always(function () {
                            SweetAlert.swal.close()
                            $scope.$digest();
                        });
                }
            });

    };
    //Xóa
    $scope.XoaDuAn = function (item) {
        BangDuAnFactory
            .XoaDuAn(item.ProjectID)
            .done(function (res) {
                if (res && res.ErrorCode === 0) {
                    toastr.success(res.Message)
                    $('#idm_Xoa').modal('hide');
                    $scope.getBangDuAn();
                }
                else {
                    toastr.warning(res.ErrorMsg);
                }
            }).fail(function () {
                toastr.error(res.ErrorMsg);
            }).always(function () {
                SweetAlert.swal.close()
                $scope.$digest();
            });
    }
    //Update dự án
    $scope.initCapNhapDuAn = function (item) {
        $scope.ItemDetail = item;
        var MaDuAn = item.ProjectCode;
        var TenDuAn = item.ProjectName;
        var TinhThanh = item.ProjectPlace;
        $scope.ItemDetail = {
            ProjectCode: MaDuAn,
            ProjectName: TenDuAn,
            ProjectPlace: TinhThanh,
            ProjectID: item.ProjectID
        }
        BangDuAnFactory
        $('#DetailModal').modal('show');
    };
    //cập nhật
    $scope.CapNhatDanhSachDuAn = function () {
        var check = $("#DetailForm").valid();
        if (check) {
            BangDuAnFactory
                .CapNhatDuAn($scope.ItemDetail)
                .done(function (res) {
                    if (res && res.ErrorCode === 0) {
                        toastr.success("Sửa thành công !")
                        $('#DetailModal').modal('hide');
                        $scope.getBangDuAn();
                        location.reload();
                    }
                    else {
                        toastr.warning(res.ErrorMsg);
                    }
                }).fail(function () {
                    toastr.error(res.ErrorMsg);
                }).always(function () {
                    setTimeout(t => {
                        $scope.disableBtn = false;
                    }, 500)
                    $scope.$digest();
                });
        }
    }
     function clearValidation(formElement) {
        var validator = $(formElement).validate();
        $('[name]', formElement).each(function () {
            validator.successList.push(this);//mark as error free
            validator.showErrors();//remove error messages if present
        });
        validator.resetForm();//remove error class on name elements and clear history
        validator.reset();//remove all error and success data
    }
    //Khi modal đóng thì clear hết validate
    $("#DetailModal").on("hidden.bs.modal", function () {
        clearValidation('#DetailForm');
    });
    //#endregion
    $scope.DoubleClick = function () {
        return;
    }
});