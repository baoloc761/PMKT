﻿angular.module('AccountingApp').controller("GiaoDichTienMatController", function ($scope, GiaoDichTienMatFactory, SweetAlert) {
    var setNgayMacDinhTimKiem = function () {
        if (jQuery().datepicker) {
            var ngay = moment(new Date());
            if (ngay.isValid()) {
                ngay.set('date', 1);
                $('#ngaygiaodich').datepicker('update', new Date(ngay.format("YYYY/MM/DD")));
                $('#fromdate').datepicker('update', new Date(ngay.format("YYYY/MM/DD")));
                $('#todate').datepicker('update', new Date(ngay.format("YYYY/MM/DD")));
                $('#Ngayhoadon').datepicker('update', new Date(ngay.format("YYYY/MM/DD")));
                $('#ngayhopdong').datepicker('update', new Date(ngay.format("YYYY/MM/DD")));
                
            }
            $('#ngaygiaodich').datepicker('update', new Date());
            $('#fromdate').datepicker('update', new Date());
            $('#todate').datepicker('update', new Date());
            $('#Ngayhoadon').datepicker('update', new Date());
            $('#ngayhopdong').datepicker('update', new Date());
        }
    };
    $scope.$on('$viewContentLoaded', function () {
        $scope.rowFocus = { TransactionDate: '', TransactionID: '', TransactionTypeID: 0, CreditAccount: '', CreditName: '', Amount: '', Note: '', ProductServiceID: 0, CurrencyID: 0, LicenseAttach: '', AccountNumber: '' };
        $scope.GetAllTransaction();
        $scope.GetAllDetails();
        $scope.GetTransactionType();
        $scope.getListSPDV();
        $scope.getListMoney();
        $scope.GetPartnerAll();
        $scope.GetAccount2to5List();
        $scope.Account2To5Debit();
        $scope.AccountNumber2();
        setNgayMacDinhTimKiem();
    });
    $scope.selectRow = function (item) {
        $scope.rowFocus = item;
    }



    $scope.initThem = function () {
        debugger
        var FilePath = angular.element(document.getElementById('LicenseAttach').innerText).selector;
        $scope.ItemDetail = {
            TransactionDate: '',
            TransactionID: '',
            TransactionTypeID: 0,
            CreditAccount: '',
            CreditName: '',
            DebitAccount: '',
            DebitName: '',
            Amount: '',
            Note: '',
            ProductServiceID: 0,
            CurrencyID: 0,
            LicenseAttach: '',
            AccountNumber: '',
            AccountDebit: '',
            InvoiceID: 0,
            InvoiceNumber: '',
            InvoiceDate: '',
            InvoiceNote: '',
            PartnerID: 0,
            PartnerName: '',
            ContractNumber: '',
            ContractDate: '',
            ContractNote: '',
            ContractID: 0,
            FullName: '',
            IDNumber: '',
            PhoneNumber: '',
            Address: '',
            AccountName: '',
            Accounttwo: '',
            fromdate: '',
            todate: ''
        };
        window.location.assign("#/them-moi-giao-dich-thu-tien-mat")
        //$('#DetailModal').modal('show');
    };


    $scope.initchitiet = function (item) {
        var HOTEN = item.Detail.UserRecive.FullName;
        var DIACHI = item.Detail.UserRecive.Address;
        var CMND = item.Detail.UserRecive.IDNumber;
        var DOITAC = item.Detail.UserRecive.PartnerName;
        var SDT = item.Detail.UserRecive.PhoneNumber;
        $scope.ItemDetail = {
            FullName: HOTEN,
            Address: DIACHI,
            IDNumber: CMND,
            PartnerName: DOITAC,
            PhoneNumber: SDT,
            PartnerID: item.PartnerID,
            UserReciveID: item.UserReciveID
        };
        GiaoDichTienMatFactory
        $('#DetailUser').modal('show');
    };

    //chọn file để upload
    $scope.SelectFile = function (e) {
        debugger
        if ($scope.ItemDetail.LicenseAttach != null) {
            $scope.ItemDetail.LicenseAttach = angular.element(document.getElementById('LicenseAttach').files[0].name).selector;
        }
        else {
            alert("Ko có dữ liệu file");
        }

        //angular.element(document.getElementById('LicenseAttach')).value = abc
    };




    $scope.GetPartnerAll = function () {
        $scope.DanhMucDoiTac = {};
        GiaoDichTienMatFactory
            .LayDanhMucDoiTac()
            .done(function (res) {
                if (res && res.ErrorCode === 0) {
                    if (res.Data.Partners.length > 0) {
                        $scope.DanhMucDoiTac = res.Data.Partners;

                    }
                    else {
                        toastr.info('Không có dữ liệu danh sách');
                    }
                }
                else {
                    toastr.warning(res.ErrorMsg);
                }
            }).fail(function () {
                toastr.error(res.ErrorMsg);
            }).always(function () {
                $scope.$digest();
            });
    }




    //Lấy ma spdv
    $scope.getListSPDV = function (item) {
        $scope.Danhsachspdv = {};
        GiaoDichTienMatFactory
            .LayDanhSanPhamDichVu(item)
            .done(function (res) {
                if (res && res.ErrorCode === 0) {
                    if (res.Data.ProductServices.length > 0) {
                        $scope.Danhsachspdv = res.Data.ProductServices;

                    }
                    else {
                        toastr.warning("Không có dữ liệu trong danh sách");
                    }
                }
                else {
                    toastr.warning(res.ErrorMsg);
                }
            }).fail(function () {
                toastr.error(res.ErrorMsg);
            }).always(function () {
                $scope.$digest();
            });
    }




    //Lấy ma spdv
    //Lấy tiền
    $scope.getListMoney = function (item) {
        $scope.Danhsachtienteselect = {};
        GiaoDichTienMatFactory
            .LayTien(item)
            .done(function (res) {
                if (res && res.ErrorCode === 0) {
                    if (res.Data.Currencies.length > 0) {
                        $scope.Danhsachtienteselect = res.Data.Currencies;
                    }
                    else {
                        toastr.warning("Không có dữ liệu trong danh sách");
                    }
                }
                else {
                    toastr.warning(res.ErrorMsg);
                }
            }).fail(function () {
                toastr.error(res.ErrorMsg);
            }).always(function () {
                $scope.$digest();
            });
    }

    //thay đổi theo tài khoản nợ
    $scope.DicAccount = {};
    debugger
    $scope.update = function (ItemDetail) {
        if ($scope.ItemDetail.AccountNumber) {
            if ($scope.DicAccount[$scope.ItemDetail.AccountNumber])
                $scope.ItemDetail.account_nummbername = $scope.DicAccount[$scope.ItemDetail.AccountNumber].AccountName;
        }
        else {
            $scope.account_nummbername = '';
        }
    }
    $scope.account_nummbername = '';

    //thay đổi theo tài khoản có
    $scope.DicAccountDebit = {};
    debugger
    $scope.updatedebit = function () {
        if ($scope.ItemDetail.AccountDebit) {
            if ($scope.DicAccountDebit[$scope.ItemDetail.AccountNumber])
                $scope.ItemDetail.AccountNummbernameDebit = $scope.DicAccountDebit[$scope.ItemDetail.AccountDebit].AccountName;
        }
        else {
            $scope.AccountNummbernameDebit = '';
        }
    }
    $scope.AccountNummbernameDebit = 'Không có dữ liệu';

    //thay đổi theo tài khoản có
    $scope.DicAccount2 = {};
    debugger
    $scope.update2 = function () {
        if ($scope.ItemDetail.Accounttwo) {
            if ($scope.DicAccountDebit[$scope.ItemDetail.Accounttwo])
                $scope.ItemDetail.Account2 = $scope.DicAccountDebit[$scope.ItemDetail.Accounttwo].AccountName;
        }
        else {
            $scope.Account2 = '';
        }
    }
    $scope.Account2 = 'Không có dữ liệu';



    //thêm
    $scope.ThemTransactionID = function () {
        $scope.disableBtn = false;
        GiaoDichTienMatFactory
            .ThemMoiGiaoDichTienMat($scope.ItemDetail)
            .done(function (res) {
                if (res && res.ErrorCode === 0) {
                    $('#DetailModal').modal('hide');
                    toastr.success("Thêm thành công!")
                    location.assign("#/giao-dich-tien-mat");
                    $scope.GetAllTransaction();
                }
                else {
                    toastr.warning(res.ErrorMsg);
                }
            }).fail(function () {
                toastr.error("Lỗi hệ thống. Lấy dữ liệu thất bại", "Thông báo");
            }).always(function () {
                setTimeout(t => {
                    $scope.disableBtn = true;
                    $scope.$digest();
                }, 500)

            });
    }

    $scope.initChitiet = function () {
        //$scope.ItemDetail = {
        //};
        $('#DetailUser').modal('show');
    };


    //Cbb loại giao dịch
    $scope.GetTransactionType = function () {
        $scope.DanhMucGiaoDich = {};
        GiaoDichTienMatFactory
            .LayDanhMucGiaoDich()
            .done(function (res) {
                if (res && res.ErrorCode === 0) {
                    if (res.Data.TransactionTypes.length > 0) {
                        $scope.DanhMucGiaoDich = res.Data.TransactionTypes;
                    }
                    else {
                        toastr.info('Không có dữ liệu danh sách');
                    }
                }
                else {
                    toastr.warning(res.ErrorMsg);
                }
            }).fail(function () {
                toastr.error(res.ErrorMsg);
            }).always(function () {
                $scope.$digest();
            });
    }



    //Accoint 2 to 5
    $scope.GetAccount2to5List = function () {
        debugger
        $scope.DanhSachAccount2To5 = {};
        $scope.DicAccount = {};

        GiaoDichTienMatFactory
            .Account2To5()
            .done(function (res) {
                if (res && res.ErrorCode === 0) {
                    if (res.Data.length > 0) {
                        for (var i = 0; i < res.Data.length; i++) {
                            var itemCurr = res.Data[i];
                            var itemCurrDebit = res.Data[i];
                            $scope.DicAccount[itemCurr.AccountNumber] = itemCurr;

                        }
                        $scope.DanhSachAccount2To5 = res.Data;
                    }
                    else {
                        toastr.info('Không có dữ liệu danh sách');
                    }
                }
                else {
                    toastr.warning(res.ErrorMsg);
                }
            }).fail(function () {
                toastr.error(res.ErrorMsg);
            }).always(function () {
                $scope.$digest();
            });
    }

    //Accoint 2 to 5
    $scope.Account2To5Debit = function () {
        debugger
        $scope.DanhSachAccount2To5Debit = {};
        $scope.DicAccountDebit = {};
        GiaoDichTienMatFactory
            .Debit2t85()
            .done(function (res) {
                if (res && res.ErrorCode === 0) {
                    if (res.Data.length > 0) {
                        for (var i = 0; i < res.Data.length; i++) {
                            var itemCurrDebit = res.Data[i];
                            $scope.DicAccountDebit[itemCurrDebit.AccountNumber] = itemCurrDebit;

                        }
                        $scope.DanhSachAccount2To5Debit = res.Data;
                    }
                    else {
                        toastr.info('Không có dữ liệu danh sách');
                    }
                }
                else {
                    toastr.warning(res.ErrorMsg);
                }
            }).fail(function () {
                toastr.error(res.ErrorMsg);
            }).always(function () {
                $scope.$digest();
            });
    }
    //Accoint 2
    $scope.AccountNumber2 = function () {
        debugger
        $scope.DanhSachAccount2 = {};
        $scope.DicAccount2 = {};
        GiaoDichTienMatFactory
            .Debit2t85()
            .done(function (res) {
                if (res && res.ErrorCode === 0) {
                    if (res.Data.length > 0) {
                        for (var i = 0; i < res.Data.length; i++) {
                            var itemAccount2 = res.Data[i];
                            $scope.DanhSachAccount2[itemAccount2.Accounttwo] = itemAccount2;

                        }
                        $scope.DanhSachAccount2 = res.Data;
                    }
                    else {
                        toastr.info('Không có dữ liệu danh sách');
                    }
                }
                else {
                    toastr.warning(res.ErrorMsg);
                }
            }).fail(function () {
                toastr.error(res.ErrorMsg);
            }).always(function () {
                $scope.$digest();
            });
    }
    //chi tiết
    $scope.GetAllDetails = function () {
        $scope.Chitietnguoidung = [];
        GiaoDichTienMatFactory
            .ListTransaction()
            .done(function (res) {
                if (res && res.ErrorCode === 0) {
                    if (res.Data.length > 0) {
                        $scope.Chitietnguoidung = res.Data.Transactions;
                    }
                    else {
                        toastr.info('Không có dữ liệu danh sách');
                    }
                }
                else {
                    toastr.warning(res.ErrorMsg);
                }
            }).fail(function () {
                toastr.error(res.ErrorMsg);
            }).always(function () {
                $scope.$digest();
            });
    }


    //cập nhật
    //pop sửa
    //Update Sản phẩm dịch vụ
    $scope.initCapNhapTransaction = function (item) {
        debugger
        angular.element(document.getElementById("Magiaodich")).val(TransactionID)
        document.getElementById("btnAdd").style.display = "none"
        var TransactionDate = item.TransactionDate;
        var TransactionTypeID = item.TransactionTypeID;
        var TransactionID = item.TransactionID;
        var CreditAccount = item.CreditAccount;
        var CreditName = item.CreditName;
        var DebitAccount = item.DebitAccount;
        var DebitName = item.DebitName;
        var Amount = item.Amount;
        var Note = item.Note;
        var ProductServiceID = item.ProductServiceID;
        var CurrencyID = item.CurrencyID;
        var LicenseAttach = item.LicenseAttach;
        var AccountNumber = item.AccountNumber;
        var InvoiceID = item.InvoiceID;
        var InvoiceNumber = item.InvoiceNumber;
        var InvoiceDate = item.InvoiceDate;
        var InvoiceNote = item.InvoiceNote;
        var PartnerID = item.PartnerID;
        var PartnerName = item.PartnerName;
        var ContractNumber = item.ContractNumber;
        var ContractDate = item.ContractDate;
        var ContractNote = item.ContractNote;
        var ContractID = item.ContractID;
        var FullName = item.FullName;
        var IDNumber = item.IDNumber;
        var PhoneNumber = item.PhoneNumber;
        var Address = item.Address;
        $scope.ItemDetail = {
            TransactionDate: TransactionDate,
            TransactionTypeID: TransactionTypeID,
            TransactionID: TransactionID,
            CreditAccount: CreditAccount,
            CreditName: CreditName,
            DebitAccount: DebitAccount,
            DebitName: DebitName,
            Amount: Amount,
            Note: Note,
            ProductServiceID: ProductServiceID,
            CurrencyID: CurrencyID,
            LicenseAttach: LicenseAttach,
            AccountNumber: AccountNumber,
            InvoiceID: InvoiceID,
            InvoiceNumber: InvoiceNumber,
            InvoiceDate: InvoiceDate,
            InvoiceNote: InvoiceNote,
            PartnerID: PartnerID,
            PartnerName: PartnerName,
            ContractNumber: ContractNumber,
            ContractDate: ContractDate,
            ContractNote: ContractNote,
            ContractID: ContractID,
            FullName: FullName,
            IDNumber: IDNumber,
            PhoneNumber: PhoneNumber,
            Address: Address
        };
        GiaoDichTienMatFactory
        window.location.assign("#/them-moi-giao-dich-thu-tien-mat?" + TransactionID + "")
        
    };

    //Sửa
    $scope.CapNhatTransaction = function () {
        var check = $("#Create").valid;
        if (check) {
            GiaoDichTienMatFactory
                .Updatetransaction($scope.ItemDetail)
                .done(function (res) {
                    if (res && res.ErrorCode === 0) {
                        toastr.success("Sửa thành công !")
                        $('#DetailModal').modal('hide');
                        $scope.GetPartnerAll();
                    }
                    else {
                        toastr.warning(res.ErrorMsg);
                    }
                }).fail(function () {
                    toastr.error(res.ErrorMsg);
                }).always(function () {
                    setTimeout(t => {
                        $scope.disableBtn = false;
                    }, 500)
                    $scope.$digest();
                });
        }
    }
    //danh sách giao dịch tiền mặt
    $scope.GetAllTransaction = function () {
        $scope.Giaodichthutienmat = [];
        GiaoDichTienMatFactory
            .ListTransaction()
            .done(function (res) {
                if (res && res.ErrorCode === 0) {
                    if (res.Data.Transactions.length > 0) {
                        var dt = {
                            FromDate: $("#fromdate").val(),
                            ToDate: $("#todate").val()
                        };
                        if (dt != null) {
                            $scope.Giaodichthutienmat = res.Data.Transactions;
                            setTimeout(t => {
                                $('#datatables-example').DataTable();
                                $('#datatables-example_filter label input, #datatablesGetAllDetails-example_paginate ul').on('click', function () {
                                    $scope.rowFocus = { TransactionTypeID: 0 };
                                    $scope.$digest();
                                });
                            }, 100)
                        }
                        else {
                            toastr.info('Không có dữ liệu trong những ngày này');
                        }
                    }
                    else {
                        toastr.info('Không có dữ liệu trong những ngày này');
                    }
                }
                else {
                    toastr.warning(res.ErrorMsg);
                }
            }).fail(function () {
                toastr.error(res.ErrorMsg);
            }).always(function () {
                $scope.$digest();
            });
    }


});