﻿angular.module('AccountingApp').controller("GiaoDichChuyenTienController", function ($scope, GiaoDichChuyenTienFactory, SweetAlert) {
    $scope.$on('$viewContentLoaded', function () {
        $scope.GetTransactionType();
        $scope.getListSPDV();
        $scope.getListMoney();
        $scope.GetPartnerAll();
        $scope.GetAllTransaction();
        $scope.GetAccount2to5List();
        $scope.Account2To5Debit();
        $scope.AccountNumber2();
    });

    //Cbb loại giao dịch
    $scope.GetTransactionType = function () {
        $scope.DanhMucGiaoDich = {};
        GiaoDichChuyenTienFactory
            .LayDanhMucGiaoDich()
            .done(function (res) {
                if (res && res.ErrorCode === 0) {
                    if (res.Data.TransactionTypes.length > 0) {
                        $scope.DanhMucGiaoDich = res.Data.TransactionTypes;
                    }
                    else {
                        toastr.info('Không có dữ liệu danh sách');
                    }
                }
                else {
                    toastr.warning(res.ErrorMsg);
                }
            }).fail(function () {
                toastr.error(res.ErrorMsg);
            }).always(function () {
                $scope.$digest();
            });
    }
    $scope.initThem = function () {
        debugger
        var FilePath = angular.element(document.getElementById('LicenseAttach').innerText).selector;
        $scope.ItemDetail = {
            TransactionDate: '',
            TransactionID: '',
            TransactionTypeID: 0,
            CreditAccount: '',
            CreditName: '',
            DebitAccount: '',
            DebitName: '',
            Amount: '',
            Note: '',
            ProductServiceID: 0,
            CurrencyID: 0,
            LicenseAttach: '',
            AccountNumber: '',
            AccountDebit: '',
            InvoiceID: 0,
            InvoiceNumber: '',
            InvoiceDate: '',
            InvoiceNote: '',
            PartnerID: 0,
            PartnerName: '',
            ContractNumber: '',
            ContractDate: '',
            ContractNote: '',
            ContractID: 0,
            FullName: '',
            IDNumber: '',
            PhoneNumber: '',
            Address: '',
            AccountName: '',
            Accounttwo: '',
            fromdate: '',
            todate: ''
        };
        window.location.assign("#/them-moi-giao-dich-chuyen-tien")
        //$('#DetailModal').modal('show');
    };

    //Lấy ma spdv
    $scope.getListSPDV = function (item) {
        $scope.Danhsachspdv = {};
        GiaoDichChuyenTienFactory
            .LayDanhSanPhamDichVu(item)
            .done(function (res) {
                if (res && res.ErrorCode === 0) {
                    if (res.Data.ProductServices.length > 0) {
                        $scope.Danhsachspdv = res.Data.ProductServices;

                    }
                    else {
                        toastr.warning("Không có dữ liệu trong danh sách");
                    }
                }
                else {
                    toastr.warning(res.ErrorMsg);
                }
            }).fail(function () {
                toastr.error(res.ErrorMsg);
            }).always(function () {
                $scope.$digest();
            });
    }
    //Lấy ma spdv
    //Lấy tiền
    $scope.getListMoney = function (item) {
        $scope.Danhsachtienteselect = {};
        GiaoDichChuyenTienFactory
            .LayTien(item)
            .done(function (res) {
                if (res && res.ErrorCode === 0) {
                    if (res.Data.Currencies.length > 0) {
                        $scope.Danhsachtienteselect = res.Data.Currencies;
                    }
                    else {
                        toastr.warning("Không có dữ liệu trong danh sách");
                    }
                }
                else {
                    toastr.warning(res.ErrorMsg);
                }
            }).fail(function () {
                toastr.error(res.ErrorMsg);
            }).always(function () {
                $scope.$digest();
            });
    }

    //Accoint 2 to 5
    $scope.GetAccount2to5List = function () {
        debugger
        $scope.DanhSachAccount2To5 = {};
        $scope.DicAccount = {};

        GiaoDichChuyenTienFactory
            .Account2To5()
            .done(function (res) {
                if (res && res.ErrorCode === 0) {
                    if (res.Data.length > 0) {
                        for (var i = 0; i < res.Data.length; i++) {
                            var itemCurr = res.Data[i];
                            var itemCurrDebit = res.Data[i];
                            $scope.DicAccount[itemCurr.AccountNumber] = itemCurr;

                        }
                        $scope.DanhSachAccount2To5 = res.Data;
                    }
                    else {
                        toastr.info('Không có dữ liệu danh sách');
                    }
                }
                else {
                    toastr.warning(res.ErrorMsg);
                }
            }).fail(function () {
                toastr.error(res.ErrorMsg);
            }).always(function () {
                $scope.$digest();
            });
    }

    //thay đổi theo tài khoản nợ
    $scope.DicAccount = {};
    debugger
    $scope.update = function (ItemDetail) {
        if ($scope.ItemDetail.AccountNumber) {
            if ($scope.DicAccount[$scope.ItemDetail.AccountNumber])
                $scope.ItemDetail.account_nummbername = $scope.DicAccount[$scope.ItemDetail.AccountNumber].AccountName;
        }
        else {
            $scope.account_nummbername = '';
        }
    }
    $scope.account_nummbername = '';

    //Accoint 2 to 5
    $scope.Account2To5Debit = function () {
        debugger
        $scope.DanhSachAccount2To5Debit = {};
        $scope.DicAccountDebit = {};
        GiaoDichChuyenTienFactory
            .Debit2t85()
            .done(function (res) {
                if (res && res.ErrorCode === 0) {
                    if (res.Data.length > 0) {
                        for (var i = 0; i < res.Data.length; i++) {
                            var itemCurrDebit = res.Data[i];
                            $scope.DicAccountDebit[itemCurrDebit.AccountNumber] = itemCurrDebit;

                        }
                        $scope.DanhSachAccount2To5Debit = res.Data;
                    }
                    else {
                        toastr.info('Không có dữ liệu danh sách');
                    }
                }
                else {
                    toastr.warning(res.ErrorMsg);
                }
            }).fail(function () {
                toastr.error(res.ErrorMsg);
            }).always(function () {
                $scope.$digest();
            });
    }
    //thay đổi theo tài khoản có
    $scope.DicAccountDebit = {};
    debugger
    $scope.updatedebit = function () {
        if ($scope.ItemDetail.AccountDebit) {
            if ($scope.DicAccountDebit[$scope.ItemDetail.AccountNumber])
                $scope.ItemDetail.AccountNummbernameDebit = $scope.DicAccountDebit[$scope.ItemDetail.AccountDebit].AccountName;
        }
        else {
            $scope.AccountNummbernameDebit = '';
        }
    }
    $scope.AccountNummbernameDebit = 'Không có dữ liệu';
    //thay đổi theo tài khoản có
    $scope.DicAccount2 = {};
    debugger
    $scope.update2 = function () {
        if ($scope.ItemDetail.Accounttwo) {
            if ($scope.DicAccountDebit[$scope.ItemDetail.Accounttwo])
                $scope.ItemDetail.Account2 = $scope.DicAccountDebit[$scope.ItemDetail.Accounttwo].AccountName;
        }
        else {
            $scope.Account2 = '';
        }
    }
    $scope.Account2 = 'Không có dữ liệu';
    $scope.AccountNumber2 = function () {
        debugger
        $scope.DanhSachAccount2 = {};
        $scope.DicAccount2 = {};
        GiaoDichChuyenTienFactory
            .Debit2t85()
            .done(function (res) {
                if (res && res.ErrorCode === 0) {
                    if (res.Data.length > 0) {
                        for (var i = 0; i < res.Data.length; i++) {
                            var itemAccount2 = res.Data[i];
                            $scope.DanhSachAccount2[itemAccount2.Accounttwo] = itemAccount2;

                        }
                        $scope.DanhSachAccount2 = res.Data;
                    }
                    else {
                        toastr.info('Không có dữ liệu danh sách');
                    }
                }
                else {
                    toastr.warning(res.ErrorMsg);
                }
            }).fail(function () {
                toastr.error(res.ErrorMsg);
            }).always(function () {
                $scope.$digest();
            });
    }
    //danh sách giao dịch tiền mặt
    $scope.GetAllTransaction = function () {
        debugger
        $scope.Giaodichthutienmat = [];
        GiaoDichChuyenTienFactory
            .ListTransaction()
            .done(function (res) {
                if (res && res.ErrorCode === 0) {
                    if (res.Data.Transactions.length > 0) {
                        var dt = {
                            FromDate: $("#fromdate").val(),
                            ToDate: $("#todate").val()
                        };
                        if (dt != null) {
                            $scope.Giaodichthutienmat = res.Data.Transactions;
                            setTimeout(t => {
                                $('#datatables-example').DataTable();
                                $('#datatables-example_filter label input, #datatablesGetAllDetails-example_paginate ul').on('click', function () {
                                    $scope.rowFocus = { TransactionTypeID: 0 };
                                    $scope.$digest();
                                });
                            }, 100)
                        }
                        else {
                            toastr.info('Không có dữ liệu trong những ngày này');
                        }
                    }
                    else {
                        toastr.info('Không có dữ liệu trong những ngày này');
                    }
                }
                else {
                    toastr.warning(res.ErrorMsg);
                }
            }).fail(function () {
                toastr.error(res.ErrorMsg);
            }).always(function () {
                $scope.$digest();
            });
    }
    //thêm
    $scope.ThemTransactionID = function () {
        $scope.disableBtn = false;
        GiaoDichChuyenTienFactory
            .ThemMoiGiaoDichTienMat($scope.ItemDetail)
            .done(function (res) {
                if (res && res.ErrorCode === 0) {
                    $('#DetailModal').modal('hide');
                    toastr.success("Thêm thành công!")
                    location.assign("#/danh-muc-chi-tien-mat");
                    $scope.GetAllTransaction();
                }
                else {
                    toastr.warning(res.ErrorMsg);
                }
            }).fail(function () {
                toastr.error("Lỗi hệ thống. Lấy dữ liệu thất bại", "Thông báo");
            }).always(function () {
                setTimeout(t => {
                    $scope.disableBtn = true;
                    $scope.$digest();
                }, 500)

            });
    }
    $scope.GetPartnerAll = function () {
        $scope.DanhMucDoiTac = {};
        GiaoDichChuyenTienFactory
            .LayDanhMucDoiTac()
            .done(function (res) {
                if (res && res.ErrorCode === 0) {
                    if (res.Data.Partners.length > 0) {
                        $scope.DanhMucDoiTac = res.Data.Partners;

                    }
                    else {
                        toastr.info('Không có dữ liệu danh sách');
                    }
                }
                else {
                    toastr.warning(res.ErrorMsg);
                }
            }).fail(function () {
                toastr.error(res.ErrorMsg);
            }).always(function () {
                $scope.$digest();
            });
    }
    $(document).ready(function () {
        var counter = 0;
        var item;
        $("#addrowhopdong").on("click", function () {
            var newRow = $("<tr>");
            var cols = "";
            cols += '<td>' + (counter + 2) + '</td>';
            cols += '<td><input type="text" class="form-control" name="phone' + counter + '"/></td>';
            cols += '<td><input type="date" class="form-control ng-pristine ng-untouched ng-valid ng-empty" name="date' + counter + '"/></td>';
            cols += '<td><input type="text" class="form-control" name="phone' + counter + '"/></td>';
            cols += '<td><select ' + counter + ' ng-model="ItemDetail.PartnerID" class="form-control ng-pristine ng-valid ng-empty ng-touched" id="textTKco21" name="abc"><option selected="selected" value = "" > --- Tùy chọn-- -</option ><option class="ng-binding ng-scope" id="abc" value="item.PartnerID">' + $scope.DanhMucDoiTac.AccountName + '</option></select ></td>';
            cols += '<td><input type="text" class="form-control" name="phone' + counter + '"/></td>';
            cols += '<td><button type="button" class="btn btn-success" id="ibtnDel"><i class="fa fa-trash-o" aria-hidden="true"></i> Xóa</button></td>';
            newRow.append(cols);
            $("#Thongtinhopdongtable").append(newRow);
            counter++;
        });

        $("#Thongtinhopdongtable").on("click", "#ibtnDelhopdong", function (event) {
            $(this).closest("tr").remove();
            counter -= 1
        });

        $("#addrow").on("click", function () {
            var newRow = $("<tr>");
            var cols = "";
            cols += '<td>' + (counter+2) + '</td>';
            cols += '<td><input type="text" class="form-control" name="phone' + counter + '"/></td>';
            cols += '<td><input type="date" class="form-control ng-pristine ng-untouched ng-valid ng-empty" name="date' + counter + '"/></td>';
            cols += '<td><input type="text" class="form-control" name="phone' + counter + '"/></td>';
            cols += '<td><input type="text" class="form-control" name="phone' + counter + '"/></td>';
            cols += '<td> <select ng-model="ItemDetail.PartnerID" class="form-control" id="textTKco21" name="abc"><option selected = "selected" value = "" > --- Tùy chọn-- -</option ><option ng-repeat="item in DanhMucDoiTac" id="abc" value="{{item.PartnerID}}">{{ item.PartnerName }}</option></select></td>';
            cols += '<td><input type="text" class="form-control" name="phone' + counter + '"/></td>';
            cols += '<td><button type="button" class="btn btn-success" id="ibtnDel"><i class="fa fa-trash-o" aria-hidden="true"></i> Xóa</button></td>';
            newRow.append(cols);
            $("table.order-list").append(newRow);
            counter++;
        });



        $("table.order-list").on("click", "#ibtnDel", function (event) {
            $(this).closest("tr").remove();
            counter -= 1
        });
        var dem = 0;
        $(".column02").on("click", "#btnxoatkno", function (event) {
            $(this).closest(".newrow").remove();
            dem -= 1
            if (dem -= 1) {
                document.getElementById("formBtnTKco").disabled = false;
            }
            
        });
        $("#formBtnTKghino").on("click", function () {
            var newRow = $('<div class="newrow" ' + dem + '>');
            var div = "";
            div += '<div class="form-group mb-2" id="taikhoannoinputtext">';
            div += '<input type="text" class="form-control" id="SchoolName" name="SchoolName">';
            div += '</div>';
            div += ' ';
            div += '<div class="form-group mx-sm-3 mb-2" id="taikhoannoinputtext">';
            div += '<input type="text" class="form-control" id="SchoolName" disabled="" name="SchoolName">';
            div += '</div>';
            div += ' ';
            div += '<div class="form-group mx-sm-3 mb-2" id="taikhoannoinputtext">';
            div += '<input type="text" class="form-control" id="SchoolName" name="SchoolName">';
            div += '</div>';
            div += ' ';
            div += '<div style="float:right;margin-right: 38px;">';
            div += '<div class="form-group mx-sm-3 mb-2">'
            div += '<button style="width: 216%!important;" type="button" style="border-radius:3px;" class="btn btn-success" id="btnxoatkno"> Xóa</button>'
            div += '</div>';
            div += ' ';
            div += '</div>';
            newRow.append(div);
            $(".column02").append(newRow);
            counter++;
            document.getElementById("formBtnTKco").disabled = true;
        });

        var counter1 = 0;
        $(".column03").on("click", "#btnxoatkno", function (event) {
            $(this).closest(".objcolumne03").remove();
            counter1 -= 1
            if (counter1 -= 1) {
                document.getElementById("formBtnTKghino").disabled = false;
            }
        });
        $("#formBtnTKco").on("click", function () {
            var newRow = $('<div class="objcolumne03" ' + counter1 + '>');
            var div = "";
            div += '<div class="form-group mb-2" id="taikhoannoinputtext">';
            div += '<input type="text" class="form-control" id="SchoolName" name="SchoolName">';
            div += '</div>';
            div += ' ';
            div += '<div class="form-group mx-sm-3 mb-2" id="taikhoannoinputtext">';
            div += '<input type="text" class="form-control" id="SchoolName" disabled="" name="SchoolName">';
            div += '</div>';
            div += ' ';
            div += '<div class="form-group mx-sm-3 mb-2" id="taikhoannoinputtext">';
            div += '<input type="text" class="form-control" id="SchoolName" name="SchoolName">';
            div += '</div>';
            div += ' ';
            div += '<div style="float:right;margin-right: 38px;">';
            div += '<div class="form-group mx-sm-3 mb-2">'
            div += '<button style="width: 216%!important;" type="button" style="border-radius:3px;" class="btn btn-success" id="btnxoatkno"> Xóa</button>'
            div += '</div>';
            div += ' ';
            div += '</div>';
            newRow.append(div);
            $(".column03").append(newRow);
            counter++;
            document.getElementById("formBtnTKghino").disabled = true;
        });
    });



    function calculateRow(row) {
        var price = +row.find('input[name^="price"]').val();

    }

    function calculateGrandTotal() {
        var grandTotal = 0;
        $("table.order-list").find('input[name^="price"]').each(function () {
            grandTotal += +$(this).val();
        });
        $("#grandtotal").text(grandTotal.toFixed(2));
    }
});