﻿
/* Cấu hình và định tuyến ứng dụng */
/* Module chính */
var AccountingApp = angular.module("AccountingApp", [
    "ui.router",
    "ui.bootstrap",
    "oc.lazyLoad",
    "ngSanitize",
    //"ngMessages"
    //"ngTable"
    //"ui.utils.masks",
    //'angularFileUpload',
    //'ngDialog'
]);

//AccountingApp.config(['$compileProvider', function ($compileProvider) {
//    $compileProvider.debugInfoEnabled(false);
//}]);

AccountingApp.run(["$rootScope", "settings", "$state", '$ocLazyLoad', function ($rootScope, settings, $state, $ocLazyLoad) {
    $rootScope.$state = $state;
    $ocLazyLoad.load([//load ở đây để hạn chế load check nhiều lần khi chuyển state
        {
            name: 'ui.select',
            insertBefore: '#ng_load_plugins_before',
            files: [
                '/assets/plugins/ui-select/select.min.css',
                '/assets/plugins/ui-select/select.min.js',
            ]
            //, serie: true
        },
        {//plugin sử dụng nhiều
            name: 'AccountingApp',
            files: [
                //'/assets/plugins/bootstrap-toastr/toastr.min.js?v=' + svn,
                //'/assets/plugins/moment.js?v=' + svn,
                //'/assets/plugins/bootstrap-datepicker/css/bootstrap-datepicker3.min.css?v=' + svn,
                //'/assets/plugins/bootstrap-datepicker/js/bootstrap-datepicker.js?v=' + svn,
                //'/assets/plugins/sweetalert-master/sweetalert.css?v=' + svn,
                //'/assets/plugins/sweetalert-master/sweetalert.min.js?v=' + svn,
                // '/js//SweetAlert.js?v=' + svn,
                //'/assets/js/main.js',
                //'/assets/plugins/sweetalert-master/sweetalert.css',
                //'/assets/plugins/sweetalert-master/sweetalert.min.js',
                '/assets/js/SweetAlert2.js',
                '/assets/plugins/moment.js',
                '/assets/plugins/bootstrap-datepicker/css/bootstrap-datepicker3.min.css',
                '/assets/plugins/bootstrap-datepicker/js/bootstrap-datepicker.js',
               
            ]
        },
    ]);
    $rootScope.setOptions = function () {
        toastr.options.positionClass = "toast-top-right";
        toastr.options.closeButton = true;
        toastr.options.showMethod = 'slideDown';
        toastr.options.hideMethod = 'slideUp';
        //toastr.options.newestOnTop = false;
        toastr.options.progressBar = true;
    };

    $rootScope.setOptions();
    function GetUserInfo() {
        $.get('/Home/LayThongTinDangNhap')
            .done(function (res) {
                if (res != null) {
                    //console.log(res);
                    $rootScope.UserInfo = res
                    $rootScope.$digest();
                }
                else
                    toastr["warning"]("Không thể lấy thông tin người dùng");
            })
    }
    GetUserInfo();
}]);
/* Configure ocLazyLoader(refer: https://github.com/ocombe/ocLazyLoad) */
AccountingApp.config(['$ocLazyLoadProvider', function ($ocLazyLoadProvider) {
    $ocLazyLoadProvider.config({
        // global configs go here
    });
}]);
/* header */
AccountingApp.controller('HeaderController', ['$scope', function ($scope) {
    $scope.$on('$includeContentLoaded', function () {
        //  Layout.initHeader(); // init header
    });
}]);



/* Footer */
AccountingApp.controller('FooterController', ['$scope', function ($scope) {
    $scope.$on('$includeContentLoaded', function () {
        //Layout.initFooter(); // init footer
    });
}]);
/* Setup global settings */
AccountingApp.factory('settings', ['$rootScope', function ($rootScope) {
    // supported languages
    var settings = {
        layout: {

        },
        assetsPath: '/assets',
        globalPath: '/assets/global',
    };

    $rootScope.settings = settings;
    return settings;
}]);

////////////////////////* Cài đặt controller cho trang chủ */
AccountingApp.controller('AppController', ['$scope', '$rootScope', '$interval', function ($scope, $rootScope, $interval) {
    $scope.$on('$viewContentLoaded', function () {
        //$rootScope.rLayPhanQuyen();
    });

}]);
function sgNumberInput($filter, $locale) {
    //#region helper methods
    function getCaretPosition(inputField) {
        // Initialize
        var position = 0;
        // IE Support
        if (document.selection) {
            inputField.focus();
            // To get cursor position, get empty selection range
            var emptySelection = document.selection.createRange();
            // Move selection start to 0 position
            emptySelection.moveStart('character', -inputField.value.length);
            // The caret position is selection length
            position = emptySelection.text.length;
        }
        else if (inputField.selectionStart || inputField.selectionStart === 0) {
            position = inputField.selectionStart;
        }
        return position;
    }
    function setCaretPosition(inputElement, position) {
        if (inputElement.createTextRange) {
            var range = inputElement.createTextRange();
            range.move('character', position);
            range.select();
        }
        else {
            if (inputElement.selectionStart) {
                inputElement.focus();
                inputElement.setSelectionRange(position, position);
            }
            else {
                inputElement.focus();
            }
        }
    }
    function countNonNumericChars(value) {
        return (value.match(/[^a-z0-9]/gi) || []).length;
    }
    //#endregion helper methods



    return {
        require: "ngModel",
        restrict: "A",
        link: function ($scope, element, attrs, ctrl) {
            var fractionSize = parseInt(attrs['fractionSize']) || 0;
            var numberFilter = $filter('number');
            //format the view value
            ctrl.$formatters.push(function (modelValue) {
                var retVal = numberFilter(modelValue, fractionSize);
                var isValid = !isNaN(modelValue);
                ctrl.$setValidity(attrs.name, isValid);
                return retVal;
            });
            //parse user's input
            ctrl.$parsers.push(function (viewValue) {
                var caretPosition = getCaretPosition(element[0]), nonNumericCount = countNonNumericChars(viewValue);
                viewValue = viewValue || '';
                //Replace all possible group separators
                var trimmedValue = viewValue.trim().replace(/,/g, '').replace(/`/g, '').replace(/'/g, '').replace(/\u00a0/g, '').replace(/ /g, '');
                //If numericValue contains more decimal places than is allowed by fractionSize, then numberFilter would round the value up
                //Thus 123.109 would become 123.11
                //We do not want that, therefore I strip the extra decimal numbers
                var separator = $locale.NUMBER_FORMATS.DECIMAL_SEP;
                var arr = trimmedValue.split(separator);
                var decimalPlaces = arr[1];
                if (decimalPlaces != null && decimalPlaces.length > fractionSize) {
                    //Trim extra decimal places
                    decimalPlaces = decimalPlaces.substring(0, fractionSize);
                    trimmedValue = arr[0] + separator + decimalPlaces;
                }
                var numericValue = parseFloat(trimmedValue);
                var isEmpty = numericValue == null || viewValue.trim() === "";
                var isRequired = attrs.required || false;
                var isValid = true;
                if (isEmpty && isRequired || !isEmpty && isNaN(numericValue)) {
                    isValid = false;
                }
                ctrl.$setValidity(attrs.name, isValid);
                if (!isNaN(numericValue) && isValid) {
                    var newViewValue = numberFilter(numericValue, fractionSize);
                    element.val(newViewValue);
                    var newNonNumbericCount = countNonNumericChars(newViewValue);
                    var diff = newNonNumbericCount - nonNumericCount;
                    var newCaretPosition = caretPosition + diff;
                    if (nonNumericCount === 0 && newCaretPosition > 0) newCaretPosition--;
                    setCaretPosition(element[0], newCaretPosition);
                }
                return !isNaN(numericValue) ? numericValue : null;
            });
        } //end of link function
    };
}

sgNumberInput.$inject = ["$filter", "$locale"];
AccountingApp.directive("sgNumberInput", sgNumberInput);
AccountingApp.directive('fotmatNumberInput', function ($filter, $browser) {
    return {
        require: 'ngModel',
        link: function ($scope, $element, $attrs, ngModelCtrl) {
            var listener = function () {
                var value = $element.val().replace(/,/g, '')
                $element.val($filter('number')(value, false))
            }

            // This runs when we update the text field
            ngModelCtrl.$parsers.push(function (viewValue) {
                return viewValue.replace(/,/g, '');
            })

            // This runs when the model gets updated on the scope directly and keeps our view in sync
            ngModelCtrl.$render = function () {
                $element.val($filter('number')(ngModelCtrl.$viewValue, false))
            }

            $element.bind('change', listener)
            $element.bind('keydown', function (event) {
                var key = event.keyCode
                // If the keys include the CTRL, SHIFT, ALT, or META keys, or the arrow keys, do nothing.
                // This lets us support copy and paste too
                if (key == 91 || (15 < key && key < 19) || (37 <= key && key <= 40))
                    return
                $browser.defer(listener) // Have to do this or changes don't get picked up properly
            })

            $element.bind('paste cut', function () {
                $browser.defer(listener)
            })
        }

    }
})
AccountingApp.directive('numberFormat', ['$filter', '$parse', function ($filter, $parse) {
    return {
        require: 'ngModel',
        link: function (scope, element, attrs, ngModelController) {

            var decimals = $parse(attrs.decimals)(scope);

            ngModelController.$parsers.push(function (data) {
                // Attempt to convert user input into a numeric type to store
                // as the model value (otherwise it will be stored as a string)
                // NOTE: Return undefined to indicate that a parse error has occurred
                //       (i.e. bad user input)
                var parsed = parseFloat(data);
                return !isNaN(parsed) ? parsed : undefined;
            });

            ngModelController.$formatters.push(function (data) {
                //convert data from model format to view format
                return $filter('number')(data, decimals); //converted
            });

            element.bind('focus', function () {
                element.val(ngModelController.$modelValue);
            });
            element.bind('blur', function () {
                // Apply formatting on the stored model value for display
                var formatted = $filter('number')(ngModelController.$modelValue, decimals);
                element.val(formatted);
            });
        }
    }
}]);
AccountingApp.directive('treeView', function ($compile) {
    return {
        restrict: 'E',
        scope: {
            localNodes: '=model',
            localClick: '&click',
            showEdit: '@'
        },
        link: function (scope, tElement, tAttrs, transclude) {

            var maxLevels = (angular.isUndefined(tAttrs.maxlevels)) ? 10 : tAttrs.maxlevels;
            var hasCheckBox = (angular.isUndefined(tAttrs.checkbox)) ? false : true;
            scope.showItems = [];

            scope.showHide = function (ulId) {
                var hideThis = document.getElementById(ulId);
                var showHide = angular.element(hideThis).attr('class');
                angular.element(hideThis).attr('class', (showHide === 'show' ? 'hide' : 'show'));
            }
            scope.checkIcon = function (ulId) {
                var hideThis = document.getElementById(ulId);
                var showHide = angular.element(hideThis).attr('class');
                return (showHide === 'show' ? true : false);
            }
            scope.showIcon = function (node) {
                if (!angular.isUndefined(node.children)) return true;
            }

            scope.checkIfChildren = function (node) {
                if (!angular.isUndefined(node.children)) return true;
            }

            /////////////////////////////////////////////////
            /// SELECT ALL CHILDRENS
            // as seen at: http://jsfiddle.net/incutonez/D8vhb/5/
            function parentCheckChange(item) {
                var c = true;
                var flag = false;
                for (var i in item.children) {
                    item.children[i].ischecked = item.ischecked;
                    //var showThis = document.getElementById(item.id);
                    //angular.element(showThis).attr('class', 'show');
                    if (item.children[i].children) {
                        parentCheckChange(item.children[i]);
                    }
                }
            }

            scope.checkChange = function (node) {
                if (node.children) {
                    parentCheckChange(node);
                }
                setTimeout(t => {
                    scope.checkAllChildChecked(scope.localNodes)
                }, 500)
            }
            function checkchildIsChecked(item) {
                if (item.ischecked == true) {
                    // console.log(item);
                    return true;
                }
                else {
                    if (item.children)
                        for (var i in item.children) {
                            console.log(item);
                            checkchildIsChecked(item.children[i]);
                            return false;
                        }
                }
            }
            scope.childIsChecked = function (node) {
                if (node.ischecked == true)
                    return true;
                else {
                    return checkchildIsChecked(node);
                }
            }
            //scope.checkAllChildChecked = function (node) {
            //    var c = true;
            //    if (node.children.length > 0) {
            //        for (var i in node.children) {
            //            if (node.children[i].ischecked === false) {
            //                c = false;
            //                node.ischecked = false;
            //                return;
            //            }
            //        }
            //        node.ischecked = c;
            //    }

            //}
            scope.checkAllChildChecked = function (node) {
                var c = true;
                var flag = false;
                for (var k = 0; k < node.length; k++) {
                    var item = node[k]
                    if (item.children && item.children.length > 0) {
                        scope.checkAllChildChecked(item.children);
                        for (var i in item.children) {
                            if (item.children[i].ischecked === false) {
                                c = false;
                                //item.ischecked = false;
                            }
                            else if (flag === false) {
                                flag = true;
                                break;

                            }
                        }
                        item.ischecked = c;
                        c = true;
                        if (flag == true) {
                            var showThis = document.getElementById(item.id);
                            angular.element(showThis).attr('class', 'show');
                            flag = false;
                        }
                        scope.$digest();
                    }
                    else {
                        return item.ischecked;
                    }
                }

            }
            scope.firstTime = 1;
            scope.initTreeCheck = function () {

                if (scope.firstTime == 1 && scope.localNodes && scope.localNodes.length > 0) {
                    scope.firstTime = 2;
                    

                    //for (var i = 0; i < scope.localNodes.length; i++) {
                    //    if (scope.localNodes[i].children.length > 0) {
                    //        for (var k = 0; k < scope.localNodes[i].children.length; k++) {
                    //            scope.checkAllChildChecked(scope.localNodes[i].children[k])
                    //        }
                    //    }
                    //    scope.checkAllChildChecked(scope.localNodes[i])
                    //}
                    setTimeout(t => {
                        scope.checkAllChildChecked(scope.localNodes)
                    },500)
                }
            }
            /////////////////////////////////////////////////

            function renderTreeView(collection, level, max) {
                var text = '';
                text += '<li ng-repeat="n in ' + collection + '" >';
                text += '<span ng-show=showIcon(n) class="show-hide" ng-click=showHide(n.id)><i ng-if=!checkIcon(n.id) class="fa fa-plus-square"></i> <i ng-if=checkIcon(n.id) class="fa fa-minus-square"></i> </span> ';
                text += '<span ng-show=!showIcon(n) style="padding-right: 13px"></span>';

                if (hasCheckBox) {
                    text += '<input class="tree-checkbox" type=checkbox ng-model=n.ischecked ng-change=checkChange(n)>';
                }


                if (scope.showEdit == 'true') {
                    text += '<span class="edit" ng-click=localClick({node:n})><i class="fa fa-pencil"></i></span>'
                }


                text += '<label>{{n.name}}</label>';

                if (level < max) {
                    text += '<ul id="{{n.id}}" ng-init=initTreeCheck()  ng-if=checkIfChildren(n)  class="hide">' + renderTreeView('n.children', level + 1, max) + '</ul></li>';
                } else {
                    text += '</li>';
                }

                return text;
            }// end renderTreeView();

            try {
                var text = '<ul class="tree-view-wrapper" >';
                text += renderTreeView('localNodes', 1, maxLevels);
                text += '</ul>';
                tElement.html(text);
                $compile(tElement.contents())(scope);

            }
            catch (err) {
                tElement.html('<b>ERROR!!!</b> - ' + err);
                $compile(tElement.contents())(scope);
            }
        }
    };
});
///////////////////////////////* Định tuyến trang web*/
AccountingApp.config(['$stateProvider', '$urlRouterProvider', function ($stateProvider, $urlRouterProvider) {
    $urlRouterProvider.otherwise("trang-chu");//Trang mặt định nếu nhập sai url
    $stateProvider //Định tuyến
        .state('dashboard', {  //Trang chủ
            url: "/trang-chu",
            templateUrl: "Home/Dashboard",
            data: { pageTitle: 'Trang chủ' },
            controller: "TrangChuController",
            resolve: {
                deps: ['$ocLazyLoad', function ($ocLazyLoad) {
                    return $ocLazyLoad.load({
                        name: 'AccountingApp',
                        insertBefore: '#ng_load_plugins_before',
                        files: [
                            '/CustomScripts/Controllers/Home/TrangChuController.js',
                        ]
                    });
                }]
            }
        })



        .state('cocau', {  //cơ cấu
            url: "/co-cau",
            templateUrl: "CoCau/Index",
            data: { pageTitle: 'Cơ cấu' },
            controller: "CoCauController",
            resolve: {
                deps: ['$ocLazyLoad', function ($ocLazyLoad) {
                    return $ocLazyLoad.load({
                        name: 'AccountingApp',
                        insertBefore: '#ng_load_plugins_before',
                        files: [
                            '/CustomScripts/Controllers/DanhMuc/CoCauController.js',
                            '/CustomScripts/Services/DanhMuc/CoCauFactory.js',
                        ]
                    });
                }]
            }
        })
       
        .state('nhomnguoidung', {  //Nhóm người dùng
            url: "/nhom-nguoi-dung",
            templateUrl: "NhomNguoiDung/Index",
            data: { pageTitle: 'Nhóm người dùng' },
            controller: "NhomNguoiDungController",
            resolve: {
                deps: ['$ocLazyLoad', function ($ocLazyLoad) {
                    return $ocLazyLoad.load({
                        name: 'AccountingApp',
                        insertBefore: '#ng_load_plugins_before',
                        files: [
                            '/CustomScripts/Controllers/HeThong/NhomNguoiDungController.js',
                            '/CustomScripts/Services/HeThong/NhomNguoiDungFactory.js',
                        ]
                    });
                }]
            }
        })
        .state('nguoidung', {  //Nhóm người dùng
            url: "/nguoi-dung",
            templateUrl: "NguoiDung/Index",
            data: { pageTitle: 'Người dùng' },
            controller: "NguoiDungController",
            resolve: {
                deps: ['$ocLazyLoad', function ($ocLazyLoad) {
                    return $ocLazyLoad.load({
                        name: 'AccountingApp',
                        insertBefore: '#ng_load_plugins_before',
                        files: [
                            '/CustomScripts/Controllers/HeThong/NguoiDungController.js',
                            '/CustomScripts/Services/HeThong/NguoiDungFactory.js',
                            '/CustomScripts/Services/HeThong/NhomNguoiDungFactory.js',
                        ]
                    });
                }]
            }
        })
        .state('addaccount', {  //Thêm tài khoản chi tiết
            url: "/add-detail-account",
            templateUrl: "AddDetailedAccount/Index",
            data: { pageTitle: 'Thêm tài khoản chi tiết' },
            controller: "AddDetailedAccountController",
            resolve: {
                deps: ['$ocLazyLoad', function ($ocLazyLoad) {
                    return $ocLazyLoad.load({
                        name: 'AccountingApp',
                        insertBefore: '#ng_load_plugins_before',
                        files: [
                            '/CustomScripts/Controllers/AddDetailedAccount/AddDetailedAccountController.js',
                            '/CustomScripts/Services/AddDetailedAccount/AddDetailsAccountFactory.js',
                        ]
                    });
                }]
            }
        })
        .state('Partslist', {  //Danh mục bộ phận
            url: "/danh-muc-bo-phan",
            templateUrl: "Danhmucbophan/Index",
            data: { pageTitle: 'Danh mục bộ phận' },
            controller: "DanhmucbophanController",
            resolve: {
                deps: ['$ocLazyLoad', function ($ocLazyLoad) {
                    return $ocLazyLoad.load({
                        name: 'AccountingApp',
                        insertBefore: '#ng_load_plugins_before',
                        files: [
                            '/CustomScripts/Controllers/Danhmuc/DanhmucbophanController.js',
                            '/CustomScripts/Services/Danhmuc/DanhmucbophanFactory.js',
                        ]
                    });
                }]
            }
        })
        .state('duan', {  //Bảng dự án
            url: "/bang-du-an",
            templateUrl: "BangDuAn/Index",
            data: { pageTitle: 'Bảng dự án' },
            controller: "BangDuAnController",
            resolve: {
                deps: ['$ocLazyLoad', function ($ocLazyLoad) {
                    return $ocLazyLoad.load({
                        name: 'AccountingApp',
                        insertBefore: '#ng_load_plugins_before',
                        files: [
                            '/CustomScripts/Controllers/Danhmuc/BangDuAnController.js',
                            '/CustomScripts/Services/Danhmuc/BangDuAnFactory.js',
                        ]
                    });
                }]
            }
        })
        .state('sanphamdichvu', {  //Danh mục sản phẩm dịch vụ hoạt động
            url: "/danh-muc-san-pham-dich-vu-hoat-dong",
            templateUrl: "DanhMucSanPhamDichVuDuAn/Index",
            data: { pageTitle: 'Bảng dự án' },
            controller: "DanhMucSanPhamDichVuHoatDongController",
            resolve: {
                deps: ['$ocLazyLoad', function ($ocLazyLoad) {
                    return $ocLazyLoad.load({
                        name: 'AccountingApp',
                        insertBefore: '#ng_load_plugins_before',
                        files: [
                            '/CustomScripts/Controllers/Danhmuc/DanhMucSanPhamDichVuHoatDongController.js',
                            '/CustomScripts/Services/Danhmuc/DanhMucSanPhamDichVuHoatDongFactory.js',
                        ]
                    });
                }]
            }
        })
        .state('nhanvien', {  //Danh mục nhân viên
            url: "/danh-muc-nhan-vien",
            templateUrl: "DanhMucNhanVien/Index",
            data: { pageTitle: 'Danh mục nhân viên' },
            controller: "DanhMucNhanVienController",
            resolve: {
                deps: ['$ocLazyLoad', function ($ocLazyLoad) {
                    return $ocLazyLoad.load({
                        name: 'AccountingApp',
                        insertBefore: '#ng_load_plugins_before',
                        files: [
                            '/CustomScripts/Controllers/Danhmuc/DanhMucNhanVienController.js',
                            '/CustomScripts/Services/Danhmuc/DanhMucNhanVienFactory.js',
                        ]
                    });
                }]
            }
        })
        .state('tiente', {  //Danh mục tiền tệ
            url: "/danh-muc-tien-te",
            templateUrl: "DanhMucTienTe/Index",
            data: { pageTitle: 'Danh mục tiền tệ' },
            controller: "DanhMucTienTeController",
            resolve: {
                deps: ['$ocLazyLoad', function ($ocLazyLoad) {
                    return $ocLazyLoad.load({
                        name: 'AccountingApp',
                        insertBefore: '#ng_load_plugins_before',
                        files: [
                            '/CustomScripts/Controllers/Danhmuc/DanhMucTienTeController.js',
                            '/CustomScripts/Services/Danhmuc/DanhMucTienTeFactory.js',
                        ]
                    });
                }]
            }
        })

        .state('doitac', {  //Danh mục đối tác
            url: "/danh-muc-doi-tac",
            templateUrl: "DanhMucDoiTac/Index",
            data: { pageTitle: 'Danh mục đối tác' },
            controller: "DanhMucDoiTacController",
            resolve: {
                deps: ['$ocLazyLoad', function ($ocLazyLoad) {
                    return $ocLazyLoad.load({
                        name: 'AccountingApp',
                        insertBefore: '#ng_load_plugins_before',
                        files: [
                            '/CustomScripts/Controllers/Danhmuc/DanhMucDoiTacController.js',
                            '/CustomScripts/Services/Danhmuc/DanhMucDoiTacFactory.js',
                        ]
                    });
                }]
            }
        })

        .state('taikhoanbank', {  //Danh mục tài khoản bank
            url: "/danh-muc-tai-khoan-bank",
            templateUrl: "DanhMucTaiKhoanBank/Index",
            data: { pageTitle: 'Danh mục tài khoản bank' },
            controller: "DanhMucTaiKhoanBankController",
            resolve: {
                deps: ['$ocLazyLoad', function ($ocLazyLoad) {
                    return $ocLazyLoad.load({
                        name: 'AccountingApp',
                        insertBefore: '#ng_load_plugins_before',
                        files: [
                            '/CustomScripts/Controllers/Danhmuc/DanhMucTaiKhoanBankController.js',
                            '/CustomScripts/Services/Danhmuc/DanhMucTaiKhoanBankFactory.js',
                        ]
                    });
                }]
            }
        })

        .state('chiphi', {  //Danh mục chi phí
            url: "/danh-muc-chi-phi",
            templateUrl: "DanhMucChiPhi/Index",
            data: { pageTitle: 'Danh mục chi phí' },
            controller: "DanhMucChiPhiController",
            resolve: {
                deps: ['$ocLazyLoad', function ($ocLazyLoad) {
                    return $ocLazyLoad.load({
                        name: 'AccountingApp',
                        insertBefore: '#ng_load_plugins_before',
                        files: [
                            '/CustomScripts/Controllers/Danhmuc/DanhMucChiPhiController.js',
                            '/CustomScripts/Services/Danhmuc/DanhMucChiPhiFactory.js',
                        ]
                    });
                }]
            }
        })


        .state('doanhthu', {  //Danh mục doanh thu
            url: "/danh-muc-doanh-thu",
            templateUrl: "DanhMucDoanhThu/Index",
            data: { pageTitle: 'Danh mục doanh thu' },
            controller: "DanhMucDoanhThuController",
            resolve: {
                deps: ['$ocLazyLoad', function ($ocLazyLoad) {
                    return $ocLazyLoad.load({
                        name: 'AccountingApp',
                        insertBefore: '#ng_load_plugins_before',
                        files: [
                            '/CustomScripts/Controllers/Danhmuc/DanhMucDoanhThuController.js',
                            '/CustomScripts/Services/Danhmuc/DanhMucDoanhThuFactory.js',
                        ]
                    });
                }]
            }
        })
        .state('bangtygia', {  //Bảng tỷ giá
            url: "/bang-ty-gia",
            templateUrl: "BangTyGia/Index",
            data: { pageTitle: 'Bảng tỷ giá' },
            controller: "BangTyGiaController",
            resolve: {
                deps: ['$ocLazyLoad', function ($ocLazyLoad) {
                    return $ocLazyLoad.load({
                        name: 'AccountingApp',
                        insertBefore: '#ng_load_plugins_before',
                        files: [
                            '/CustomScripts/Controllers/Danhmuc/BangTyGiaController.js',
                            '/CustomScripts/Services/Danhmuc/BangTyGiaFactory.js',
                        ]
                    });
                }]
            }
        })
        .state('danhmuctaikhoan', {  //Danh mục tài khoản
            url: "/danh-muc-tai-khoan",
            templateUrl: "DanhMucTaiKhoan/Index",
            data: { pageTitle: 'Danh mục tài khoản' },
            controller: "DanhMucTaiKhoanController",
            resolve: {
                deps: ['$ocLazyLoad', function ($ocLazyLoad) {
                    return $ocLazyLoad.load({
                        name: 'AccountingApp',
                        insertBefore: '#ng_load_plugins_before',
                        files: [
                            '/CustomScripts/Controllers/Danhmuc/DanhMucTaiKhoanController.js',
                            '/CustomScripts/Services/Danhmuc/DanhMucTaiKhoanFactory.js',
                        ]
                    });
                }]
            }
        })
        .state('giaodich', {  //Danh mục các loại thuế
            url: "/danh-muc-loai-giao-dich",
            templateUrl: "DanhMucLoaiGiaoDich/Index",
            data: { pageTitle: 'Danh mục loại giao dịch' },
            controller: "DanhMucLoaiGiaoDichController",
            resolve: {
                deps: ['$ocLazyLoad', function ($ocLazyLoad) {
                    return $ocLazyLoad.load({
                        name: 'AccountingApp',
                        insertBefore: '#ng_load_plugins_before',
                        files: [
                            '/CustomScripts/Controllers/Danhmuc/DanhMucLoaiGiaoDichController.js',
                            '/CustomScripts/Services/Danhmuc/DanhMucLoaiGiaoDichFactory.js',
                        ]
                    });
                }]
            }
        })

        .state('giaodichhangngay', {  //Xử lý giao dịch tiền mặt
            url: "/giao-dich-tien-mat",
            templateUrl: "GiaoDichTienMat/Index",
            data: { pageTitle: 'Giao dịch thu tiền mặt' },
            controller: "GiaoDichTienMatController",
            resolve: {
                deps: ['$ocLazyLoad', function ($ocLazyLoad) {
                    return $ocLazyLoad.load({
                        name: 'AccountingApp',
                        insertBefore: '#ng_load_plugins_before',
                        files: [
                            '/CustomScripts/Controllers/XyLyGiaoDich/GiaoDichTienMatController.js',
                            '/CustomScripts/Services/XyLyGiaoDich/GiaoDichTienMatFactory.js',
                        ]
                    });
                }]
            }
        })

        .state('giaodichchitienmat', {  //Danh mục chi tiền mặt
            url: "/danh-muc-chi-tien-mat",
            templateUrl: "GiaoDichChiTienMat/Index",
            data: { pageTitle: 'Danh mục chi tiền mặt' },
            controller: "GiaoDichChiTienMatController",
            resolve: {
                deps: ['$ocLazyLoad', function ($ocLazyLoad) {
                    return $ocLazyLoad.load({
                        name: 'AccountingApp',
                        insertBefore: '#ng_load_plugins_before',
                        files: [
                            '/CustomScripts/Controllers/XyLyGiaoDich/GiaoDichChiTienMatController.js',
                            '/CustomScripts/Services/XyLyGiaoDich/GiaoDichChiTienMatFactory.js',
                        ]
                    });
                }]
            }
        })
        .state('giaodichchuyentien', {  //Danh mục chuyển tiền
            url: "/giao-dich-chuyen-tien",
            templateUrl: "GiaoDichChuyenTien/Index",
            data: { pageTitle: 'Giao dịch chuyển tiền' },
            controller: "GiaoDichChuyenTienController",
            resolve: {
                deps: ['$ocLazyLoad', function ($ocLazyLoad) {
                    return $ocLazyLoad.load({
                        name: 'AccountingApp',
                        insertBefore: '#ng_load_plugins_before',
                        files: [
                            '/CustomScripts/Controllers/XyLyGiaoDich/GiaoDichChuyenTienController.js',
                            '/CustomScripts/Services/XyLyGiaoDich/GiaoDichChuyenTienFactory.js',
                        ]
                    });
                }]
            }
        })
        .state('themmoigiaodichchitienmat', {  //Danh mục chi tiền mặt
            url: "/them-moi-giao-dich-chi-tien-mat",
            templateUrl: "GiaoDichChiTienMat/CreateTab",
            data: { pageTitle: 'Thêm mới giao dịch chi tiền mặt' },
            controller: "GiaoDichChiTienMatController",
            resolve: {
                deps: ['$ocLazyLoad', function ($ocLazyLoad) {
                    return $ocLazyLoad.load({
                        name: 'AccountingApp',
                        insertBefore: '#ng_load_plugins_before',
                        files: [
                            '/CustomScripts/Controllers/XyLyGiaoDich/GiaoDichChiTienMatController.js',
                            '/CustomScripts/Services/XyLyGiaoDich/GiaoDichChiTienMatFactory.js',
                        ]
                    });
                }]
            }
        })
        //thêm mới giao dịch thu tiền mặt
        .state('themmoigiaodichthutienmat', {  //Danh mục chi tiền mặt
            url: "/them-moi-giao-dich-thu-tien-mat",
            templateUrl: "GiaoDichTienMat/CreateTab",
            data: { pageTitle: 'Thêm mới giao dịch chi tiền mặt' },
            controller: "GiaoDichTienMatController",
            resolve: {
                deps: ['$ocLazyLoad', function ($ocLazyLoad) {
                    return $ocLazyLoad.load({
                        name: 'AccountingApp',
                        insertBefore: '#ng_load_plugins_before',
                        files: [
                            '/CustomScripts/Controllers/XyLyGiaoDich/GiaoDichTienMatController.js',
                            '/CustomScripts/Services/XyLyGiaoDich/GiaoDichTienMatFactory.js',
                        ]
                    });
                }]
            }
        })

        .state('thue', {  //Danh mục các loại thuế
            url: "/danh-muc-cac-loai-thue",
            templateUrl: "DanhMucCacLoaiThue/Index",
            data: { pageTitle: 'Danh mục các loại thuế' },
            controller: "DanhMucCacLoaiThueController",
            resolve: {
                deps: ['$ocLazyLoad', function ($ocLazyLoad) {
                    return $ocLazyLoad.load({
                        name: 'AccountingApp',
                        insertBefore: '#ng_load_plugins_before',
                        files: [
                            '/CustomScripts/Controllers/Danhmuc/DanhMucCacLoaiThueController.js',
                            '/CustomScripts/Services/Danhmuc/DanhMucCacLoaiThueFactory.js',
                        ]
                    });
                }]
            }
        })
        .state('themmoigiaodichchuyentien', {  //thêm GD chuyển tiềns
            url: "/them-moi-giao-dich-chuyen-tien",
            templateUrl: "GiaoDichChuyenTien/CreateTab",
            data: { pageTitle: 'Thêm mới giao dịch chuyển tiền' },
            controller: "GiaoDichChuyenTienController",
            resolve: {
                deps: ['$ocLazyLoad', function ($ocLazyLoad) {
                    return $ocLazyLoad.load({
                        name: 'AccountingApp',
                        insertBefore: '#ng_load_plugins_before',
                        files: [
                            '/CustomScripts/Controllers/XyLyGiaoDich/GiaoDichChuyenTienController.js',
                            '/CustomScripts/Services/XyLyGiaoDich/GiaoDichChuyenTienFactory.js',
                        ]
                    });
                }]
            }
        })
}]);

