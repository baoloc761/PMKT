﻿/* Thanh trượt bên phải */
var AccountingApp = angular.module('AccountingApp');
AccountingApp.controller('QuickSidebarController', ['$scope', '$state', '$rootScope', function ($scope, $state, $rootScope) {
    $scope.$on('$includeContentLoaded', function () {
       

    });
   
}]);