﻿angular.module('AccountingApp').controller("DanhMucTienTeController", function ($scope, DanhMucTienTeFactory, SweetAlert) {
    $scope.$on('$viewContentLoaded', function () {
        $scope.getdanhtiente();
        $scope.rowFocus = { CurrencyID: 0, CurrencyCode: '', CurrencyName: ''};
    });
    $scope.selectRow = function (item) {
        $scope.rowFocus = item;
    }
    //danh sách tiền tệ
    $scope.getdanhtiente = function () {
        $scope.Danhsachtiente = {};
        DanhMucTienTeFactory
            .Laydanhsachtiente()
            .done(function (res) {
                if (res && res.ErrorCode === 0) {
                    if (res.Data.Currencies.length > 0) {
                        $scope.Danhsachtiente = res.Data.Currencies;
                        setTimeout(t => {
                            $('#datatables-example').DataTable();
                            $('#datatables-example_filter label input, #datatables-example_paginate ul').on('click', function () {
                                $scope.rowFocus = { IdNhom: 0 };
                                $scope.$digest();
                            });
                        }, 100)
                    }
                    else {
                        toastr.info('Không có dữ liệu danh sách');
                    }
                }
                else {
                    toastr.warning(res.ErrorMsg);
                }
            }).fail(function () {
                toastr.error(res.ErrorMsg);
            }).always(function () {
                $scope.$digest();
            });
    }

    //popup tiền tệ
    //Thêm popup nhân viên
    $scope.initThemTienTe = function () {
        $scope.ItemDetail = {
            CurrencyID: 0,
            CurrencyCode: '',
            CurrencyName: ''
        };
        $('#DetailModal').modal('show');
        //Validate form
        validateForm("#DetailForm")
    };
    //Lưu tiền tệ
    $scope.ThemTienTe = function (item) {
        $scope.Danhsachtiente= {};
        DanhMucTienTeFactory
            .ThemMoiTienTe(item)
            .done(function (res) {
                if (res && res.ErrorCode === 0) {
                    $('#DetailModal').modal('hide');
                    $scope.getdanhtiente();
                    toastr.success("Thêm thành công!")
                }
                else {
                    toastr.warning(res.ErrorMsg);
                }
            }).fail(function () {
                toastr.error(res.ErrorMsg);
            }).always(function () {
                $scope.$digest();
            });
    }

    //khởi tạo xóa
    $scope.initXoaTienTe = function (item) {
        SweetAlert.swal({
            title: "Xóa tiền tệ ?",
            text: "Tiền tệ: " + item.CurrencyName + " sẽ được xóa!",
            type: "warning",
            showCancelButton: true,
            confirmButtonColor: "#DD6B55", confirmButtonText: "Đồng ý!",
            cancelButtonColor: "#D0D0D0", cancelButtonText: "Hủy bỏ!",
            closeOnConfirm: false,
            closeOnCancel: true
        },
            function (isConfirm) {
                if (isConfirm) {
                    DanhMucTienTeFactory
                        .XoaDichVuTienTe(item)
                        .done(function (res) {
                            if (res && res.ErrorCode === 0) {
                                toastr.success("Xóa thành công !")
                                $scope.getdanhtiente();
                                location.reload();
                            }
                            else {
                                toastr.warning(res.ErrorMsg);
                            }
                        }).fail(function () {
                            toastr.error("Lỗi");
                        }).always(function () {
                            SweetAlert.swal.close()
                            $scope.$digest();
                        });
                }
            });

    };
    //Nút xóa tiên tệ
    $scope.XoaTienTe = function (item) {
        DanhMucTienTeFactory
            .XoaDichVuTienTe(item.CurrencyID)
            .done(function (res) {
                if (res && res.ErrorCode === 0) {
                    toastr.success(res.Message)
                    $('#idm_Xoa').modal('hide')
                    $scope.getdanhtiente();
                }
                else {
                    toastr.warning(res.ErrorMsg);
                }
            }).fail(function () {
                toastr.error(res.ErrorMsg);
            }).always(function () {
                SweetAlert.swal.close()
                $scope.$digest();
            });
    }

    $scope.initCapNhapTienTe = function (item) {
        var MaTienTe = item.CurrencyCode;
        var TenTiente = item.CurrencyName;
        $scope.ItemDetail = {
            CurrencyCode: MaTienTe,
            CurrencyName: TenTiente,
            CurrencyID: item.CurrencyID
        };
        //$scope.ItemDetail = item;
        DanhMucTienTeFactory
        $('#DetailModal').modal('show');
    };

    //cập nhật
    $scope.CapNhatDanhSachTienTe = function () {
        var check = $("#DetailForm").valid();
        if (check) {
            DanhMucTienTeFactory
                .CapNhatTienTe($scope.ItemDetail)
                .done(function (res) {
                    if (res && res.ErrorCode === 0) {
                        toastr.success("Sửa thành công !")
                        $('#DetailModal').modal('hide');
                        $scope.getdanhBophan();
                    }
                    else {
                        toastr.warning(res.ErrorMsg);
                    }
                }).fail(function () {
                    toastr.error(res.ErrorMsg);
                }).always(function () {
                    setTimeout(t => {
                        $scope.disableBtn = false;
                    }, 500)
                    $scope.$digest();
                });
        }
    }



    function clearValidation(formElement) {
        var validator = $(formElement).validate();
        $('[name]', formElement).each(function () {
            validator.successList.push(this);//mark as error free
            validator.showErrors();//remove error messages if present
        });
        validator.resetForm();//remove error class on name elements and clear history
        validator.reset();//remove all error and success data
    }
    //Khi modal đóng thì clear hết validate
    $("#DetailModal").on("hidden.bs.modal", function () {
        clearValidation('#DetailForm');
    });
    //#endregion
    $scope.DoubleClick = function () {
        return;
    }
});