﻿(function () {
    angular.module('AccountingApp')
        .factory('BangTyGiaFactory', BangTyGiaFactory); //tao factory cho module chinh
    BangTyGiaFactory.$inject = ['$http']; //tim service http vao
    function BangTyGiaFactory($http) {
        var service = {
            LayDanhMucBangTyGia: LayDanhMucBangTyGia,
            ThemTyGia: ThemTyGia,
            LayDanhSachTienTeSelect: LayDanhSachTienTeSelect,
            SuaTyGia: SuaTyGia,
            XoaTyGia: XoaTyGia
        };
        return service

        //GET LIST Tiền
        function LayDanhSachTienTeSelect(item) {
            var data = item;
            var response = $.ajax({
                type: 'POST',
                url: '/BangTyGia/GetMoney',
                dataType: 'json',
                contentType: 'application/json; charset=utf-8',
                data: JSON.stringify(data),

            });
            return response;
        }

        //GET LIST bảng tỷ giá
        function LayDanhMucBangTyGia() {
            var bodyRequest = {
                data: {
                    SearchValue: '',
                    Page: 1,
                    RowPerPage: 10,
                    SortType: ''
                }
            };
            var response = $.ajax({
                type: 'POST',
                url: '/BangTyGia/GetExchangeRates',
                dataType: 'json',
                contentType: 'application/json; charset=utf-8',
                data: JSON.stringify(bodyRequest),
            });
            return response;
        }
        //Thêm ty gia
        function ThemTyGia(item) {
            var data = item;
            var response = $.ajax({
                type: 'POST',
                url: '/BangTyGia/AddExchangeRates',
                dataType: 'json',
                contentType: 'application/json; charset=utf-8',
                data: JSON.stringify(data),
            });
            return response;
        }
        //Sửa tỷ giá
        function SuaTyGia(item) {
            var data = item;
            var response = $.ajax({
                type: 'POST',
                url: '/BangTyGia/UpdateExchangeRates',
                dataType: 'json',
                contentType: 'application/json; charset=utf-8',
                data: JSON.stringify(data),
            });
            return response;
        }

        //Xóa tỷ giá
        function XoaTyGia(item) {
            var data = item;
            var response = $.ajax({
                type: 'POST',
                url: '/BangTyGia/DeleteExchangeRates',
                dataType: 'json',
                contentType: 'application/json; charset=utf-8',
                data: JSON.stringify(data),
            });
            return response;
        }
    }
})();